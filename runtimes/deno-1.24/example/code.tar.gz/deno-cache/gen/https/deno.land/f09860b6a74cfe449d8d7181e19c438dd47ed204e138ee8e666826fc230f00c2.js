// Copyright 2018-2022 the oak authors. All rights reserved. MIT license.
import { contentType, Status, STATUS_TEXT } from "./deps.ts";
import { DomResponse } from "./http_server_native_request.ts";
import { BODY_TYPES, encodeUrl, isAsyncIterable, isHtml, isReader, isRedirectStatus, readableStreamFromAsyncIterable, readableStreamFromReader, Uint8ArrayTransformStream } from "./util.ts";
/** A symbol that indicates to `response.redirect()` to attempt to redirect
 * back to the request referrer.  For example:
 *
 * ```ts
 * import { Application, REDIRECT_BACK } from "https://deno.land/x/oak/mod.ts";
 *
 * const app = new Application();
 *
 * app.use((ctx) => {
 *   if (ctx.request.url.pathName === "/back") {
 *     ctx.response.redirect(REDIRECT_BACK, "/");
 *   }
 * });
 *
 * await app.listen({ port: 80 });
 * ```
 */ export const REDIRECT_BACK = Symbol("redirect backwards");
export async function convertBodyToBodyInit(body, type) {
    let result;
    if (BODY_TYPES.includes(typeof body)) {
        result = String(body);
        type = type ?? (isHtml(result) ? "html" : "text/plain");
    } else if (isReader(body)) {
        result = readableStreamFromReader(body);
    } else if (ArrayBuffer.isView(body) || body instanceof ArrayBuffer || body instanceof Blob || body instanceof URLSearchParams) {
        // deno-lint-ignore no-explicit-any
        result = body;
    } else if (body instanceof ReadableStream) {
        result = body.pipeThrough(new Uint8ArrayTransformStream());
    } else if (body instanceof FormData) {
        result = body;
        type = "multipart/form-data";
    } else if (isAsyncIterable(body)) {
        result = readableStreamFromAsyncIterable(body);
    } else if (body && typeof body === "object") {
        result = JSON.stringify(body);
        type = type ?? "json";
    } else if (typeof body === "function") {
        const result1 = body.call(null);
        return convertBodyToBodyInit(await result1, type);
    } else if (body) {
        throw new TypeError("Response body was set but could not be converted.");
    }
    return [
        result,
        type
    ];
}
/** An interface to control what response will be sent when the middleware
 * finishes processing the request.
 *
 * The response is usually accessed via the context's `.response` property.
 *
 * ### Example
 *
 * ```ts
 * import { Application, Status } from "https://deno.land/x/oak/mod.ts";
 *
 * const app = new Application();
 *
 * app.use((ctx) => {
 *   ctx.response.body = { hello: "oak" };
 *   ctx.response.type = "json";
 *   ctx.response.status = Status.OK;
 * });
 * ```
 */ export class Response {
    #body;
    #bodySet = false;
    #domResponse;
    #headers = new Headers();
    #request;
    #resources = [];
    #status;
    #type;
    #writable = true;
    async #getBodyInit() {
        const [body, type] = await convertBodyToBodyInit(this.body, this.type);
        this.type = type;
        return body;
    }
     #setContentType() {
        if (this.type) {
            const contentTypeString = contentType(this.type);
            if (contentTypeString && !this.headers.has("Content-Type")) {
                this.headers.append("Content-Type", contentTypeString);
            }
        }
    }
    /** The body of the response.  The body will be automatically processed when
   * the response is being sent and converted to a `Uint8Array` or a
   * `Deno.Reader`.
   *
   * Automatic conversion to a `Deno.Reader` occurs for async iterables. */ get body() {
        return this.#body;
    }
    /** The body of the response.  The body will be automatically processed when
   * the response is being sent and converted to a `Uint8Array` or a
   * `Deno.Reader`.
   *
   * Automatic conversion to a `Deno.Reader` occurs for async iterables. */ set body(value) {
        if (!this.#writable) {
            throw new Error("The response is not writable.");
        }
        this.#bodySet = true;
        this.#body = value;
    }
    /** Headers that will be returned in the response. */ get headers() {
        return this.#headers;
    }
    /** Headers that will be returned in the response. */ set headers(value) {
        if (!this.#writable) {
            throw new Error("The response is not writable.");
        }
        this.#headers = value;
    }
    /** The HTTP status of the response.  If this has not been explicitly set,
   * reading the value will return what would be the value of status if the
   * response were sent at this point in processing the middleware.  If the body
   * has been set, the status will be `200 OK`.  If a value for the body has
   * not been set yet, the status will be `404 Not Found`. */ get status() {
        if (this.#status) {
            return this.#status;
        }
        return this.body != null ? Status.OK : this.#bodySet ? Status.NoContent : Status.NotFound;
    }
    /** The HTTP status of the response.  If this has not been explicitly set,
   * reading the value will return what would be the value of status if the
   * response were sent at this point in processing the middleware.  If the body
   * has been set, the status will be `200 OK`.  If a value for the body has
   * not been set yet, the status will be `404 Not Found`. */ set status(value) {
        if (!this.#writable) {
            throw new Error("The response is not writable.");
        }
        this.#status = value;
    }
    /** The media type, or extension of the response.  Setting this value will
   * ensure an appropriate `Content-Type` header is added to the response. */ get type() {
        return this.#type;
    }
    /** The media type, or extension of the response.  Setting this value will
   * ensure an appropriate `Content-Type` header is added to the response. */ set type(value) {
        if (!this.#writable) {
            throw new Error("The response is not writable.");
        }
        this.#type = value;
    }
    /** A read-only property which determines if the response is writable or not.
   * Once the response has been processed, this value is set to `false`. */ get writable() {
        return this.#writable;
    }
    constructor(request){
        this.#request = request;
    }
    /** Add a resource to the list of resources that will be closed when the
   * request is destroyed. */ addResource(rid) {
        this.#resources.push(rid);
    }
    /** Release any resources that are being tracked by the response.
   *
   * @param closeResources close any resource IDs registered with the response
   */ destroy(closeResources = true) {
        this.#writable = false;
        this.#body = undefined;
        this.#domResponse = undefined;
        if (closeResources) {
            for (const rid of this.#resources){
                try {
                    Deno.close(rid);
                } catch  {
                // we don't care about errors here
                }
            }
        }
    }
    redirect(url, alt = "/") {
        if (url === REDIRECT_BACK) {
            url = this.#request.headers.get("Referer") ?? String(alt);
        } else if (typeof url === "object") {
            url = String(url);
        }
        this.headers.set("Location", encodeUrl(url));
        if (!this.status || !isRedirectStatus(this.status)) {
            this.status = Status.Found;
        }
        if (this.#request.accepts("html")) {
            url = encodeURI(url);
            this.type = "text/html; charset=utf-8";
            this.body = `Redirecting to <a href="${url}">${url}</a>.`;
            return;
        }
        this.type = "text/plain; charset=utf-8";
        this.body = `Redirecting to ${url}.`;
    }
    async toDomResponse() {
        if (this.#domResponse) {
            return this.#domResponse;
        }
        const bodyInit = await this.#getBodyInit();
        this.#setContentType();
        const { headers  } = this;
        // If there is no body and no content type and no set length, then set the
        // content length to 0
        if (!(bodyInit || headers.has("Content-Type") || headers.has("Content-Length"))) {
            headers.append("Content-Length", "0");
        }
        this.#writable = false;
        const status = this.status;
        const responseInit = {
            headers,
            status,
            statusText: STATUS_TEXT.get(status)
        };
        return this.#domResponse = new DomResponse(bodyInit, responseInit);
    }
    [Symbol.for("Deno.customInspect")](inspect) {
        const { body , headers , status , type , writable  } = this;
        return `${this.constructor.name} ${inspect({
            body,
            headers,
            status,
            type,
            writable
        })}`;
    }
    [Symbol.for("nodejs.util.inspect.custom")](depth, // deno-lint-ignore no-explicit-any
    options, inspect) {
        if (depth < 0) {
            return options.stylize(`[${this.constructor.name}]`, "special");
        }
        const newOptions = Object.assign({}, options, {
            depth: options.depth === null ? null : options.depth - 1
        });
        const { body , headers , status , type , writable  } = this;
        return `${options.stylize(this.constructor.name, "special")} ${inspect({
            body,
            headers,
            status,
            type,
            writable
        }, newOptions)}`;
    }
}
//# sourceMappingURL=data:application/json;base64,eyJ2ZXJzaW9uIjozLCJzb3VyY2VzIjpbImh0dHBzOi8vZGVuby5sYW5kL3gvb2FrQHYxMC42LjAvcmVzcG9uc2UudHMiXSwic291cmNlc0NvbnRlbnQiOlsiLy8gQ29weXJpZ2h0IDIwMTgtMjAyMiB0aGUgb2FrIGF1dGhvcnMuIEFsbCByaWdodHMgcmVzZXJ2ZWQuIE1JVCBsaWNlbnNlLlxuXG5pbXBvcnQgeyBjb250ZW50VHlwZSwgU3RhdHVzLCBTVEFUVVNfVEVYVCB9IGZyb20gXCIuL2RlcHMudHNcIjtcbmltcG9ydCB7IERvbVJlc3BvbnNlIH0gZnJvbSBcIi4vaHR0cF9zZXJ2ZXJfbmF0aXZlX3JlcXVlc3QudHNcIjtcbmltcG9ydCB0eXBlIHsgUmVxdWVzdCB9IGZyb20gXCIuL3JlcXVlc3QudHNcIjtcbmltcG9ydCB7XG4gIEJPRFlfVFlQRVMsXG4gIGVuY29kZVVybCxcbiAgaXNBc3luY0l0ZXJhYmxlLFxuICBpc0h0bWwsXG4gIGlzUmVhZGVyLFxuICBpc1JlZGlyZWN0U3RhdHVzLFxuICByZWFkYWJsZVN0cmVhbUZyb21Bc3luY0l0ZXJhYmxlLFxuICByZWFkYWJsZVN0cmVhbUZyb21SZWFkZXIsXG4gIFVpbnQ4QXJyYXlUcmFuc2Zvcm1TdHJlYW0sXG59IGZyb20gXCIuL3V0aWwudHNcIjtcblxuZXhwb3J0IHR5cGUgUmVzcG9uc2VCb2R5ID1cbiAgfCBzdHJpbmdcbiAgfCBudW1iZXJcbiAgfCBiaWdpbnRcbiAgfCBib29sZWFuXG4gIHwgc3ltYm9sXG4gIC8vIGRlbm8tbGludC1pZ25vcmUgYmFuLXR5cGVzXG4gIHwgb2JqZWN0XG4gIHwgdW5kZWZpbmVkXG4gIHwgbnVsbDtcbmV4cG9ydCB0eXBlIFJlc3BvbnNlQm9keUZ1bmN0aW9uID0gKCkgPT4gUmVzcG9uc2VCb2R5IHwgUHJvbWlzZTxSZXNwb25zZUJvZHk+O1xuXG4vKiogQSBzeW1ib2wgdGhhdCBpbmRpY2F0ZXMgdG8gYHJlc3BvbnNlLnJlZGlyZWN0KClgIHRvIGF0dGVtcHQgdG8gcmVkaXJlY3RcbiAqIGJhY2sgdG8gdGhlIHJlcXVlc3QgcmVmZXJyZXIuICBGb3IgZXhhbXBsZTpcbiAqXG4gKiBgYGB0c1xuICogaW1wb3J0IHsgQXBwbGljYXRpb24sIFJFRElSRUNUX0JBQ0sgfSBmcm9tIFwiaHR0cHM6Ly9kZW5vLmxhbmQveC9vYWsvbW9kLnRzXCI7XG4gKlxuICogY29uc3QgYXBwID0gbmV3IEFwcGxpY2F0aW9uKCk7XG4gKlxuICogYXBwLnVzZSgoY3R4KSA9PiB7XG4gKiAgIGlmIChjdHgucmVxdWVzdC51cmwucGF0aE5hbWUgPT09IFwiL2JhY2tcIikge1xuICogICAgIGN0eC5yZXNwb25zZS5yZWRpcmVjdChSRURJUkVDVF9CQUNLLCBcIi9cIik7XG4gKiAgIH1cbiAqIH0pO1xuICpcbiAqIGF3YWl0IGFwcC5saXN0ZW4oeyBwb3J0OiA4MCB9KTtcbiAqIGBgYFxuICovXG5leHBvcnQgY29uc3QgUkVESVJFQ1RfQkFDSyA9IFN5bWJvbChcInJlZGlyZWN0IGJhY2t3YXJkc1wiKTtcblxuZXhwb3J0IGFzeW5jIGZ1bmN0aW9uIGNvbnZlcnRCb2R5VG9Cb2R5SW5pdChcbiAgYm9keTogUmVzcG9uc2VCb2R5IHwgUmVzcG9uc2VCb2R5RnVuY3Rpb24sXG4gIHR5cGU/OiBzdHJpbmcsXG4pOiBQcm9taXNlPFtnbG9iYWxUaGlzLkJvZHlJbml0IHwgdW5kZWZpbmVkLCBzdHJpbmcgfCB1bmRlZmluZWRdPiB7XG4gIGxldCByZXN1bHQ6IGdsb2JhbFRoaXMuQm9keUluaXQgfCB1bmRlZmluZWQ7XG4gIGlmIChCT0RZX1RZUEVTLmluY2x1ZGVzKHR5cGVvZiBib2R5KSkge1xuICAgIHJlc3VsdCA9IFN0cmluZyhib2R5KTtcbiAgICB0eXBlID0gdHlwZSA/PyAoaXNIdG1sKHJlc3VsdCkgPyBcImh0bWxcIiA6IFwidGV4dC9wbGFpblwiKTtcbiAgfSBlbHNlIGlmIChpc1JlYWRlcihib2R5KSkge1xuICAgIHJlc3VsdCA9IHJlYWRhYmxlU3RyZWFtRnJvbVJlYWRlcihib2R5KTtcbiAgfSBlbHNlIGlmIChcbiAgICBBcnJheUJ1ZmZlci5pc1ZpZXcoYm9keSkgfHwgYm9keSBpbnN0YW5jZW9mIEFycmF5QnVmZmVyIHx8XG4gICAgYm9keSBpbnN0YW5jZW9mIEJsb2IgfHwgYm9keSBpbnN0YW5jZW9mIFVSTFNlYXJjaFBhcmFtc1xuICApIHtcbiAgICAvLyBkZW5vLWxpbnQtaWdub3JlIG5vLWV4cGxpY2l0LWFueVxuICAgIHJlc3VsdCA9IGJvZHkgYXMgYW55O1xuICB9IGVsc2UgaWYgKGJvZHkgaW5zdGFuY2VvZiBSZWFkYWJsZVN0cmVhbSkge1xuICAgIHJlc3VsdCA9IGJvZHkucGlwZVRocm91Z2gobmV3IFVpbnQ4QXJyYXlUcmFuc2Zvcm1TdHJlYW0oKSk7XG4gIH0gZWxzZSBpZiAoYm9keSBpbnN0YW5jZW9mIEZvcm1EYXRhKSB7XG4gICAgcmVzdWx0ID0gYm9keTtcbiAgICB0eXBlID0gXCJtdWx0aXBhcnQvZm9ybS1kYXRhXCI7XG4gIH0gZWxzZSBpZiAoaXNBc3luY0l0ZXJhYmxlKGJvZHkpKSB7XG4gICAgcmVzdWx0ID0gcmVhZGFibGVTdHJlYW1Gcm9tQXN5bmNJdGVyYWJsZShib2R5KTtcbiAgfSBlbHNlIGlmIChib2R5ICYmIHR5cGVvZiBib2R5ID09PSBcIm9iamVjdFwiKSB7XG4gICAgcmVzdWx0ID0gSlNPTi5zdHJpbmdpZnkoYm9keSk7XG4gICAgdHlwZSA9IHR5cGUgPz8gXCJqc29uXCI7XG4gIH0gZWxzZSBpZiAodHlwZW9mIGJvZHkgPT09IFwiZnVuY3Rpb25cIikge1xuICAgIGNvbnN0IHJlc3VsdCA9IGJvZHkuY2FsbChudWxsKTtcbiAgICByZXR1cm4gY29udmVydEJvZHlUb0JvZHlJbml0KGF3YWl0IHJlc3VsdCwgdHlwZSk7XG4gIH0gZWxzZSBpZiAoYm9keSkge1xuICAgIHRocm93IG5ldyBUeXBlRXJyb3IoXCJSZXNwb25zZSBib2R5IHdhcyBzZXQgYnV0IGNvdWxkIG5vdCBiZSBjb252ZXJ0ZWQuXCIpO1xuICB9XG4gIHJldHVybiBbcmVzdWx0LCB0eXBlXTtcbn1cblxuLyoqIEFuIGludGVyZmFjZSB0byBjb250cm9sIHdoYXQgcmVzcG9uc2Ugd2lsbCBiZSBzZW50IHdoZW4gdGhlIG1pZGRsZXdhcmVcbiAqIGZpbmlzaGVzIHByb2Nlc3NpbmcgdGhlIHJlcXVlc3QuXG4gKlxuICogVGhlIHJlc3BvbnNlIGlzIHVzdWFsbHkgYWNjZXNzZWQgdmlhIHRoZSBjb250ZXh0J3MgYC5yZXNwb25zZWAgcHJvcGVydHkuXG4gKlxuICogIyMjIEV4YW1wbGVcbiAqXG4gKiBgYGB0c1xuICogaW1wb3J0IHsgQXBwbGljYXRpb24sIFN0YXR1cyB9IGZyb20gXCJodHRwczovL2Rlbm8ubGFuZC94L29hay9tb2QudHNcIjtcbiAqXG4gKiBjb25zdCBhcHAgPSBuZXcgQXBwbGljYXRpb24oKTtcbiAqXG4gKiBhcHAudXNlKChjdHgpID0+IHtcbiAqICAgY3R4LnJlc3BvbnNlLmJvZHkgPSB7IGhlbGxvOiBcIm9ha1wiIH07XG4gKiAgIGN0eC5yZXNwb25zZS50eXBlID0gXCJqc29uXCI7XG4gKiAgIGN0eC5yZXNwb25zZS5zdGF0dXMgPSBTdGF0dXMuT0s7XG4gKiB9KTtcbiAqIGBgYFxuICovXG5leHBvcnQgY2xhc3MgUmVzcG9uc2Uge1xuICAjYm9keT86IFJlc3BvbnNlQm9keSB8IFJlc3BvbnNlQm9keUZ1bmN0aW9uO1xuICAjYm9keVNldCA9IGZhbHNlO1xuICAjZG9tUmVzcG9uc2U/OiBnbG9iYWxUaGlzLlJlc3BvbnNlO1xuICAjaGVhZGVycyA9IG5ldyBIZWFkZXJzKCk7XG4gICNyZXF1ZXN0OiBSZXF1ZXN0O1xuICAjcmVzb3VyY2VzOiBudW1iZXJbXSA9IFtdO1xuICAjc3RhdHVzPzogU3RhdHVzO1xuICAjdHlwZT86IHN0cmluZztcbiAgI3dyaXRhYmxlID0gdHJ1ZTtcblxuICBhc3luYyAjZ2V0Qm9keUluaXQoKTogUHJvbWlzZTxnbG9iYWxUaGlzLkJvZHlJbml0IHwgdW5kZWZpbmVkPiB7XG4gICAgY29uc3QgW2JvZHksIHR5cGVdID0gYXdhaXQgY29udmVydEJvZHlUb0JvZHlJbml0KHRoaXMuYm9keSwgdGhpcy50eXBlKTtcbiAgICB0aGlzLnR5cGUgPSB0eXBlO1xuICAgIHJldHVybiBib2R5O1xuICB9XG5cbiAgI3NldENvbnRlbnRUeXBlKCk6IHZvaWQge1xuICAgIGlmICh0aGlzLnR5cGUpIHtcbiAgICAgIGNvbnN0IGNvbnRlbnRUeXBlU3RyaW5nID0gY29udGVudFR5cGUodGhpcy50eXBlKTtcbiAgICAgIGlmIChjb250ZW50VHlwZVN0cmluZyAmJiAhdGhpcy5oZWFkZXJzLmhhcyhcIkNvbnRlbnQtVHlwZVwiKSkge1xuICAgICAgICB0aGlzLmhlYWRlcnMuYXBwZW5kKFwiQ29udGVudC1UeXBlXCIsIGNvbnRlbnRUeXBlU3RyaW5nKTtcbiAgICAgIH1cbiAgICB9XG4gIH1cblxuICAvKiogVGhlIGJvZHkgb2YgdGhlIHJlc3BvbnNlLiAgVGhlIGJvZHkgd2lsbCBiZSBhdXRvbWF0aWNhbGx5IHByb2Nlc3NlZCB3aGVuXG4gICAqIHRoZSByZXNwb25zZSBpcyBiZWluZyBzZW50IGFuZCBjb252ZXJ0ZWQgdG8gYSBgVWludDhBcnJheWAgb3IgYVxuICAgKiBgRGVuby5SZWFkZXJgLlxuICAgKlxuICAgKiBBdXRvbWF0aWMgY29udmVyc2lvbiB0byBhIGBEZW5vLlJlYWRlcmAgb2NjdXJzIGZvciBhc3luYyBpdGVyYWJsZXMuICovXG4gIGdldCBib2R5KCk6IFJlc3BvbnNlQm9keSB8IFJlc3BvbnNlQm9keUZ1bmN0aW9uIHtcbiAgICByZXR1cm4gdGhpcy4jYm9keTtcbiAgfVxuXG4gIC8qKiBUaGUgYm9keSBvZiB0aGUgcmVzcG9uc2UuICBUaGUgYm9keSB3aWxsIGJlIGF1dG9tYXRpY2FsbHkgcHJvY2Vzc2VkIHdoZW5cbiAgICogdGhlIHJlc3BvbnNlIGlzIGJlaW5nIHNlbnQgYW5kIGNvbnZlcnRlZCB0byBhIGBVaW50OEFycmF5YCBvciBhXG4gICAqIGBEZW5vLlJlYWRlcmAuXG4gICAqXG4gICAqIEF1dG9tYXRpYyBjb252ZXJzaW9uIHRvIGEgYERlbm8uUmVhZGVyYCBvY2N1cnMgZm9yIGFzeW5jIGl0ZXJhYmxlcy4gKi9cbiAgc2V0IGJvZHkodmFsdWU6IFJlc3BvbnNlQm9keSB8IFJlc3BvbnNlQm9keUZ1bmN0aW9uKSB7XG4gICAgaWYgKCF0aGlzLiN3cml0YWJsZSkge1xuICAgICAgdGhyb3cgbmV3IEVycm9yKFwiVGhlIHJlc3BvbnNlIGlzIG5vdCB3cml0YWJsZS5cIik7XG4gICAgfVxuICAgIHRoaXMuI2JvZHlTZXQgPSB0cnVlO1xuICAgIHRoaXMuI2JvZHkgPSB2YWx1ZTtcbiAgfVxuXG4gIC8qKiBIZWFkZXJzIHRoYXQgd2lsbCBiZSByZXR1cm5lZCBpbiB0aGUgcmVzcG9uc2UuICovXG4gIGdldCBoZWFkZXJzKCk6IEhlYWRlcnMge1xuICAgIHJldHVybiB0aGlzLiNoZWFkZXJzO1xuICB9XG5cbiAgLyoqIEhlYWRlcnMgdGhhdCB3aWxsIGJlIHJldHVybmVkIGluIHRoZSByZXNwb25zZS4gKi9cbiAgc2V0IGhlYWRlcnModmFsdWU6IEhlYWRlcnMpIHtcbiAgICBpZiAoIXRoaXMuI3dyaXRhYmxlKSB7XG4gICAgICB0aHJvdyBuZXcgRXJyb3IoXCJUaGUgcmVzcG9uc2UgaXMgbm90IHdyaXRhYmxlLlwiKTtcbiAgICB9XG4gICAgdGhpcy4jaGVhZGVycyA9IHZhbHVlO1xuICB9XG5cbiAgLyoqIFRoZSBIVFRQIHN0YXR1cyBvZiB0aGUgcmVzcG9uc2UuICBJZiB0aGlzIGhhcyBub3QgYmVlbiBleHBsaWNpdGx5IHNldCxcbiAgICogcmVhZGluZyB0aGUgdmFsdWUgd2lsbCByZXR1cm4gd2hhdCB3b3VsZCBiZSB0aGUgdmFsdWUgb2Ygc3RhdHVzIGlmIHRoZVxuICAgKiByZXNwb25zZSB3ZXJlIHNlbnQgYXQgdGhpcyBwb2ludCBpbiBwcm9jZXNzaW5nIHRoZSBtaWRkbGV3YXJlLiAgSWYgdGhlIGJvZHlcbiAgICogaGFzIGJlZW4gc2V0LCB0aGUgc3RhdHVzIHdpbGwgYmUgYDIwMCBPS2AuICBJZiBhIHZhbHVlIGZvciB0aGUgYm9keSBoYXNcbiAgICogbm90IGJlZW4gc2V0IHlldCwgdGhlIHN0YXR1cyB3aWxsIGJlIGA0MDQgTm90IEZvdW5kYC4gKi9cbiAgZ2V0IHN0YXR1cygpOiBTdGF0dXMge1xuICAgIGlmICh0aGlzLiNzdGF0dXMpIHtcbiAgICAgIHJldHVybiB0aGlzLiNzdGF0dXM7XG4gICAgfVxuICAgIHJldHVybiB0aGlzLmJvZHkgIT0gbnVsbFxuICAgICAgPyBTdGF0dXMuT0tcbiAgICAgIDogdGhpcy4jYm9keVNldFxuICAgICAgPyBTdGF0dXMuTm9Db250ZW50XG4gICAgICA6IFN0YXR1cy5Ob3RGb3VuZDtcbiAgfVxuXG4gIC8qKiBUaGUgSFRUUCBzdGF0dXMgb2YgdGhlIHJlc3BvbnNlLiAgSWYgdGhpcyBoYXMgbm90IGJlZW4gZXhwbGljaXRseSBzZXQsXG4gICAqIHJlYWRpbmcgdGhlIHZhbHVlIHdpbGwgcmV0dXJuIHdoYXQgd291bGQgYmUgdGhlIHZhbHVlIG9mIHN0YXR1cyBpZiB0aGVcbiAgICogcmVzcG9uc2Ugd2VyZSBzZW50IGF0IHRoaXMgcG9pbnQgaW4gcHJvY2Vzc2luZyB0aGUgbWlkZGxld2FyZS4gIElmIHRoZSBib2R5XG4gICAqIGhhcyBiZWVuIHNldCwgdGhlIHN0YXR1cyB3aWxsIGJlIGAyMDAgT0tgLiAgSWYgYSB2YWx1ZSBmb3IgdGhlIGJvZHkgaGFzXG4gICAqIG5vdCBiZWVuIHNldCB5ZXQsIHRoZSBzdGF0dXMgd2lsbCBiZSBgNDA0IE5vdCBGb3VuZGAuICovXG4gIHNldCBzdGF0dXModmFsdWU6IFN0YXR1cykge1xuICAgIGlmICghdGhpcy4jd3JpdGFibGUpIHtcbiAgICAgIHRocm93IG5ldyBFcnJvcihcIlRoZSByZXNwb25zZSBpcyBub3Qgd3JpdGFibGUuXCIpO1xuICAgIH1cbiAgICB0aGlzLiNzdGF0dXMgPSB2YWx1ZTtcbiAgfVxuXG4gIC8qKiBUaGUgbWVkaWEgdHlwZSwgb3IgZXh0ZW5zaW9uIG9mIHRoZSByZXNwb25zZS4gIFNldHRpbmcgdGhpcyB2YWx1ZSB3aWxsXG4gICAqIGVuc3VyZSBhbiBhcHByb3ByaWF0ZSBgQ29udGVudC1UeXBlYCBoZWFkZXIgaXMgYWRkZWQgdG8gdGhlIHJlc3BvbnNlLiAqL1xuICBnZXQgdHlwZSgpOiBzdHJpbmcgfCB1bmRlZmluZWQge1xuICAgIHJldHVybiB0aGlzLiN0eXBlO1xuICB9XG4gIC8qKiBUaGUgbWVkaWEgdHlwZSwgb3IgZXh0ZW5zaW9uIG9mIHRoZSByZXNwb25zZS4gIFNldHRpbmcgdGhpcyB2YWx1ZSB3aWxsXG4gICAqIGVuc3VyZSBhbiBhcHByb3ByaWF0ZSBgQ29udGVudC1UeXBlYCBoZWFkZXIgaXMgYWRkZWQgdG8gdGhlIHJlc3BvbnNlLiAqL1xuICBzZXQgdHlwZSh2YWx1ZTogc3RyaW5nIHwgdW5kZWZpbmVkKSB7XG4gICAgaWYgKCF0aGlzLiN3cml0YWJsZSkge1xuICAgICAgdGhyb3cgbmV3IEVycm9yKFwiVGhlIHJlc3BvbnNlIGlzIG5vdCB3cml0YWJsZS5cIik7XG4gICAgfVxuICAgIHRoaXMuI3R5cGUgPSB2YWx1ZTtcbiAgfVxuXG4gIC8qKiBBIHJlYWQtb25seSBwcm9wZXJ0eSB3aGljaCBkZXRlcm1pbmVzIGlmIHRoZSByZXNwb25zZSBpcyB3cml0YWJsZSBvciBub3QuXG4gICAqIE9uY2UgdGhlIHJlc3BvbnNlIGhhcyBiZWVuIHByb2Nlc3NlZCwgdGhpcyB2YWx1ZSBpcyBzZXQgdG8gYGZhbHNlYC4gKi9cbiAgZ2V0IHdyaXRhYmxlKCk6IGJvb2xlYW4ge1xuICAgIHJldHVybiB0aGlzLiN3cml0YWJsZTtcbiAgfVxuXG4gIGNvbnN0cnVjdG9yKHJlcXVlc3Q6IFJlcXVlc3QpIHtcbiAgICB0aGlzLiNyZXF1ZXN0ID0gcmVxdWVzdDtcbiAgfVxuXG4gIC8qKiBBZGQgYSByZXNvdXJjZSB0byB0aGUgbGlzdCBvZiByZXNvdXJjZXMgdGhhdCB3aWxsIGJlIGNsb3NlZCB3aGVuIHRoZVxuICAgKiByZXF1ZXN0IGlzIGRlc3Ryb3llZC4gKi9cbiAgYWRkUmVzb3VyY2UocmlkOiBudW1iZXIpOiB2b2lkIHtcbiAgICB0aGlzLiNyZXNvdXJjZXMucHVzaChyaWQpO1xuICB9XG5cbiAgLyoqIFJlbGVhc2UgYW55IHJlc291cmNlcyB0aGF0IGFyZSBiZWluZyB0cmFja2VkIGJ5IHRoZSByZXNwb25zZS5cbiAgICpcbiAgICogQHBhcmFtIGNsb3NlUmVzb3VyY2VzIGNsb3NlIGFueSByZXNvdXJjZSBJRHMgcmVnaXN0ZXJlZCB3aXRoIHRoZSByZXNwb25zZVxuICAgKi9cbiAgZGVzdHJveShjbG9zZVJlc291cmNlcyA9IHRydWUpOiB2b2lkIHtcbiAgICB0aGlzLiN3cml0YWJsZSA9IGZhbHNlO1xuICAgIHRoaXMuI2JvZHkgPSB1bmRlZmluZWQ7XG4gICAgdGhpcy4jZG9tUmVzcG9uc2UgPSB1bmRlZmluZWQ7XG4gICAgaWYgKGNsb3NlUmVzb3VyY2VzKSB7XG4gICAgICBmb3IgKGNvbnN0IHJpZCBvZiB0aGlzLiNyZXNvdXJjZXMpIHtcbiAgICAgICAgdHJ5IHtcbiAgICAgICAgICBEZW5vLmNsb3NlKHJpZCk7XG4gICAgICAgIH0gY2F0Y2gge1xuICAgICAgICAgIC8vIHdlIGRvbid0IGNhcmUgYWJvdXQgZXJyb3JzIGhlcmVcbiAgICAgICAgfVxuICAgICAgfVxuICAgIH1cbiAgfVxuXG4gIC8qKiBTZXRzIHRoZSByZXNwb25zZSB0byByZWRpcmVjdCB0byB0aGUgc3VwcGxpZWQgYHVybGAuXG4gICAqXG4gICAqIElmIHRoZSBgLnN0YXR1c2AgaXMgbm90IGN1cnJlbnRseSBhIHJlZGlyZWN0IHN0YXR1cywgdGhlIHN0YXR1cyB3aWxsIGJlIHNldFxuICAgKiB0byBgMzAyIEZvdW5kYC5cbiAgICpcbiAgICogVGhlIGJvZHkgd2lsbCBiZSBzZXQgdG8gYSBtZXNzYWdlIGluZGljYXRpbmcgdGhlIHJlZGlyZWN0aW9uIGlzIG9jY3VycmluZy5cbiAgICovXG4gIHJlZGlyZWN0KHVybDogc3RyaW5nIHwgVVJMKTogdm9pZDtcbiAgLyoqIFNldHMgdGhlIHJlc3BvbnNlIHRvIHJlZGlyZWN0IGJhY2sgdG8gdGhlIHJlZmVycmVyIGlmIGF2YWlsYWJsZSwgd2l0aCBhblxuICAgKiBvcHRpb25hbCBgYWx0YCBVUkwgaWYgdGhlcmUgaXMgbm8gcmVmZXJyZXIgaGVhZGVyIG9uIHRoZSByZXF1ZXN0LiAgSWYgdGhlcmVcbiAgICogaXMgbm8gcmVmZXJyZXIgaGVhZGVyLCBub3IgYW4gYGFsdGAgcGFyYW1ldGVyLCB0aGUgcmVkaXJlY3QgaXMgc2V0IHRvIGAvYC5cbiAgICpcbiAgICogSWYgdGhlIGAuc3RhdHVzYCBpcyBub3QgY3VycmVudGx5IGEgcmVkaXJlY3Qgc3RhdHVzLCB0aGUgc3RhdHVzIHdpbGwgYmUgc2V0XG4gICAqIHRvIGAzMDIgRm91bmRgLlxuICAgKlxuICAgKiBUaGUgYm9keSB3aWxsIGJlIHNldCB0byBhIG1lc3NhZ2UgaW5kaWNhdGluZyB0aGUgcmVkaXJlY3Rpb24gaXMgb2NjdXJyaW5nLlxuICAgKi9cbiAgcmVkaXJlY3QodXJsOiB0eXBlb2YgUkVESVJFQ1RfQkFDSywgYWx0Pzogc3RyaW5nIHwgVVJMKTogdm9pZDtcbiAgcmVkaXJlY3QoXG4gICAgdXJsOiBzdHJpbmcgfCBVUkwgfCB0eXBlb2YgUkVESVJFQ1RfQkFDSyxcbiAgICBhbHQ6IHN0cmluZyB8IFVSTCA9IFwiL1wiLFxuICApOiB2b2lkIHtcbiAgICBpZiAodXJsID09PSBSRURJUkVDVF9CQUNLKSB7XG4gICAgICB1cmwgPSB0aGlzLiNyZXF1ZXN0LmhlYWRlcnMuZ2V0KFwiUmVmZXJlclwiKSA/PyBTdHJpbmcoYWx0KTtcbiAgICB9IGVsc2UgaWYgKHR5cGVvZiB1cmwgPT09IFwib2JqZWN0XCIpIHtcbiAgICAgIHVybCA9IFN0cmluZyh1cmwpO1xuICAgIH1cbiAgICB0aGlzLmhlYWRlcnMuc2V0KFwiTG9jYXRpb25cIiwgZW5jb2RlVXJsKHVybCkpO1xuICAgIGlmICghdGhpcy5zdGF0dXMgfHwgIWlzUmVkaXJlY3RTdGF0dXModGhpcy5zdGF0dXMpKSB7XG4gICAgICB0aGlzLnN0YXR1cyA9IFN0YXR1cy5Gb3VuZDtcbiAgICB9XG5cbiAgICBpZiAodGhpcy4jcmVxdWVzdC5hY2NlcHRzKFwiaHRtbFwiKSkge1xuICAgICAgdXJsID0gZW5jb2RlVVJJKHVybCk7XG4gICAgICB0aGlzLnR5cGUgPSBcInRleHQvaHRtbDsgY2hhcnNldD11dGYtOFwiO1xuICAgICAgdGhpcy5ib2R5ID0gYFJlZGlyZWN0aW5nIHRvIDxhIGhyZWY9XCIke3VybH1cIj4ke3VybH08L2E+LmA7XG4gICAgICByZXR1cm47XG4gICAgfVxuICAgIHRoaXMudHlwZSA9IFwidGV4dC9wbGFpbjsgY2hhcnNldD11dGYtOFwiO1xuICAgIHRoaXMuYm9keSA9IGBSZWRpcmVjdGluZyB0byAke3VybH0uYDtcbiAgfVxuXG4gIGFzeW5jIHRvRG9tUmVzcG9uc2UoKTogUHJvbWlzZTxnbG9iYWxUaGlzLlJlc3BvbnNlPiB7XG4gICAgaWYgKHRoaXMuI2RvbVJlc3BvbnNlKSB7XG4gICAgICByZXR1cm4gdGhpcy4jZG9tUmVzcG9uc2U7XG4gICAgfVxuXG4gICAgY29uc3QgYm9keUluaXQgPSBhd2FpdCB0aGlzLiNnZXRCb2R5SW5pdCgpO1xuXG4gICAgdGhpcy4jc2V0Q29udGVudFR5cGUoKTtcblxuICAgIGNvbnN0IHsgaGVhZGVycyB9ID0gdGhpcztcblxuICAgIC8vIElmIHRoZXJlIGlzIG5vIGJvZHkgYW5kIG5vIGNvbnRlbnQgdHlwZSBhbmQgbm8gc2V0IGxlbmd0aCwgdGhlbiBzZXQgdGhlXG4gICAgLy8gY29udGVudCBsZW5ndGggdG8gMFxuICAgIGlmIChcbiAgICAgICEoXG4gICAgICAgIGJvZHlJbml0IHx8XG4gICAgICAgIGhlYWRlcnMuaGFzKFwiQ29udGVudC1UeXBlXCIpIHx8XG4gICAgICAgIGhlYWRlcnMuaGFzKFwiQ29udGVudC1MZW5ndGhcIilcbiAgICAgIClcbiAgICApIHtcbiAgICAgIGhlYWRlcnMuYXBwZW5kKFwiQ29udGVudC1MZW5ndGhcIiwgXCIwXCIpO1xuICAgIH1cblxuICAgIHRoaXMuI3dyaXRhYmxlID0gZmFsc2U7XG5cbiAgICBjb25zdCBzdGF0dXMgPSB0aGlzLnN0YXR1cztcbiAgICBjb25zdCByZXNwb25zZUluaXQ6IFJlc3BvbnNlSW5pdCA9IHtcbiAgICAgIGhlYWRlcnMsXG4gICAgICBzdGF0dXMsXG4gICAgICBzdGF0dXNUZXh0OiBTVEFUVVNfVEVYVC5nZXQoc3RhdHVzKSxcbiAgICB9O1xuXG4gICAgcmV0dXJuIHRoaXMuI2RvbVJlc3BvbnNlID0gbmV3IERvbVJlc3BvbnNlKGJvZHlJbml0LCByZXNwb25zZUluaXQpO1xuICB9XG5cbiAgW1N5bWJvbC5mb3IoXCJEZW5vLmN1c3RvbUluc3BlY3RcIildKGluc3BlY3Q6ICh2YWx1ZTogdW5rbm93bikgPT4gc3RyaW5nKSB7XG4gICAgY29uc3QgeyBib2R5LCBoZWFkZXJzLCBzdGF0dXMsIHR5cGUsIHdyaXRhYmxlIH0gPSB0aGlzO1xuICAgIHJldHVybiBgJHt0aGlzLmNvbnN0cnVjdG9yLm5hbWV9ICR7XG4gICAgICBpbnNwZWN0KHsgYm9keSwgaGVhZGVycywgc3RhdHVzLCB0eXBlLCB3cml0YWJsZSB9KVxuICAgIH1gO1xuICB9XG5cbiAgW1N5bWJvbC5mb3IoXCJub2RlanMudXRpbC5pbnNwZWN0LmN1c3RvbVwiKV0oXG4gICAgZGVwdGg6IG51bWJlcixcbiAgICAvLyBkZW5vLWxpbnQtaWdub3JlIG5vLWV4cGxpY2l0LWFueVxuICAgIG9wdGlvbnM6IGFueSxcbiAgICBpbnNwZWN0OiAodmFsdWU6IHVua25vd24sIG9wdGlvbnM/OiB1bmtub3duKSA9PiBzdHJpbmcsXG4gICkge1xuICAgIGlmIChkZXB0aCA8IDApIHtcbiAgICAgIHJldHVybiBvcHRpb25zLnN0eWxpemUoYFske3RoaXMuY29uc3RydWN0b3IubmFtZX1dYCwgXCJzcGVjaWFsXCIpO1xuICAgIH1cblxuICAgIGNvbnN0IG5ld09wdGlvbnMgPSBPYmplY3QuYXNzaWduKHt9LCBvcHRpb25zLCB7XG4gICAgICBkZXB0aDogb3B0aW9ucy5kZXB0aCA9PT0gbnVsbCA/IG51bGwgOiBvcHRpb25zLmRlcHRoIC0gMSxcbiAgICB9KTtcbiAgICBjb25zdCB7IGJvZHksIGhlYWRlcnMsIHN0YXR1cywgdHlwZSwgd3JpdGFibGUgfSA9IHRoaXM7XG4gICAgcmV0dXJuIGAke29wdGlvbnMuc3R5bGl6ZSh0aGlzLmNvbnN0cnVjdG9yLm5hbWUsIFwic3BlY2lhbFwiKX0gJHtcbiAgICAgIGluc3BlY3QoXG4gICAgICAgIHsgYm9keSwgaGVhZGVycywgc3RhdHVzLCB0eXBlLCB3cml0YWJsZSB9LFxuICAgICAgICBuZXdPcHRpb25zLFxuICAgICAgKVxuICAgIH1gO1xuICB9XG59XG4iXSwibmFtZXMiOltdLCJtYXBwaW5ncyI6IkFBQUEseUVBQXlFO0FBRXpFLFNBQVMsV0FBVyxFQUFFLE1BQU0sRUFBRSxXQUFXLFFBQVEsV0FBVyxDQUFDO0FBQzdELFNBQVMsV0FBVyxRQUFRLGlDQUFpQyxDQUFDO0FBRTlELFNBQ0UsVUFBVSxFQUNWLFNBQVMsRUFDVCxlQUFlLEVBQ2YsTUFBTSxFQUNOLFFBQVEsRUFDUixnQkFBZ0IsRUFDaEIsK0JBQStCLEVBQy9CLHdCQUF3QixFQUN4Qix5QkFBeUIsUUFDcEIsV0FBVyxDQUFDO0FBY25COzs7Ozs7Ozs7Ozs7Ozs7O0dBZ0JHLENBQ0gsT0FBTyxNQUFNLGFBQWEsR0FBRyxNQUFNLENBQUMsb0JBQW9CLENBQUMsQ0FBQztBQUUxRCxPQUFPLGVBQWUscUJBQXFCLENBQ3pDLElBQXlDLEVBQ3pDLElBQWEsRUFDbUQ7SUFDaEUsSUFBSSxNQUFNLEFBQWlDLEFBQUM7SUFDNUMsSUFBSSxVQUFVLENBQUMsUUFBUSxDQUFDLE9BQU8sSUFBSSxDQUFDLEVBQUU7UUFDcEMsTUFBTSxHQUFHLE1BQU0sQ0FBQyxJQUFJLENBQUMsQ0FBQztRQUN0QixJQUFJLEdBQUcsSUFBSSxJQUFJLENBQUMsTUFBTSxDQUFDLE1BQU0sQ0FBQyxHQUFHLE1BQU0sR0FBRyxZQUFZLENBQUMsQ0FBQztLQUN6RCxNQUFNLElBQUksUUFBUSxDQUFDLElBQUksQ0FBQyxFQUFFO1FBQ3pCLE1BQU0sR0FBRyx3QkFBd0IsQ0FBQyxJQUFJLENBQUMsQ0FBQztLQUN6QyxNQUFNLElBQ0wsV0FBVyxDQUFDLE1BQU0sQ0FBQyxJQUFJLENBQUMsSUFBSSxJQUFJLFlBQVksV0FBVyxJQUN2RCxJQUFJLFlBQVksSUFBSSxJQUFJLElBQUksWUFBWSxlQUFlLEVBQ3ZEO1FBQ0EsbUNBQW1DO1FBQ25DLE1BQU0sR0FBRyxJQUFJLEFBQU8sQ0FBQztLQUN0QixNQUFNLElBQUksSUFBSSxZQUFZLGNBQWMsRUFBRTtRQUN6QyxNQUFNLEdBQUcsSUFBSSxDQUFDLFdBQVcsQ0FBQyxJQUFJLHlCQUF5QixFQUFFLENBQUMsQ0FBQztLQUM1RCxNQUFNLElBQUksSUFBSSxZQUFZLFFBQVEsRUFBRTtRQUNuQyxNQUFNLEdBQUcsSUFBSSxDQUFDO1FBQ2QsSUFBSSxHQUFHLHFCQUFxQixDQUFDO0tBQzlCLE1BQU0sSUFBSSxlQUFlLENBQUMsSUFBSSxDQUFDLEVBQUU7UUFDaEMsTUFBTSxHQUFHLCtCQUErQixDQUFDLElBQUksQ0FBQyxDQUFDO0tBQ2hELE1BQU0sSUFBSSxJQUFJLElBQUksT0FBTyxJQUFJLEtBQUssUUFBUSxFQUFFO1FBQzNDLE1BQU0sR0FBRyxJQUFJLENBQUMsU0FBUyxDQUFDLElBQUksQ0FBQyxDQUFDO1FBQzlCLElBQUksR0FBRyxJQUFJLElBQUksTUFBTSxDQUFDO0tBQ3ZCLE1BQU0sSUFBSSxPQUFPLElBQUksS0FBSyxVQUFVLEVBQUU7UUFDckMsTUFBTSxPQUFNLEdBQUcsSUFBSSxDQUFDLElBQUksQ0FBQyxJQUFJLENBQUMsQUFBQztRQUMvQixPQUFPLHFCQUFxQixDQUFDLE1BQU0sT0FBTSxFQUFFLElBQUksQ0FBQyxDQUFDO0tBQ2xELE1BQU0sSUFBSSxJQUFJLEVBQUU7UUFDZixNQUFNLElBQUksU0FBUyxDQUFDLG1EQUFtRCxDQUFDLENBQUM7S0FDMUU7SUFDRCxPQUFPO1FBQUMsTUFBTTtRQUFFLElBQUk7S0FBQyxDQUFDO0NBQ3ZCO0FBRUQ7Ozs7Ozs7Ozs7Ozs7Ozs7OztHQWtCRyxDQUNILE9BQU8sTUFBTSxRQUFRO0lBQ25CLENBQUMsSUFBSSxDQUF1QztJQUM1QyxDQUFDLE9BQU8sR0FBRyxLQUFLLENBQUM7SUFDakIsQ0FBQyxXQUFXLENBQXVCO0lBQ25DLENBQUMsT0FBTyxHQUFHLElBQUksT0FBTyxFQUFFLENBQUM7SUFDekIsQ0FBQyxPQUFPLENBQVU7SUFDbEIsQ0FBQyxTQUFTLEdBQWEsRUFBRSxDQUFDO0lBQzFCLENBQUMsTUFBTSxDQUFVO0lBQ2pCLENBQUMsSUFBSSxDQUFVO0lBQ2YsQ0FBQyxRQUFRLEdBQUcsSUFBSSxDQUFDO0lBRWpCLE1BQU0sQ0FBQyxXQUFXLEdBQTZDO1FBQzdELE1BQU0sQ0FBQyxJQUFJLEVBQUUsSUFBSSxDQUFDLEdBQUcsTUFBTSxxQkFBcUIsQ0FBQyxJQUFJLENBQUMsSUFBSSxFQUFFLElBQUksQ0FBQyxJQUFJLENBQUMsQUFBQztRQUN2RSxJQUFJLENBQUMsSUFBSSxHQUFHLElBQUksQ0FBQztRQUNqQixPQUFPLElBQUksQ0FBQztLQUNiO0lBRUQsQ0FBQSxDQUFDLGNBQWMsR0FBUztRQUN0QixJQUFJLElBQUksQ0FBQyxJQUFJLEVBQUU7WUFDYixNQUFNLGlCQUFpQixHQUFHLFdBQVcsQ0FBQyxJQUFJLENBQUMsSUFBSSxDQUFDLEFBQUM7WUFDakQsSUFBSSxpQkFBaUIsSUFBSSxDQUFDLElBQUksQ0FBQyxPQUFPLENBQUMsR0FBRyxDQUFDLGNBQWMsQ0FBQyxFQUFFO2dCQUMxRCxJQUFJLENBQUMsT0FBTyxDQUFDLE1BQU0sQ0FBQyxjQUFjLEVBQUUsaUJBQWlCLENBQUMsQ0FBQzthQUN4RDtTQUNGO0tBQ0Y7SUFFRDs7OzsyRUFJeUUsQ0FDekUsSUFBSSxJQUFJLEdBQXdDO1FBQzlDLE9BQU8sSUFBSSxDQUFDLENBQUMsSUFBSSxDQUFDO0tBQ25CO0lBRUQ7Ozs7MkVBSXlFLENBQ3pFLElBQUksSUFBSSxDQUFDLEtBQTBDLEVBQUU7UUFDbkQsSUFBSSxDQUFDLElBQUksQ0FBQyxDQUFDLFFBQVEsRUFBRTtZQUNuQixNQUFNLElBQUksS0FBSyxDQUFDLCtCQUErQixDQUFDLENBQUM7U0FDbEQ7UUFDRCxJQUFJLENBQUMsQ0FBQyxPQUFPLEdBQUcsSUFBSSxDQUFDO1FBQ3JCLElBQUksQ0FBQyxDQUFDLElBQUksR0FBRyxLQUFLLENBQUM7S0FDcEI7SUFFRCxxREFBcUQsQ0FDckQsSUFBSSxPQUFPLEdBQVk7UUFDckIsT0FBTyxJQUFJLENBQUMsQ0FBQyxPQUFPLENBQUM7S0FDdEI7SUFFRCxxREFBcUQsQ0FDckQsSUFBSSxPQUFPLENBQUMsS0FBYyxFQUFFO1FBQzFCLElBQUksQ0FBQyxJQUFJLENBQUMsQ0FBQyxRQUFRLEVBQUU7WUFDbkIsTUFBTSxJQUFJLEtBQUssQ0FBQywrQkFBK0IsQ0FBQyxDQUFDO1NBQ2xEO1FBQ0QsSUFBSSxDQUFDLENBQUMsT0FBTyxHQUFHLEtBQUssQ0FBQztLQUN2QjtJQUVEOzs7OzZEQUkyRCxDQUMzRCxJQUFJLE1BQU0sR0FBVztRQUNuQixJQUFJLElBQUksQ0FBQyxDQUFDLE1BQU0sRUFBRTtZQUNoQixPQUFPLElBQUksQ0FBQyxDQUFDLE1BQU0sQ0FBQztTQUNyQjtRQUNELE9BQU8sSUFBSSxDQUFDLElBQUksSUFBSSxJQUFJLEdBQ3BCLE1BQU0sQ0FBQyxFQUFFLEdBQ1QsSUFBSSxDQUFDLENBQUMsT0FBTyxHQUNiLE1BQU0sQ0FBQyxTQUFTLEdBQ2hCLE1BQU0sQ0FBQyxRQUFRLENBQUM7S0FDckI7SUFFRDs7Ozs2REFJMkQsQ0FDM0QsSUFBSSxNQUFNLENBQUMsS0FBYSxFQUFFO1FBQ3hCLElBQUksQ0FBQyxJQUFJLENBQUMsQ0FBQyxRQUFRLEVBQUU7WUFDbkIsTUFBTSxJQUFJLEtBQUssQ0FBQywrQkFBK0IsQ0FBQyxDQUFDO1NBQ2xEO1FBQ0QsSUFBSSxDQUFDLENBQUMsTUFBTSxHQUFHLEtBQUssQ0FBQztLQUN0QjtJQUVEOzZFQUMyRSxDQUMzRSxJQUFJLElBQUksR0FBdUI7UUFDN0IsT0FBTyxJQUFJLENBQUMsQ0FBQyxJQUFJLENBQUM7S0FDbkI7SUFDRDs2RUFDMkUsQ0FDM0UsSUFBSSxJQUFJLENBQUMsS0FBeUIsRUFBRTtRQUNsQyxJQUFJLENBQUMsSUFBSSxDQUFDLENBQUMsUUFBUSxFQUFFO1lBQ25CLE1BQU0sSUFBSSxLQUFLLENBQUMsK0JBQStCLENBQUMsQ0FBQztTQUNsRDtRQUNELElBQUksQ0FBQyxDQUFDLElBQUksR0FBRyxLQUFLLENBQUM7S0FDcEI7SUFFRDsyRUFDeUUsQ0FDekUsSUFBSSxRQUFRLEdBQVk7UUFDdEIsT0FBTyxJQUFJLENBQUMsQ0FBQyxRQUFRLENBQUM7S0FDdkI7SUFFRCxZQUFZLE9BQWdCLENBQUU7UUFDNUIsSUFBSSxDQUFDLENBQUMsT0FBTyxHQUFHLE9BQU8sQ0FBQztLQUN6QjtJQUVEOzZCQUMyQixDQUMzQixXQUFXLENBQUMsR0FBVyxFQUFRO1FBQzdCLElBQUksQ0FBQyxDQUFDLFNBQVMsQ0FBQyxJQUFJLENBQUMsR0FBRyxDQUFDLENBQUM7S0FDM0I7SUFFRDs7O0tBR0csQ0FDSCxPQUFPLENBQUMsY0FBYyxHQUFHLElBQUksRUFBUTtRQUNuQyxJQUFJLENBQUMsQ0FBQyxRQUFRLEdBQUcsS0FBSyxDQUFDO1FBQ3ZCLElBQUksQ0FBQyxDQUFDLElBQUksR0FBRyxTQUFTLENBQUM7UUFDdkIsSUFBSSxDQUFDLENBQUMsV0FBVyxHQUFHLFNBQVMsQ0FBQztRQUM5QixJQUFJLGNBQWMsRUFBRTtZQUNsQixLQUFLLE1BQU0sR0FBRyxJQUFJLElBQUksQ0FBQyxDQUFDLFNBQVMsQ0FBRTtnQkFDakMsSUFBSTtvQkFDRixJQUFJLENBQUMsS0FBSyxDQUFDLEdBQUcsQ0FBQyxDQUFDO2lCQUNqQixDQUFDLE9BQU07Z0JBQ04sa0NBQWtDO2lCQUNuQzthQUNGO1NBQ0Y7S0FDRjtJQW9CRCxRQUFRLENBQ04sR0FBd0MsRUFDeEMsR0FBaUIsR0FBRyxHQUFHLEVBQ2pCO1FBQ04sSUFBSSxHQUFHLEtBQUssYUFBYSxFQUFFO1lBQ3pCLEdBQUcsR0FBRyxJQUFJLENBQUMsQ0FBQyxPQUFPLENBQUMsT0FBTyxDQUFDLEdBQUcsQ0FBQyxTQUFTLENBQUMsSUFBSSxNQUFNLENBQUMsR0FBRyxDQUFDLENBQUM7U0FDM0QsTUFBTSxJQUFJLE9BQU8sR0FBRyxLQUFLLFFBQVEsRUFBRTtZQUNsQyxHQUFHLEdBQUcsTUFBTSxDQUFDLEdBQUcsQ0FBQyxDQUFDO1NBQ25CO1FBQ0QsSUFBSSxDQUFDLE9BQU8sQ0FBQyxHQUFHLENBQUMsVUFBVSxFQUFFLFNBQVMsQ0FBQyxHQUFHLENBQUMsQ0FBQyxDQUFDO1FBQzdDLElBQUksQ0FBQyxJQUFJLENBQUMsTUFBTSxJQUFJLENBQUMsZ0JBQWdCLENBQUMsSUFBSSxDQUFDLE1BQU0sQ0FBQyxFQUFFO1lBQ2xELElBQUksQ0FBQyxNQUFNLEdBQUcsTUFBTSxDQUFDLEtBQUssQ0FBQztTQUM1QjtRQUVELElBQUksSUFBSSxDQUFDLENBQUMsT0FBTyxDQUFDLE9BQU8sQ0FBQyxNQUFNLENBQUMsRUFBRTtZQUNqQyxHQUFHLEdBQUcsU0FBUyxDQUFDLEdBQUcsQ0FBQyxDQUFDO1lBQ3JCLElBQUksQ0FBQyxJQUFJLEdBQUcsMEJBQTBCLENBQUM7WUFDdkMsSUFBSSxDQUFDLElBQUksR0FBRyxDQUFDLHdCQUF3QixFQUFFLEdBQUcsQ0FBQyxFQUFFLEVBQUUsR0FBRyxDQUFDLEtBQUssQ0FBQyxDQUFDO1lBQzFELE9BQU87U0FDUjtRQUNELElBQUksQ0FBQyxJQUFJLEdBQUcsMkJBQTJCLENBQUM7UUFDeEMsSUFBSSxDQUFDLElBQUksR0FBRyxDQUFDLGVBQWUsRUFBRSxHQUFHLENBQUMsQ0FBQyxDQUFDLENBQUM7S0FDdEM7SUFFRCxNQUFNLGFBQWEsR0FBaUM7UUFDbEQsSUFBSSxJQUFJLENBQUMsQ0FBQyxXQUFXLEVBQUU7WUFDckIsT0FBTyxJQUFJLENBQUMsQ0FBQyxXQUFXLENBQUM7U0FDMUI7UUFFRCxNQUFNLFFBQVEsR0FBRyxNQUFNLElBQUksQ0FBQyxDQUFDLFdBQVcsRUFBRSxBQUFDO1FBRTNDLElBQUksQ0FBQyxDQUFDLGNBQWMsRUFBRSxDQUFDO1FBRXZCLE1BQU0sRUFBRSxPQUFPLENBQUEsRUFBRSxHQUFHLElBQUksQUFBQztRQUV6QiwwRUFBMEU7UUFDMUUsc0JBQXNCO1FBQ3RCLElBQ0UsQ0FBQyxDQUNDLFFBQVEsSUFDUixPQUFPLENBQUMsR0FBRyxDQUFDLGNBQWMsQ0FBQyxJQUMzQixPQUFPLENBQUMsR0FBRyxDQUFDLGdCQUFnQixDQUFDLENBQzlCLEVBQ0Q7WUFDQSxPQUFPLENBQUMsTUFBTSxDQUFDLGdCQUFnQixFQUFFLEdBQUcsQ0FBQyxDQUFDO1NBQ3ZDO1FBRUQsSUFBSSxDQUFDLENBQUMsUUFBUSxHQUFHLEtBQUssQ0FBQztRQUV2QixNQUFNLE1BQU0sR0FBRyxJQUFJLENBQUMsTUFBTSxBQUFDO1FBQzNCLE1BQU0sWUFBWSxHQUFpQjtZQUNqQyxPQUFPO1lBQ1AsTUFBTTtZQUNOLFVBQVUsRUFBRSxXQUFXLENBQUMsR0FBRyxDQUFDLE1BQU0sQ0FBQztTQUNwQyxBQUFDO1FBRUYsT0FBTyxJQUFJLENBQUMsQ0FBQyxXQUFXLEdBQUcsSUFBSSxXQUFXLENBQUMsUUFBUSxFQUFFLFlBQVksQ0FBQyxDQUFDO0tBQ3BFO0lBRUQsQ0FBQyxNQUFNLENBQUMsR0FBRyxDQUFDLG9CQUFvQixDQUFDLENBQUMsQ0FBQyxPQUFtQyxFQUFFO1FBQ3RFLE1BQU0sRUFBRSxJQUFJLENBQUEsRUFBRSxPQUFPLENBQUEsRUFBRSxNQUFNLENBQUEsRUFBRSxJQUFJLENBQUEsRUFBRSxRQUFRLENBQUEsRUFBRSxHQUFHLElBQUksQUFBQztRQUN2RCxPQUFPLENBQUMsRUFBRSxJQUFJLENBQUMsV0FBVyxDQUFDLElBQUksQ0FBQyxDQUFDLEVBQy9CLE9BQU8sQ0FBQztZQUFFLElBQUk7WUFBRSxPQUFPO1lBQUUsTUFBTTtZQUFFLElBQUk7WUFBRSxRQUFRO1NBQUUsQ0FBQyxDQUNuRCxDQUFDLENBQUM7S0FDSjtJQUVELENBQUMsTUFBTSxDQUFDLEdBQUcsQ0FBQyw0QkFBNEIsQ0FBQyxDQUFDLENBQ3hDLEtBQWEsRUFDYixtQ0FBbUM7SUFDbkMsT0FBWSxFQUNaLE9BQXNELEVBQ3REO1FBQ0EsSUFBSSxLQUFLLEdBQUcsQ0FBQyxFQUFFO1lBQ2IsT0FBTyxPQUFPLENBQUMsT0FBTyxDQUFDLENBQUMsQ0FBQyxFQUFFLElBQUksQ0FBQyxXQUFXLENBQUMsSUFBSSxDQUFDLENBQUMsQ0FBQyxFQUFFLFNBQVMsQ0FBQyxDQUFDO1NBQ2pFO1FBRUQsTUFBTSxVQUFVLEdBQUcsTUFBTSxDQUFDLE1BQU0sQ0FBQyxFQUFFLEVBQUUsT0FBTyxFQUFFO1lBQzVDLEtBQUssRUFBRSxPQUFPLENBQUMsS0FBSyxLQUFLLElBQUksR0FBRyxJQUFJLEdBQUcsT0FBTyxDQUFDLEtBQUssR0FBRyxDQUFDO1NBQ3pELENBQUMsQUFBQztRQUNILE1BQU0sRUFBRSxJQUFJLENBQUEsRUFBRSxPQUFPLENBQUEsRUFBRSxNQUFNLENBQUEsRUFBRSxJQUFJLENBQUEsRUFBRSxRQUFRLENBQUEsRUFBRSxHQUFHLElBQUksQUFBQztRQUN2RCxPQUFPLENBQUMsRUFBRSxPQUFPLENBQUMsT0FBTyxDQUFDLElBQUksQ0FBQyxXQUFXLENBQUMsSUFBSSxFQUFFLFNBQVMsQ0FBQyxDQUFDLENBQUMsRUFDM0QsT0FBTyxDQUNMO1lBQUUsSUFBSTtZQUFFLE9BQU87WUFBRSxNQUFNO1lBQUUsSUFBSTtZQUFFLFFBQVE7U0FBRSxFQUN6QyxVQUFVLENBQ1gsQ0FDRixDQUFDLENBQUM7S0FDSjtDQUNGIn0=
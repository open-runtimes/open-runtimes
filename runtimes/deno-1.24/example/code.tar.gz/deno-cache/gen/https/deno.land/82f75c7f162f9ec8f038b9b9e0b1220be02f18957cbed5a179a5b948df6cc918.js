// Copyright 2020-2021 the denosaurs team. All rights reserved. MIT license.
import { VERSION } from "../info.ts";
const json = {
    filename: "scripts.json",
    source: String.raw`{
  "$schema": "https://deno.land/x/denon@${VERSION}/schema.json",
  "scripts": {
    "start": {
      "cmd": "deno run app.ts",
      "desc": "run my app.ts file"
    }
  }
}`
};
const yaml = {
    filename: "scripts.yml",
    source: String.raw`scripts:
  start:
    cmd: "deno run app.ts"
    desc: "run my app.ts file"`
};
const typescript = {
    filename: "scripts.config.ts",
    source: String.raw`
import { DenonConfig } from "https://deno.land/x/denon@${VERSION}/mod.ts";

const config: DenonConfig = {
  scripts: {
    start: {
      cmd: "deno run app.ts",
      desc: "run my app.ts file",
    },
  },
};

export default config;`
};
export const templates = {
    json: json,
    yaml: yaml,
    yml: yaml,
    ts: typescript,
    typescript: typescript
};
//# sourceMappingURL=data:application/json;base64,eyJ2ZXJzaW9uIjozLCJzb3VyY2VzIjpbImh0dHBzOi8vZGVuby5sYW5kL3gvZGVub25AMi41LjAvc3JjL3RlbXBsYXRlcy50cyJdLCJzb3VyY2VzQ29udGVudCI6WyIvLyBDb3B5cmlnaHQgMjAyMC0yMDIxIHRoZSBkZW5vc2F1cnMgdGVhbS4gQWxsIHJpZ2h0cyByZXNlcnZlZC4gTUlUIGxpY2Vuc2UuXG5cbmltcG9ydCB7IFZFUlNJT04gfSBmcm9tIFwiLi4vaW5mby50c1wiO1xuXG4vLyBkZW5vLWxpbnQtaWdub3JlLWZpbGVcblxuZXhwb3J0IGludGVyZmFjZSBUZW1wbGF0ZSB7XG4gIGZpbGVuYW1lOiBzdHJpbmc7XG4gIHNvdXJjZTogc3RyaW5nO1xufVxuXG5jb25zdCBqc29uOiBUZW1wbGF0ZSA9IHtcbiAgZmlsZW5hbWU6IFwic2NyaXB0cy5qc29uXCIsXG4gIHNvdXJjZTogU3RyaW5nLnJhd2B7XG4gIFwiJHNjaGVtYVwiOiBcImh0dHBzOi8vZGVuby5sYW5kL3gvZGVub25AJHtWRVJTSU9OfS9zY2hlbWEuanNvblwiLFxuICBcInNjcmlwdHNcIjoge1xuICAgIFwic3RhcnRcIjoge1xuICAgICAgXCJjbWRcIjogXCJkZW5vIHJ1biBhcHAudHNcIixcbiAgICAgIFwiZGVzY1wiOiBcInJ1biBteSBhcHAudHMgZmlsZVwiXG4gICAgfVxuICB9XG59YCxcbn07XG5cbmNvbnN0IHlhbWw6IFRlbXBsYXRlID0ge1xuICBmaWxlbmFtZTogXCJzY3JpcHRzLnltbFwiLFxuICBzb3VyY2U6IFN0cmluZy5yYXdgc2NyaXB0czpcbiAgc3RhcnQ6XG4gICAgY21kOiBcImRlbm8gcnVuIGFwcC50c1wiXG4gICAgZGVzYzogXCJydW4gbXkgYXBwLnRzIGZpbGVcImAsXG59O1xuXG5jb25zdCB0eXBlc2NyaXB0OiBUZW1wbGF0ZSA9IHtcbiAgZmlsZW5hbWU6IFwic2NyaXB0cy5jb25maWcudHNcIixcbiAgc291cmNlOiBTdHJpbmcucmF3YFxuaW1wb3J0IHsgRGVub25Db25maWcgfSBmcm9tIFwiaHR0cHM6Ly9kZW5vLmxhbmQveC9kZW5vbkAke1ZFUlNJT059L21vZC50c1wiO1xuXG5jb25zdCBjb25maWc6IERlbm9uQ29uZmlnID0ge1xuICBzY3JpcHRzOiB7XG4gICAgc3RhcnQ6IHtcbiAgICAgIGNtZDogXCJkZW5vIHJ1biBhcHAudHNcIixcbiAgICAgIGRlc2M6IFwicnVuIG15IGFwcC50cyBmaWxlXCIsXG4gICAgfSxcbiAgfSxcbn07XG5cbmV4cG9ydCBkZWZhdWx0IGNvbmZpZztgLFxufTtcblxuZXhwb3J0IGNvbnN0IHRlbXBsYXRlczogeyBba2V5OiBzdHJpbmddOiBUZW1wbGF0ZSB9ID0ge1xuICBqc29uOiBqc29uLFxuICB5YW1sOiB5YW1sLFxuICB5bWw6IHlhbWwsXG4gIHRzOiB0eXBlc2NyaXB0LFxuICB0eXBlc2NyaXB0OiB0eXBlc2NyaXB0LFxufTtcbiJdLCJuYW1lcyI6W10sIm1hcHBpbmdzIjoiQUFBQSw0RUFBNEU7QUFFNUUsU0FBUyxPQUFPLFFBQVEsWUFBWSxDQUFDO0FBU3JDLE1BQU0sSUFBSSxHQUFhO0lBQ3JCLFFBQVEsRUFBRSxjQUFjO0lBQ3hCLE1BQU0sRUFBRSxNQUFNLENBQUMsR0FBRyxDQUFDO3dDQUNtQixFQUFFLE9BQU8sQ0FBQzs7Ozs7OztDQU9qRCxDQUFDO0NBQ0QsQUFBQztBQUVGLE1BQU0sSUFBSSxHQUFhO0lBQ3JCLFFBQVEsRUFBRSxhQUFhO0lBQ3ZCLE1BQU0sRUFBRSxNQUFNLENBQUMsR0FBRyxDQUFDOzs7OEJBR1MsQ0FBQztDQUM5QixBQUFDO0FBRUYsTUFBTSxVQUFVLEdBQWE7SUFDM0IsUUFBUSxFQUFFLG1CQUFtQjtJQUM3QixNQUFNLEVBQUUsTUFBTSxDQUFDLEdBQUcsQ0FBQzt1REFDa0MsRUFBRSxPQUFPLENBQUM7Ozs7Ozs7Ozs7O3NCQVczQyxDQUFDO0NBQ3RCLEFBQUM7QUFFRixPQUFPLE1BQU0sU0FBUyxHQUFnQztJQUNwRCxJQUFJLEVBQUUsSUFBSTtJQUNWLElBQUksRUFBRSxJQUFJO0lBQ1YsR0FBRyxFQUFFLElBQUk7SUFDVCxFQUFFLEVBQUUsVUFBVTtJQUNkLFVBQVUsRUFBRSxVQUFVO0NBQ3ZCLENBQUMifQ==
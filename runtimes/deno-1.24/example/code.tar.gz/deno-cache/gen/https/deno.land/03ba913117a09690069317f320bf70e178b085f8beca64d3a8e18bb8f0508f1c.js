// Copyright 2018-2022 the oak authors. All rights reserved. MIT license.
import { Context } from "./context.ts";
import { STATUS_TEXT } from "./deps.ts";
import { HttpServer } from "./http_server_native.ts";
import { NativeRequest } from "./http_server_native_request.ts";
import { KeyStack } from "./keyStack.ts";
import { compose } from "./middleware.ts";
import { cloneState } from "./structured_clone.ts";
import { assert, isConn } from "./util.ts";
const ADDR_REGEXP = /^\[?([^\]]*)\]?:([0-9]{1,5})$/;
const DEFAULT_SERVER = HttpServer;
export class ApplicationErrorEvent extends ErrorEvent {
    context;
    constructor(eventInitDict){
        super("error", eventInitDict);
        this.context = eventInitDict.context;
    }
}
function logErrorListener({ error , context  }) {
    if (error instanceof Error) {
        console.error(`[uncaught application error]: ${error.name} - ${error.message}`);
    } else {
        console.error(`[uncaught application error]\n`, error);
    }
    if (context) {
        let url;
        try {
            url = context.request.url.toString();
        } catch  {
            url = "[malformed url]";
        }
        console.error(`\nrequest:`, {
            url,
            method: context.request.method,
            hasBody: context.request.hasBody
        });
        console.error(`response:`, {
            status: context.response.status,
            type: context.response.type,
            hasBody: !!context.response.body,
            writable: context.response.writable
        });
    }
    if (error instanceof Error && error.stack) {
        console.error(`\n${error.stack.split("\n").slice(1).join("\n")}`);
    }
}
export class ApplicationListenEvent extends Event {
    hostname;
    listener;
    port;
    secure;
    serverType;
    constructor(eventInitDict){
        super("listen", eventInitDict);
        this.hostname = eventInitDict.hostname;
        this.listener = eventInitDict.listener;
        this.port = eventInitDict.port;
        this.secure = eventInitDict.secure;
        this.serverType = eventInitDict.serverType;
    }
}
/** A class which registers middleware (via `.use()`) and then processes
 * inbound requests against that middleware (via `.listen()`).
 *
 * The `context.state` can be typed via passing a generic argument when
 * constructing an instance of `Application`. It can also be inferred by setting
 * the {@linkcode ApplicationOptions.state} option when constructing the
 * application.
 *
 * ### Basic example
 *
 * ```ts
 * import { Application } from "https://deno.land/x/oak/mod.ts";
 *
 * const app = new Application();
 *
 * app.use((ctx, next) => {
 *   // called on each request with the context (`ctx`) of the request,
 *   // response, and other data.
 *   // `next()` is use to modify the flow control of the middleware stack.
 * });
 *
 * app.listen({ port: 8080 });
 * ```
 *
 * @template AS the type of the application state which extends
 *              {@linkcode State} and defaults to a simple string record.
 */ // deno-lint-ignore no-explicit-any
export class Application extends EventTarget {
    #composedMiddleware;
    #contextState;
    #keys;
    #middleware = [];
    #serverConstructor;
    /** A set of keys, or an instance of `KeyStack` which will be used to sign
   * cookies read and set by the application to avoid tampering with the
   * cookies. */ get keys() {
        return this.#keys;
    }
    set keys(keys) {
        if (!keys) {
            this.#keys = undefined;
            return;
        } else if (Array.isArray(keys)) {
            this.#keys = new KeyStack(keys);
        } else {
            this.#keys = keys;
        }
    }
    /** If `true`, proxy headers will be trusted when processing requests.  This
   * defaults to `false`. */ proxy;
    /** Generic state of the application, which can be specified by passing the
   * generic argument when constructing:
   *
   *       const app = new Application<{ foo: string }>();
   *
   * Or can be contextually inferred based on setting an initial state object:
   *
   *       const app = new Application({ state: { foo: "bar" } });
   *
   * When a new context is created, the application's state is cloned and the
   * state is unique to that request/response.  Changes can be made to the
   * application state that will be shared with all contexts.
   */ state;
    constructor(options = {}){
        super();
        const { state , keys , proxy , serverConstructor =DEFAULT_SERVER , contextState ="clone" , logErrors =true ,  } = options;
        this.proxy = proxy ?? false;
        this.keys = keys;
        this.state = state ?? {};
        this.#serverConstructor = serverConstructor;
        this.#contextState = contextState;
        if (logErrors) {
            this.addEventListener("error", logErrorListener);
        }
    }
     #getComposed() {
        if (!this.#composedMiddleware) {
            this.#composedMiddleware = compose(this.#middleware);
        }
        return this.#composedMiddleware;
    }
     #getContextState() {
        switch(this.#contextState){
            case "alias":
                return this.state;
            case "clone":
                return cloneState(this.state);
            case "empty":
                return {};
            case "prototype":
                return Object.create(this.state);
        }
    }
    /** Deal with uncaught errors in either the middleware or sending the
   * response. */ // deno-lint-ignore no-explicit-any
     #handleError(context, error) {
        if (!(error instanceof Error)) {
            error = new Error(`non-error thrown: ${JSON.stringify(error)}`);
        }
        const { message  } = error;
        this.dispatchEvent(new ApplicationErrorEvent({
            context,
            message,
            error
        }));
        if (!context.response.writable) {
            return;
        }
        for (const key of [
            ...context.response.headers.keys()
        ]){
            context.response.headers.delete(key);
        }
        if (error.headers && error.headers instanceof Headers) {
            for (const [key1, value] of error.headers){
                context.response.headers.set(key1, value);
            }
        }
        context.response.type = "text";
        const status = context.response.status = Deno.errors && error instanceof Deno.errors.NotFound ? 404 : error.status && typeof error.status === "number" ? error.status : 500;
        context.response.body = error.expose ? error.message : STATUS_TEXT.get(status);
    }
    /** Processing registered middleware on each request. */ async #handleRequest(request, secure, state) {
        const context1 = new Context(this, request, this.#getContextState(), secure);
        let resolve;
        const handlingPromise = new Promise((res)=>resolve = res);
        state.handling.add(handlingPromise);
        if (!state.closing && !state.closed) {
            try {
                await this.#getComposed()(context1);
            } catch (err) {
                this.#handleError(context1, err);
            }
        }
        if (context1.respond === false) {
            context1.response.destroy();
            resolve();
            state.handling.delete(handlingPromise);
            return;
        }
        let closeResources = true;
        let response;
        try {
            closeResources = false;
            response = await context1.response.toDomResponse();
        } catch (err1) {
            this.#handleError(context1, err1);
            response = await context1.response.toDomResponse();
        }
        assert(response);
        try {
            await request.respond(response);
        } catch (err2) {
            this.#handleError(context1, err2);
        } finally{
            context1.response.destroy(closeResources);
            resolve();
            state.handling.delete(handlingPromise);
            if (state.closing) {
                state.server.close();
                state.closed = true;
            }
        }
    }
    /** Add an event listener for an event.  Currently valid event types are
   * `"error"` and `"listen"`. */ addEventListener(type, listener, options) {
        super.addEventListener(type, listener, options);
    }
    /** Handle an individual server request, returning the server response.  This
   * is similar to `.listen()`, but opening the connection and retrieving
   * requests are not the responsibility of the application.  If the generated
   * context gets set to not to respond, then the method resolves with
   * `undefined`, otherwise it resolves with a request that is compatible with
   * `std/http/server`. */ handle = async (request, secureOrConn, secure = false)=>{
        if (!this.#middleware.length) {
            throw new TypeError("There is no middleware to process requests.");
        }
        assert(isConn(secureOrConn) || typeof secureOrConn === "undefined");
        const contextRequest = new NativeRequest({
            request,
            respondWith () {
                return Promise.resolve(undefined);
            }
        }, {
            conn: secureOrConn
        });
        const context = new Context(this, contextRequest, this.#getContextState(), secure);
        try {
            await this.#getComposed()(context);
        } catch (err) {
            this.#handleError(context, err);
        }
        if (context.respond === false) {
            context.response.destroy();
            return;
        }
        try {
            const response = await context.response.toDomResponse();
            context.response.destroy(false);
            return response;
        } catch (err1) {
            this.#handleError(context, err1);
            throw err1;
        }
    };
    async listen(options = {
        port: 0
    }) {
        if (!this.#middleware.length) {
            throw new TypeError("There is no middleware to process requests.");
        }
        if (typeof options === "string") {
            const match = ADDR_REGEXP.exec(options);
            if (!match) {
                throw TypeError(`Invalid address passed: "${options}"`);
            }
            const [, hostname, portStr] = match;
            options = {
                hostname,
                port: parseInt(portStr, 10)
            };
        }
        options = Object.assign({
            port: 0
        }, options);
        const server = new this.#serverConstructor(this, options);
        const { signal  } = options;
        const state = {
            closed: false,
            closing: false,
            handling: new Set(),
            server
        };
        if (signal) {
            signal.addEventListener("abort", ()=>{
                if (!state.handling.size) {
                    server.close();
                    state.closed = true;
                }
                state.closing = true;
            });
        }
        const { secure =false  } = options;
        const serverType = server instanceof HttpServer ? "native" : "custom";
        const listener = server.listen();
        const { hostname: hostname1 , port  } = listener.addr;
        this.dispatchEvent(new ApplicationListenEvent({
            hostname: hostname1,
            listener,
            port,
            secure,
            serverType
        }));
        try {
            for await (const request of server){
                this.#handleRequest(request, secure, state);
            }
            await Promise.all(state.handling);
        } catch (error) {
            const message = error instanceof Error ? error.message : "Application Error";
            this.dispatchEvent(new ApplicationErrorEvent({
                message,
                error
            }));
        }
    }
    use(...middleware) {
        this.#middleware.push(...middleware);
        this.#composedMiddleware = undefined;
        // deno-lint-ignore no-explicit-any
        return this;
    }
    [Symbol.for("Deno.customInspect")](inspect) {
        const { keys , proxy , state  } = this;
        return `${this.constructor.name} ${inspect({
            "#middleware": this.#middleware,
            keys,
            proxy,
            state
        })}`;
    }
    [Symbol.for("nodejs.util.inspect.custom")](depth, // deno-lint-ignore no-explicit-any
    options, inspect) {
        if (depth < 0) {
            return options.stylize(`[${this.constructor.name}]`, "special");
        }
        const newOptions = Object.assign({}, options, {
            depth: options.depth === null ? null : options.depth - 1
        });
        const { keys , proxy , state  } = this;
        return `${options.stylize(this.constructor.name, "special")} ${inspect({
            "#middleware": this.#middleware,
            keys,
            proxy,
            state
        }, newOptions)}`;
    }
}
//# sourceMappingURL=data:application/json;base64,eyJ2ZXJzaW9uIjozLCJzb3VyY2VzIjpbImh0dHBzOi8vZGVuby5sYW5kL3gvb2FrQHYxMC42LjAvYXBwbGljYXRpb24udHMiXSwic291cmNlc0NvbnRlbnQiOlsiLy8gQ29weXJpZ2h0IDIwMTgtMjAyMiB0aGUgb2FrIGF1dGhvcnMuIEFsbCByaWdodHMgcmVzZXJ2ZWQuIE1JVCBsaWNlbnNlLlxuXG5pbXBvcnQgeyBDb250ZXh0IH0gZnJvbSBcIi4vY29udGV4dC50c1wiO1xuaW1wb3J0IHsgU3RhdHVzLCBTVEFUVVNfVEVYVCB9IGZyb20gXCIuL2RlcHMudHNcIjtcbmltcG9ydCB7IEh0dHBTZXJ2ZXIgfSBmcm9tIFwiLi9odHRwX3NlcnZlcl9uYXRpdmUudHNcIjtcbmltcG9ydCB7IE5hdGl2ZVJlcXVlc3QgfSBmcm9tIFwiLi9odHRwX3NlcnZlcl9uYXRpdmVfcmVxdWVzdC50c1wiO1xuaW1wb3J0IHsgS2V5U3RhY2sgfSBmcm9tIFwiLi9rZXlTdGFjay50c1wiO1xuaW1wb3J0IHsgY29tcG9zZSwgTWlkZGxld2FyZSB9IGZyb20gXCIuL21pZGRsZXdhcmUudHNcIjtcbmltcG9ydCB7IGNsb25lU3RhdGUgfSBmcm9tIFwiLi9zdHJ1Y3R1cmVkX2Nsb25lLnRzXCI7XG5pbXBvcnQge1xuICBLZXksXG4gIExpc3RlbmVyLFxuICBTZXJ2ZXIsXG4gIFNlcnZlckNvbnN0cnVjdG9yLFxuICBTZXJ2ZXJSZXF1ZXN0LFxufSBmcm9tIFwiLi90eXBlcy5kLnRzXCI7XG5pbXBvcnQgeyBhc3NlcnQsIGlzQ29ubiB9IGZyb20gXCIuL3V0aWwudHNcIjtcblxuZXhwb3J0IGludGVyZmFjZSBMaXN0ZW5PcHRpb25zQmFzZSB7XG4gIC8qKiBUaGUgcG9ydCB0byBsaXN0ZW4gb24uIElmIG5vdCBzcGVjaWZpZWQsIGRlZmF1bHRzIHRvIGAwYCwgd2hpY2ggYWxsb3dzIHRoZVxuICAgKiBvcGVyYXRpbmcgc3lzdGVtIHRvIGRldGVybWluZSB0aGUgdmFsdWUuICovXG4gIHBvcnQ/OiBudW1iZXI7XG4gIC8qKiBBIGxpdGVyYWwgSVAgYWRkcmVzcyBvciBob3N0IG5hbWUgdGhhdCBjYW4gYmUgcmVzb2x2ZWQgdG8gYW4gSVAgYWRkcmVzcy5cbiAgICogSWYgbm90IHNwZWNpZmllZCwgZGVmYXVsdHMgdG8gYDAuMC4wLjBgLlxuICAgKlxuICAgKiBfX05vdGUgYWJvdXQgYDAuMC4wLjBgX18gV2hpbGUgbGlzdGVuaW5nIGAwLjAuMC4wYCB3b3JrcyBvbiBhbGwgcGxhdGZvcm1zLFxuICAgKiB0aGUgYnJvd3NlcnMgb24gV2luZG93cyBkb24ndCB3b3JrIHdpdGggdGhlIGFkZHJlc3MgYDAuMC4wLjBgLlxuICAgKiBZb3Ugc2hvdWxkIHNob3cgdGhlIG1lc3NhZ2UgbGlrZSBgc2VydmVyIHJ1bm5pbmcgb24gbG9jYWxob3N0OjgwODBgIGluc3RlYWQgb2ZcbiAgICogYHNlcnZlciBydW5uaW5nIG9uIDAuMC4wLjA6ODA4MGAgaWYgeW91ciBwcm9ncmFtIHN1cHBvcnRzIFdpbmRvd3MuICovXG4gIGhvc3RuYW1lPzogc3RyaW5nO1xuICBzZWN1cmU/OiBmYWxzZTtcbiAgLyoqIEFuIG9wdGlvbmFsIGFib3J0IHNpZ25hbCB3aGljaCBjYW4gYmUgdXNlZCB0byBjbG9zZSB0aGUgbGlzdGVuZXIuICovXG4gIHNpZ25hbD86IEFib3J0U2lnbmFsO1xufVxuXG5leHBvcnQgaW50ZXJmYWNlIExpc3Rlbk9wdGlvbnNUbHMgZXh0ZW5kcyBEZW5vLkxpc3RlblRsc09wdGlvbnMge1xuICAvKiogQXBwbGljYXRpb24tTGF5ZXIgUHJvdG9jb2wgTmVnb3RpYXRpb24gKEFMUE4pIHByb3RvY29scyB0byBhbm5vdW5jZSB0b1xuICAgKiB0aGUgY2xpZW50LiBJZiBub3Qgc3BlY2lmaWVkLCBubyBBTFBOIGV4dGVuc2lvbiB3aWxsIGJlIGluY2x1ZGVkIGluIHRoZVxuICAgKiBUTFMgaGFuZHNoYWtlLlxuICAgKlxuICAgKiAqKk5PVEUqKiB0aGlzIGlzIHBhcnQgb2YgdGhlIG5hdGl2ZSBIVFRQIHNlcnZlciBpbiBEZW5vIDEuOSBvciBsYXRlcixcbiAgICogd2hpY2ggcmVxdWlyZXMgdGhlIGAtLXVuc3RhYmxlYCBmbGFnIHRvIGJlIGF2YWlsYWJsZS5cbiAgICovXG4gIGFscG5Qcm90b2NvbHM/OiBzdHJpbmdbXTtcbiAgc2VjdXJlOiB0cnVlO1xuICAvKiogQW4gb3B0aW9uYWwgYWJvcnQgc2lnbmFsIHdoaWNoIGNhbiBiZSB1c2VkIHRvIGNsb3NlIHRoZSBsaXN0ZW5lci4gKi9cbiAgc2lnbmFsPzogQWJvcnRTaWduYWw7XG59XG5cbmV4cG9ydCBpbnRlcmZhY2UgSGFuZGxlTWV0aG9kIHtcbiAgLyoqIEhhbmRsZSBhbiBpbmRpdmlkdWFsIHNlcnZlciByZXF1ZXN0LCByZXR1cm5pbmcgdGhlIHNlcnZlciByZXNwb25zZS4gIFRoaXNcbiAgICogaXMgc2ltaWxhciB0byBgLmxpc3RlbigpYCwgYnV0IG9wZW5pbmcgdGhlIGNvbm5lY3Rpb24gYW5kIHJldHJpZXZpbmdcbiAgICogcmVxdWVzdHMgYXJlIG5vdCB0aGUgcmVzcG9uc2liaWxpdHkgb2YgdGhlIGFwcGxpY2F0aW9uLiAgSWYgdGhlIGdlbmVyYXRlZFxuICAgKiBjb250ZXh0IGdldHMgc2V0IHRvIG5vdCB0byByZXNwb25kLCB0aGVuIHRoZSBtZXRob2QgcmVzb2x2ZXMgd2l0aFxuICAgKiBgdW5kZWZpbmVkYCwgb3RoZXJ3aXNlIGl0IHJlc29sdmVzIHdpdGggYSBET00gYFJlc3BvbnNlYCBvYmplY3QuICovXG4gIChcbiAgICByZXF1ZXN0OiBSZXF1ZXN0LFxuICAgIGNvbm4/OiBEZW5vLkNvbm4sXG4gICAgc2VjdXJlPzogYm9vbGVhbixcbiAgKTogUHJvbWlzZTxSZXNwb25zZSB8IHVuZGVmaW5lZD47XG59XG5cbmV4cG9ydCB0eXBlIExpc3Rlbk9wdGlvbnMgPSBMaXN0ZW5PcHRpb25zVGxzIHwgTGlzdGVuT3B0aW9uc0Jhc2U7XG5cbmludGVyZmFjZSBBcHBsaWNhdGlvbkVycm9yRXZlbnRMaXN0ZW5lcjxTIGV4dGVuZHMgQVMsIEFTPiB7XG4gIChldnQ6IEFwcGxpY2F0aW9uRXJyb3JFdmVudDxTLCBBUz4pOiB2b2lkIHwgUHJvbWlzZTx2b2lkPjtcbn1cblxuaW50ZXJmYWNlIEFwcGxpY2F0aW9uRXJyb3JFdmVudExpc3RlbmVyT2JqZWN0PFMgZXh0ZW5kcyBBUywgQVM+IHtcbiAgaGFuZGxlRXZlbnQoZXZ0OiBBcHBsaWNhdGlvbkVycm9yRXZlbnQ8UywgQVM+KTogdm9pZCB8IFByb21pc2U8dm9pZD47XG59XG5cbmludGVyZmFjZSBBcHBsaWNhdGlvbkVycm9yRXZlbnRJbml0PFMgZXh0ZW5kcyBBUywgQVMgZXh0ZW5kcyBTdGF0ZT5cbiAgZXh0ZW5kcyBFcnJvckV2ZW50SW5pdCB7XG4gIGNvbnRleHQ/OiBDb250ZXh0PFMsIEFTPjtcbn1cblxudHlwZSBBcHBsaWNhdGlvbkVycm9yRXZlbnRMaXN0ZW5lck9yRXZlbnRMaXN0ZW5lck9iamVjdDxTIGV4dGVuZHMgQVMsIEFTPiA9XG4gIHwgQXBwbGljYXRpb25FcnJvckV2ZW50TGlzdGVuZXI8UywgQVM+XG4gIHwgQXBwbGljYXRpb25FcnJvckV2ZW50TGlzdGVuZXJPYmplY3Q8UywgQVM+O1xuXG5pbnRlcmZhY2UgQXBwbGljYXRpb25MaXN0ZW5FdmVudExpc3RlbmVyIHtcbiAgKGV2dDogQXBwbGljYXRpb25MaXN0ZW5FdmVudCk6IHZvaWQgfCBQcm9taXNlPHZvaWQ+O1xufVxuXG5pbnRlcmZhY2UgQXBwbGljYXRpb25MaXN0ZW5FdmVudExpc3RlbmVyT2JqZWN0IHtcbiAgaGFuZGxlRXZlbnQoZXZ0OiBBcHBsaWNhdGlvbkxpc3RlbkV2ZW50KTogdm9pZCB8IFByb21pc2U8dm9pZD47XG59XG5cbmludGVyZmFjZSBBcHBsaWNhdGlvbkxpc3RlbkV2ZW50SW5pdCBleHRlbmRzIEV2ZW50SW5pdCB7XG4gIGhvc3RuYW1lOiBzdHJpbmc7XG4gIGxpc3RlbmVyOiBMaXN0ZW5lcjtcbiAgcG9ydDogbnVtYmVyO1xuICBzZWN1cmU6IGJvb2xlYW47XG4gIHNlcnZlclR5cGU6IFwibmF0aXZlXCIgfCBcImN1c3RvbVwiO1xufVxuXG50eXBlIEFwcGxpY2F0aW9uTGlzdGVuRXZlbnRMaXN0ZW5lck9yRXZlbnRMaXN0ZW5lck9iamVjdCA9XG4gIHwgQXBwbGljYXRpb25MaXN0ZW5FdmVudExpc3RlbmVyXG4gIHwgQXBwbGljYXRpb25MaXN0ZW5FdmVudExpc3RlbmVyT2JqZWN0O1xuXG4vKiogQXZhaWxhYmxlIG9wdGlvbnMgdGhhdCBhcmUgdXNlZCB3aGVuIGNyZWF0aW5nIGEgbmV3IGluc3RhbmNlIG9mXG4gKiB7QGxpbmtjb2RlIEFwcGxpY2F0aW9ufS4gKi9cbmV4cG9ydCBpbnRlcmZhY2UgQXBwbGljYXRpb25PcHRpb25zPFMsIFIgZXh0ZW5kcyBTZXJ2ZXJSZXF1ZXN0PiB7XG4gIC8qKiBEZXRlcm1pbmUgaG93IHdoZW4gY3JlYXRpbmcgYSBuZXcgY29udGV4dCwgdGhlIHN0YXRlIGZyb20gdGhlIGFwcGxpY2F0aW9uXG4gICAqIHNob3VsZCBiZSBhcHBsaWVkLiBBIHZhbHVlIG9mIGBcImNsb25lXCJgIHdpbGwgc2V0IHRoZSBzdGF0ZSBhcyBhIGNsb25lIG9mXG4gICAqIHRoZSBhcHAgc3RhdGUuIEFueSBub24tY2xvbmVhYmxlIG9yIG5vbi1lbnVtZXJhYmxlIHByb3BlcnRpZXMgd2lsbCBub3QgYmVcbiAgICogY29waWVkLiBBIHZhbHVlIG9mIGBcInByb3RvdHlwZVwiYCBtZWFucyB0aGF0IHRoZSBhcHBsaWNhdGlvbidzIHN0YXRlIHdpbGwgYmVcbiAgICogdXNlZCBhcyB0aGUgcHJvdG90eXBlIG9mIHRoZSB0aGUgY29udGV4dCdzIHN0YXRlLCBtZWFuaW5nIHNoYWxsb3dcbiAgICogcHJvcGVydGllcyBvbiB0aGUgY29udGV4dCdzIHN0YXRlIHdpbGwgbm90IGJlIHJlZmxlY3RlZCBpbiB0aGVcbiAgICogYXBwbGljYXRpb24ncyBzdGF0ZS4gQSB2YWx1ZSBvZiBgXCJhbGlhc1wiYCBtZWFucyB0aGF0IGFwcGxpY2F0aW9uJ3MgYC5zdGF0ZWBcbiAgICogYW5kIHRoZSBjb250ZXh0J3MgYC5zdGF0ZWAgd2lsbCBiZSBhIHJlZmVyZW5jZSB0byB0aGUgc2FtZSBvYmplY3QuIEEgdmFsdWVcbiAgICogb2YgYFwiZW1wdHlcImAgd2lsbCBpbml0aWFsaXplIHRoZSBjb250ZXh0J3MgYC5zdGF0ZWAgd2l0aCBhbiBlbXB0eSBvYmplY3QuXG4gICAqXG4gICAqIFRoZSBkZWZhdWx0IHZhbHVlIGlzIGBcImNsb25lXCJgLlxuICAgKi9cbiAgY29udGV4dFN0YXRlPzogXCJjbG9uZVwiIHwgXCJwcm90b3R5cGVcIiB8IFwiYWxpYXNcIiB8IFwiZW1wdHlcIjtcblxuICAvKiogQW4gaW5pdGlhbCBzZXQgb2Yga2V5cyAob3IgaW5zdGFuY2Ugb2Yge0BsaW5rY29kZSBLZXlTdGFja30pIHRvIGJlIHVzZWQgZm9yIHNpZ25pbmdcbiAgICogY29va2llcyBwcm9kdWNlZCBieSB0aGUgYXBwbGljYXRpb24uICovXG4gIGtleXM/OiBLZXlTdGFjayB8IEtleVtdO1xuXG4gIC8qKiBJZiBgdHJ1ZWAsIGFueSBlcnJvcnMgaGFuZGxlZCBieSB0aGUgYXBwbGljYXRpb24gd2lsbCBiZSBsb2dnZWQgdG8gdGhlXG4gICAqIHN0ZGVyci4gSWYgYGZhbHNlYCBub3RoaW5nIHdpbGwgYmUgbG9nZ2VkLiBUaGUgZGVmYXVsdCBpcyBgdHJ1ZWAuXG4gICAqXG4gICAqIEFsbCBlcnJvcnMgYXJlIGF2YWlsYWJsZSBhcyBldmVudHMgb24gdGhlIGFwcGxpY2F0aW9uIG9mIHR5cGUgYFwiZXJyb3JcImAgYW5kXG4gICAqIGNhbiBiZSBhY2Nlc3NlZCBmb3IgY3VzdG9tIGxvZ2dpbmcvYXBwbGljYXRpb24gbWFuYWdlbWVudCB2aWEgYWRkaW5nIGFuXG4gICAqIGV2ZW50IGxpc3RlbmVyIHRvIHRoZSBhcHBsaWNhdGlvbjpcbiAgICpcbiAgICogYGBgdHNcbiAgICogY29uc3QgYXBwID0gbmV3IEFwcGxpY2F0aW9uKHsgbG9nRXJyb3JzOiBmYWxzZSB9KTtcbiAgICogYXBwLmFkZEV2ZW50TGlzdGVuZXIoXCJlcnJvclwiLCAoZXZ0KSA9PiB7XG4gICAqICAgLy8gZXZ0LmVycm9yIHdpbGwgY29udGFpbiB3aGF0IGVycm9yIHdhcyB0aHJvd25cbiAgICogfSk7XG4gICAqIGBgYFxuICAgKi9cbiAgbG9nRXJyb3JzPzogYm9vbGVhbjtcblxuICAvKiogSWYgc2V0IHRvIGB0cnVlYCwgcHJveHkgaGVhZGVycyB3aWxsIGJlIHRydXN0ZWQgd2hlbiBwcm9jZXNzaW5nIHJlcXVlc3RzLlxuICAgKiBUaGlzIGRlZmF1bHRzIHRvIGBmYWxzZWAuICovXG4gIHByb3h5PzogYm9vbGVhbjtcblxuICAvKiogQSBzZXJ2ZXIgY29uc3RydWN0b3IgdG8gdXNlIGluc3RlYWQgb2YgdGhlIGRlZmF1bHQgc2VydmVyIGZvciByZWNlaXZpbmdcbiAgICogcmVxdWVzdHMuXG4gICAqXG4gICAqIEdlbmVyYWxseSB0aGlzIGlzIG9ubHkgdXNlZCBmb3IgdGVzdGluZy4gKi9cbiAgc2VydmVyQ29uc3RydWN0b3I/OiBTZXJ2ZXJDb25zdHJ1Y3RvcjxSPjtcblxuICAvKiogVGhlIGluaXRpYWwgc3RhdGUgb2JqZWN0IGZvciB0aGUgYXBwbGljYXRpb24sIG9mIHdoaWNoIHRoZSB0eXBlIGNhbiBiZVxuICAgKiB1c2VkIHRvIGluZmVyIHRoZSB0eXBlIG9mIHRoZSBzdGF0ZSBmb3IgYm90aCB0aGUgYXBwbGljYXRpb24gYW5kIGFueSBvZiB0aGVcbiAgICogYXBwbGljYXRpb24ncyBjb250ZXh0LiAqL1xuICBzdGF0ZT86IFM7XG59XG5cbmludGVyZmFjZSBSZXF1ZXN0U3RhdGUge1xuICBoYW5kbGluZzogU2V0PFByb21pc2U8dm9pZD4+O1xuICBjbG9zaW5nOiBib29sZWFuO1xuICBjbG9zZWQ6IGJvb2xlYW47XG4gIHNlcnZlcjogU2VydmVyPFNlcnZlclJlcXVlc3Q+O1xufVxuXG4vLyBkZW5vLWxpbnQtaWdub3JlIG5vLWV4cGxpY2l0LWFueVxuZXhwb3J0IHR5cGUgU3RhdGUgPSBSZWNvcmQ8c3RyaW5nIHwgbnVtYmVyIHwgc3ltYm9sLCBhbnk+O1xuXG5jb25zdCBBRERSX1JFR0VYUCA9IC9eXFxbPyhbXlxcXV0qKVxcXT86KFswLTldezEsNX0pJC87XG5cbmNvbnN0IERFRkFVTFRfU0VSVkVSOiBTZXJ2ZXJDb25zdHJ1Y3RvcjxTZXJ2ZXJSZXF1ZXN0PiA9IEh0dHBTZXJ2ZXI7XG5cbmV4cG9ydCBjbGFzcyBBcHBsaWNhdGlvbkVycm9yRXZlbnQ8UyBleHRlbmRzIEFTLCBBUyBleHRlbmRzIFN0YXRlPlxuICBleHRlbmRzIEVycm9yRXZlbnQge1xuICBjb250ZXh0PzogQ29udGV4dDxTLCBBUz47XG5cbiAgY29uc3RydWN0b3IoZXZlbnRJbml0RGljdDogQXBwbGljYXRpb25FcnJvckV2ZW50SW5pdDxTLCBBUz4pIHtcbiAgICBzdXBlcihcImVycm9yXCIsIGV2ZW50SW5pdERpY3QpO1xuICAgIHRoaXMuY29udGV4dCA9IGV2ZW50SW5pdERpY3QuY29udGV4dDtcbiAgfVxufVxuXG5mdW5jdGlvbiBsb2dFcnJvckxpc3RlbmVyPFMgZXh0ZW5kcyBBUywgQVMgZXh0ZW5kcyBTdGF0ZT4oXG4gIHsgZXJyb3IsIGNvbnRleHQgfTogQXBwbGljYXRpb25FcnJvckV2ZW50PFMsIEFTPixcbikge1xuICBpZiAoZXJyb3IgaW5zdGFuY2VvZiBFcnJvcikge1xuICAgIGNvbnNvbGUuZXJyb3IoXG4gICAgICBgW3VuY2F1Z2h0IGFwcGxpY2F0aW9uIGVycm9yXTogJHtlcnJvci5uYW1lfSAtICR7ZXJyb3IubWVzc2FnZX1gLFxuICAgICk7XG4gIH0gZWxzZSB7XG4gICAgY29uc29sZS5lcnJvcihgW3VuY2F1Z2h0IGFwcGxpY2F0aW9uIGVycm9yXVxcbmAsIGVycm9yKTtcbiAgfVxuICBpZiAoY29udGV4dCkge1xuICAgIGxldCB1cmw6IHN0cmluZztcbiAgICB0cnkge1xuICAgICAgdXJsID0gY29udGV4dC5yZXF1ZXN0LnVybC50b1N0cmluZygpO1xuICAgIH0gY2F0Y2gge1xuICAgICAgdXJsID0gXCJbbWFsZm9ybWVkIHVybF1cIjtcbiAgICB9XG4gICAgY29uc29sZS5lcnJvcihgXFxucmVxdWVzdDpgLCB7XG4gICAgICB1cmwsXG4gICAgICBtZXRob2Q6IGNvbnRleHQucmVxdWVzdC5tZXRob2QsXG4gICAgICBoYXNCb2R5OiBjb250ZXh0LnJlcXVlc3QuaGFzQm9keSxcbiAgICB9KTtcbiAgICBjb25zb2xlLmVycm9yKGByZXNwb25zZTpgLCB7XG4gICAgICBzdGF0dXM6IGNvbnRleHQucmVzcG9uc2Uuc3RhdHVzLFxuICAgICAgdHlwZTogY29udGV4dC5yZXNwb25zZS50eXBlLFxuICAgICAgaGFzQm9keTogISFjb250ZXh0LnJlc3BvbnNlLmJvZHksXG4gICAgICB3cml0YWJsZTogY29udGV4dC5yZXNwb25zZS53cml0YWJsZSxcbiAgICB9KTtcbiAgfVxuICBpZiAoZXJyb3IgaW5zdGFuY2VvZiBFcnJvciAmJiBlcnJvci5zdGFjaykge1xuICAgIGNvbnNvbGUuZXJyb3IoYFxcbiR7ZXJyb3Iuc3RhY2suc3BsaXQoXCJcXG5cIikuc2xpY2UoMSkuam9pbihcIlxcblwiKX1gKTtcbiAgfVxufVxuXG5leHBvcnQgY2xhc3MgQXBwbGljYXRpb25MaXN0ZW5FdmVudCBleHRlbmRzIEV2ZW50IHtcbiAgaG9zdG5hbWU6IHN0cmluZztcbiAgbGlzdGVuZXI6IExpc3RlbmVyO1xuICBwb3J0OiBudW1iZXI7XG4gIHNlY3VyZTogYm9vbGVhbjtcbiAgc2VydmVyVHlwZTogXCJuYXRpdmVcIiB8IFwiY3VzdG9tXCI7XG5cbiAgY29uc3RydWN0b3IoZXZlbnRJbml0RGljdDogQXBwbGljYXRpb25MaXN0ZW5FdmVudEluaXQpIHtcbiAgICBzdXBlcihcImxpc3RlblwiLCBldmVudEluaXREaWN0KTtcbiAgICB0aGlzLmhvc3RuYW1lID0gZXZlbnRJbml0RGljdC5ob3N0bmFtZTtcbiAgICB0aGlzLmxpc3RlbmVyID0gZXZlbnRJbml0RGljdC5saXN0ZW5lcjtcbiAgICB0aGlzLnBvcnQgPSBldmVudEluaXREaWN0LnBvcnQ7XG4gICAgdGhpcy5zZWN1cmUgPSBldmVudEluaXREaWN0LnNlY3VyZTtcbiAgICB0aGlzLnNlcnZlclR5cGUgPSBldmVudEluaXREaWN0LnNlcnZlclR5cGU7XG4gIH1cbn1cblxuLyoqIEEgY2xhc3Mgd2hpY2ggcmVnaXN0ZXJzIG1pZGRsZXdhcmUgKHZpYSBgLnVzZSgpYCkgYW5kIHRoZW4gcHJvY2Vzc2VzXG4gKiBpbmJvdW5kIHJlcXVlc3RzIGFnYWluc3QgdGhhdCBtaWRkbGV3YXJlICh2aWEgYC5saXN0ZW4oKWApLlxuICpcbiAqIFRoZSBgY29udGV4dC5zdGF0ZWAgY2FuIGJlIHR5cGVkIHZpYSBwYXNzaW5nIGEgZ2VuZXJpYyBhcmd1bWVudCB3aGVuXG4gKiBjb25zdHJ1Y3RpbmcgYW4gaW5zdGFuY2Ugb2YgYEFwcGxpY2F0aW9uYC4gSXQgY2FuIGFsc28gYmUgaW5mZXJyZWQgYnkgc2V0dGluZ1xuICogdGhlIHtAbGlua2NvZGUgQXBwbGljYXRpb25PcHRpb25zLnN0YXRlfSBvcHRpb24gd2hlbiBjb25zdHJ1Y3RpbmcgdGhlXG4gKiBhcHBsaWNhdGlvbi5cbiAqXG4gKiAjIyMgQmFzaWMgZXhhbXBsZVxuICpcbiAqIGBgYHRzXG4gKiBpbXBvcnQgeyBBcHBsaWNhdGlvbiB9IGZyb20gXCJodHRwczovL2Rlbm8ubGFuZC94L29hay9tb2QudHNcIjtcbiAqXG4gKiBjb25zdCBhcHAgPSBuZXcgQXBwbGljYXRpb24oKTtcbiAqXG4gKiBhcHAudXNlKChjdHgsIG5leHQpID0+IHtcbiAqICAgLy8gY2FsbGVkIG9uIGVhY2ggcmVxdWVzdCB3aXRoIHRoZSBjb250ZXh0IChgY3R4YCkgb2YgdGhlIHJlcXVlc3QsXG4gKiAgIC8vIHJlc3BvbnNlLCBhbmQgb3RoZXIgZGF0YS5cbiAqICAgLy8gYG5leHQoKWAgaXMgdXNlIHRvIG1vZGlmeSB0aGUgZmxvdyBjb250cm9sIG9mIHRoZSBtaWRkbGV3YXJlIHN0YWNrLlxuICogfSk7XG4gKlxuICogYXBwLmxpc3Rlbih7IHBvcnQ6IDgwODAgfSk7XG4gKiBgYGBcbiAqXG4gKiBAdGVtcGxhdGUgQVMgdGhlIHR5cGUgb2YgdGhlIGFwcGxpY2F0aW9uIHN0YXRlIHdoaWNoIGV4dGVuZHNcbiAqICAgICAgICAgICAgICB7QGxpbmtjb2RlIFN0YXRlfSBhbmQgZGVmYXVsdHMgdG8gYSBzaW1wbGUgc3RyaW5nIHJlY29yZC5cbiAqL1xuLy8gZGVuby1saW50LWlnbm9yZSBuby1leHBsaWNpdC1hbnlcbmV4cG9ydCBjbGFzcyBBcHBsaWNhdGlvbjxBUyBleHRlbmRzIFN0YXRlID0gUmVjb3JkPHN0cmluZywgYW55Pj5cbiAgZXh0ZW5kcyBFdmVudFRhcmdldCB7XG4gICNjb21wb3NlZE1pZGRsZXdhcmU/OiAoY29udGV4dDogQ29udGV4dDxBUywgQVM+KSA9PiBQcm9taXNlPHVua25vd24+O1xuICAjY29udGV4dFN0YXRlOiBcImNsb25lXCIgfCBcInByb3RvdHlwZVwiIHwgXCJhbGlhc1wiIHwgXCJlbXB0eVwiO1xuICAja2V5cz86IEtleVN0YWNrO1xuICAjbWlkZGxld2FyZTogTWlkZGxld2FyZTxTdGF0ZSwgQ29udGV4dDxTdGF0ZSwgQVM+PltdID0gW107XG4gICNzZXJ2ZXJDb25zdHJ1Y3RvcjogU2VydmVyQ29uc3RydWN0b3I8U2VydmVyUmVxdWVzdD47XG5cbiAgLyoqIEEgc2V0IG9mIGtleXMsIG9yIGFuIGluc3RhbmNlIG9mIGBLZXlTdGFja2Agd2hpY2ggd2lsbCBiZSB1c2VkIHRvIHNpZ25cbiAgICogY29va2llcyByZWFkIGFuZCBzZXQgYnkgdGhlIGFwcGxpY2F0aW9uIHRvIGF2b2lkIHRhbXBlcmluZyB3aXRoIHRoZVxuICAgKiBjb29raWVzLiAqL1xuICBnZXQga2V5cygpOiBLZXlTdGFjayB8IEtleVtdIHwgdW5kZWZpbmVkIHtcbiAgICByZXR1cm4gdGhpcy4ja2V5cztcbiAgfVxuXG4gIHNldCBrZXlzKGtleXM6IEtleVN0YWNrIHwgS2V5W10gfCB1bmRlZmluZWQpIHtcbiAgICBpZiAoIWtleXMpIHtcbiAgICAgIHRoaXMuI2tleXMgPSB1bmRlZmluZWQ7XG4gICAgICByZXR1cm47XG4gICAgfSBlbHNlIGlmIChBcnJheS5pc0FycmF5KGtleXMpKSB7XG4gICAgICB0aGlzLiNrZXlzID0gbmV3IEtleVN0YWNrKGtleXMpO1xuICAgIH0gZWxzZSB7XG4gICAgICB0aGlzLiNrZXlzID0ga2V5cztcbiAgICB9XG4gIH1cblxuICAvKiogSWYgYHRydWVgLCBwcm94eSBoZWFkZXJzIHdpbGwgYmUgdHJ1c3RlZCB3aGVuIHByb2Nlc3NpbmcgcmVxdWVzdHMuICBUaGlzXG4gICAqIGRlZmF1bHRzIHRvIGBmYWxzZWAuICovXG4gIHByb3h5OiBib29sZWFuO1xuXG4gIC8qKiBHZW5lcmljIHN0YXRlIG9mIHRoZSBhcHBsaWNhdGlvbiwgd2hpY2ggY2FuIGJlIHNwZWNpZmllZCBieSBwYXNzaW5nIHRoZVxuICAgKiBnZW5lcmljIGFyZ3VtZW50IHdoZW4gY29uc3RydWN0aW5nOlxuICAgKlxuICAgKiAgICAgICBjb25zdCBhcHAgPSBuZXcgQXBwbGljYXRpb248eyBmb286IHN0cmluZyB9PigpO1xuICAgKlxuICAgKiBPciBjYW4gYmUgY29udGV4dHVhbGx5IGluZmVycmVkIGJhc2VkIG9uIHNldHRpbmcgYW4gaW5pdGlhbCBzdGF0ZSBvYmplY3Q6XG4gICAqXG4gICAqICAgICAgIGNvbnN0IGFwcCA9IG5ldyBBcHBsaWNhdGlvbih7IHN0YXRlOiB7IGZvbzogXCJiYXJcIiB9IH0pO1xuICAgKlxuICAgKiBXaGVuIGEgbmV3IGNvbnRleHQgaXMgY3JlYXRlZCwgdGhlIGFwcGxpY2F0aW9uJ3Mgc3RhdGUgaXMgY2xvbmVkIGFuZCB0aGVcbiAgICogc3RhdGUgaXMgdW5pcXVlIHRvIHRoYXQgcmVxdWVzdC9yZXNwb25zZS4gIENoYW5nZXMgY2FuIGJlIG1hZGUgdG8gdGhlXG4gICAqIGFwcGxpY2F0aW9uIHN0YXRlIHRoYXQgd2lsbCBiZSBzaGFyZWQgd2l0aCBhbGwgY29udGV4dHMuXG4gICAqL1xuICBzdGF0ZTogQVM7XG5cbiAgY29uc3RydWN0b3Iob3B0aW9uczogQXBwbGljYXRpb25PcHRpb25zPEFTLCBTZXJ2ZXJSZXF1ZXN0PiA9IHt9KSB7XG4gICAgc3VwZXIoKTtcbiAgICBjb25zdCB7XG4gICAgICBzdGF0ZSxcbiAgICAgIGtleXMsXG4gICAgICBwcm94eSxcbiAgICAgIHNlcnZlckNvbnN0cnVjdG9yID0gREVGQVVMVF9TRVJWRVIsXG4gICAgICBjb250ZXh0U3RhdGUgPSBcImNsb25lXCIsXG4gICAgICBsb2dFcnJvcnMgPSB0cnVlLFxuICAgIH0gPSBvcHRpb25zO1xuXG4gICAgdGhpcy5wcm94eSA9IHByb3h5ID8/IGZhbHNlO1xuICAgIHRoaXMua2V5cyA9IGtleXM7XG4gICAgdGhpcy5zdGF0ZSA9IHN0YXRlID8/IHt9IGFzIEFTO1xuICAgIHRoaXMuI3NlcnZlckNvbnN0cnVjdG9yID0gc2VydmVyQ29uc3RydWN0b3I7XG4gICAgdGhpcy4jY29udGV4dFN0YXRlID0gY29udGV4dFN0YXRlO1xuXG4gICAgaWYgKGxvZ0Vycm9ycykge1xuICAgICAgdGhpcy5hZGRFdmVudExpc3RlbmVyKFwiZXJyb3JcIiwgbG9nRXJyb3JMaXN0ZW5lcik7XG4gICAgfVxuICB9XG5cbiAgI2dldENvbXBvc2VkKCk6ICgoY29udGV4dDogQ29udGV4dDxBUywgQVM+KSA9PiBQcm9taXNlPHVua25vd24+KSB7XG4gICAgaWYgKCF0aGlzLiNjb21wb3NlZE1pZGRsZXdhcmUpIHtcbiAgICAgIHRoaXMuI2NvbXBvc2VkTWlkZGxld2FyZSA9IGNvbXBvc2UodGhpcy4jbWlkZGxld2FyZSk7XG4gICAgfVxuICAgIHJldHVybiB0aGlzLiNjb21wb3NlZE1pZGRsZXdhcmU7XG4gIH1cblxuICAjZ2V0Q29udGV4dFN0YXRlKCk6IEFTIHtcbiAgICBzd2l0Y2ggKHRoaXMuI2NvbnRleHRTdGF0ZSkge1xuICAgICAgY2FzZSBcImFsaWFzXCI6XG4gICAgICAgIHJldHVybiB0aGlzLnN0YXRlO1xuICAgICAgY2FzZSBcImNsb25lXCI6XG4gICAgICAgIHJldHVybiBjbG9uZVN0YXRlKHRoaXMuc3RhdGUpO1xuICAgICAgY2FzZSBcImVtcHR5XCI6XG4gICAgICAgIHJldHVybiB7fSBhcyBBUztcbiAgICAgIGNhc2UgXCJwcm90b3R5cGVcIjpcbiAgICAgICAgcmV0dXJuIE9iamVjdC5jcmVhdGUodGhpcy5zdGF0ZSk7XG4gICAgfVxuICB9XG5cbiAgLyoqIERlYWwgd2l0aCB1bmNhdWdodCBlcnJvcnMgaW4gZWl0aGVyIHRoZSBtaWRkbGV3YXJlIG9yIHNlbmRpbmcgdGhlXG4gICAqIHJlc3BvbnNlLiAqL1xuICAvLyBkZW5vLWxpbnQtaWdub3JlIG5vLWV4cGxpY2l0LWFueVxuICAjaGFuZGxlRXJyb3IoY29udGV4dDogQ29udGV4dDxBUz4sIGVycm9yOiBhbnkpOiB2b2lkIHtcbiAgICBpZiAoIShlcnJvciBpbnN0YW5jZW9mIEVycm9yKSkge1xuICAgICAgZXJyb3IgPSBuZXcgRXJyb3IoYG5vbi1lcnJvciB0aHJvd246ICR7SlNPTi5zdHJpbmdpZnkoZXJyb3IpfWApO1xuICAgIH1cbiAgICBjb25zdCB7IG1lc3NhZ2UgfSA9IGVycm9yO1xuICAgIHRoaXMuZGlzcGF0Y2hFdmVudChuZXcgQXBwbGljYXRpb25FcnJvckV2ZW50KHsgY29udGV4dCwgbWVzc2FnZSwgZXJyb3IgfSkpO1xuICAgIGlmICghY29udGV4dC5yZXNwb25zZS53cml0YWJsZSkge1xuICAgICAgcmV0dXJuO1xuICAgIH1cbiAgICBmb3IgKGNvbnN0IGtleSBvZiBbLi4uY29udGV4dC5yZXNwb25zZS5oZWFkZXJzLmtleXMoKV0pIHtcbiAgICAgIGNvbnRleHQucmVzcG9uc2UuaGVhZGVycy5kZWxldGUoa2V5KTtcbiAgICB9XG4gICAgaWYgKGVycm9yLmhlYWRlcnMgJiYgZXJyb3IuaGVhZGVycyBpbnN0YW5jZW9mIEhlYWRlcnMpIHtcbiAgICAgIGZvciAoY29uc3QgW2tleSwgdmFsdWVdIG9mIGVycm9yLmhlYWRlcnMpIHtcbiAgICAgICAgY29udGV4dC5yZXNwb25zZS5oZWFkZXJzLnNldChrZXksIHZhbHVlKTtcbiAgICAgIH1cbiAgICB9XG4gICAgY29udGV4dC5yZXNwb25zZS50eXBlID0gXCJ0ZXh0XCI7XG4gICAgY29uc3Qgc3RhdHVzOiBTdGF0dXMgPSBjb250ZXh0LnJlc3BvbnNlLnN0YXR1cyA9XG4gICAgICBEZW5vLmVycm9ycyAmJiBlcnJvciBpbnN0YW5jZW9mIERlbm8uZXJyb3JzLk5vdEZvdW5kXG4gICAgICAgID8gNDA0XG4gICAgICAgIDogZXJyb3Iuc3RhdHVzICYmIHR5cGVvZiBlcnJvci5zdGF0dXMgPT09IFwibnVtYmVyXCJcbiAgICAgICAgPyBlcnJvci5zdGF0dXNcbiAgICAgICAgOiA1MDA7XG4gICAgY29udGV4dC5yZXNwb25zZS5ib2R5ID0gZXJyb3IuZXhwb3NlXG4gICAgICA/IGVycm9yLm1lc3NhZ2VcbiAgICAgIDogU1RBVFVTX1RFWFQuZ2V0KHN0YXR1cyk7XG4gIH1cblxuICAvKiogUHJvY2Vzc2luZyByZWdpc3RlcmVkIG1pZGRsZXdhcmUgb24gZWFjaCByZXF1ZXN0LiAqL1xuICBhc3luYyAjaGFuZGxlUmVxdWVzdChcbiAgICByZXF1ZXN0OiBTZXJ2ZXJSZXF1ZXN0LFxuICAgIHNlY3VyZTogYm9vbGVhbixcbiAgICBzdGF0ZTogUmVxdWVzdFN0YXRlLFxuICApOiBQcm9taXNlPHZvaWQ+IHtcbiAgICBjb25zdCBjb250ZXh0ID0gbmV3IENvbnRleHQodGhpcywgcmVxdWVzdCwgdGhpcy4jZ2V0Q29udGV4dFN0YXRlKCksIHNlY3VyZSk7XG4gICAgbGV0IHJlc29sdmU6ICgpID0+IHZvaWQ7XG4gICAgY29uc3QgaGFuZGxpbmdQcm9taXNlID0gbmV3IFByb21pc2U8dm9pZD4oKHJlcykgPT4gcmVzb2x2ZSA9IHJlcyk7XG4gICAgc3RhdGUuaGFuZGxpbmcuYWRkKGhhbmRsaW5nUHJvbWlzZSk7XG4gICAgaWYgKCFzdGF0ZS5jbG9zaW5nICYmICFzdGF0ZS5jbG9zZWQpIHtcbiAgICAgIHRyeSB7XG4gICAgICAgIGF3YWl0IHRoaXMuI2dldENvbXBvc2VkKCkoY29udGV4dCk7XG4gICAgICB9IGNhdGNoIChlcnIpIHtcbiAgICAgICAgdGhpcy4jaGFuZGxlRXJyb3IoY29udGV4dCwgZXJyKTtcbiAgICAgIH1cbiAgICB9XG4gICAgaWYgKGNvbnRleHQucmVzcG9uZCA9PT0gZmFsc2UpIHtcbiAgICAgIGNvbnRleHQucmVzcG9uc2UuZGVzdHJveSgpO1xuICAgICAgcmVzb2x2ZSEoKTtcbiAgICAgIHN0YXRlLmhhbmRsaW5nLmRlbGV0ZShoYW5kbGluZ1Byb21pc2UpO1xuICAgICAgcmV0dXJuO1xuICAgIH1cbiAgICBsZXQgY2xvc2VSZXNvdXJjZXMgPSB0cnVlO1xuICAgIGxldCByZXNwb25zZTogUmVzcG9uc2U7XG4gICAgdHJ5IHtcbiAgICAgIGNsb3NlUmVzb3VyY2VzID0gZmFsc2U7XG4gICAgICByZXNwb25zZSA9IGF3YWl0IGNvbnRleHQucmVzcG9uc2UudG9Eb21SZXNwb25zZSgpO1xuICAgIH0gY2F0Y2ggKGVycikge1xuICAgICAgdGhpcy4jaGFuZGxlRXJyb3IoY29udGV4dCwgZXJyKTtcbiAgICAgIHJlc3BvbnNlID0gYXdhaXQgY29udGV4dC5yZXNwb25zZS50b0RvbVJlc3BvbnNlKCk7XG4gICAgfVxuICAgIGFzc2VydChyZXNwb25zZSk7XG4gICAgdHJ5IHtcbiAgICAgIGF3YWl0IHJlcXVlc3QucmVzcG9uZChyZXNwb25zZSk7XG4gICAgfSBjYXRjaCAoZXJyKSB7XG4gICAgICB0aGlzLiNoYW5kbGVFcnJvcihjb250ZXh0LCBlcnIpO1xuICAgIH0gZmluYWxseSB7XG4gICAgICBjb250ZXh0LnJlc3BvbnNlLmRlc3Ryb3koY2xvc2VSZXNvdXJjZXMpO1xuICAgICAgcmVzb2x2ZSEoKTtcbiAgICAgIHN0YXRlLmhhbmRsaW5nLmRlbGV0ZShoYW5kbGluZ1Byb21pc2UpO1xuICAgICAgaWYgKHN0YXRlLmNsb3NpbmcpIHtcbiAgICAgICAgc3RhdGUuc2VydmVyLmNsb3NlKCk7XG4gICAgICAgIHN0YXRlLmNsb3NlZCA9IHRydWU7XG4gICAgICB9XG4gICAgfVxuICB9XG5cbiAgLyoqIEFkZCBhbiBldmVudCBsaXN0ZW5lciBmb3IgYW4gYFwiZXJyb3JcImAgZXZlbnQgd2hpY2ggb2NjdXJzIHdoZW4gYW5cbiAgICogdW4tY2F1Z2h0IGVycm9yIG9jY3VycyB3aGVuIHByb2Nlc3NpbmcgdGhlIG1pZGRsZXdhcmUgb3IgZHVyaW5nIHByb2Nlc3NpbmdcbiAgICogb2YgdGhlIHJlc3BvbnNlLiAqL1xuICBhZGRFdmVudExpc3RlbmVyPFMgZXh0ZW5kcyBBUz4oXG4gICAgdHlwZTogXCJlcnJvclwiLFxuICAgIGxpc3RlbmVyOiBBcHBsaWNhdGlvbkVycm9yRXZlbnRMaXN0ZW5lck9yRXZlbnRMaXN0ZW5lck9iamVjdDxTLCBBUz4gfCBudWxsLFxuICAgIG9wdGlvbnM/OiBib29sZWFuIHwgQWRkRXZlbnRMaXN0ZW5lck9wdGlvbnMsXG4gICk6IHZvaWQ7XG4gIC8qKiBBZGQgYW4gZXZlbnQgbGlzdGVuZXIgZm9yIGEgYFwibGlzdGVuXCJgIGV2ZW50IHdoaWNoIG9jY3VycyB3aGVuIHRoZSBzZXJ2ZXJcbiAgICogaGFzIHN1Y2Nlc3NmdWxseSBvcGVuZWQgYnV0IGJlZm9yZSBhbnkgcmVxdWVzdHMgc3RhcnQgYmVpbmcgcHJvY2Vzc2VkLiAqL1xuICBhZGRFdmVudExpc3RlbmVyKFxuICAgIHR5cGU6IFwibGlzdGVuXCIsXG4gICAgbGlzdGVuZXI6IEFwcGxpY2F0aW9uTGlzdGVuRXZlbnRMaXN0ZW5lck9yRXZlbnRMaXN0ZW5lck9iamVjdCB8IG51bGwsXG4gICAgb3B0aW9ucz86IGJvb2xlYW4gfCBBZGRFdmVudExpc3RlbmVyT3B0aW9ucyxcbiAgKTogdm9pZDtcbiAgLyoqIEFkZCBhbiBldmVudCBsaXN0ZW5lciBmb3IgYW4gZXZlbnQuICBDdXJyZW50bHkgdmFsaWQgZXZlbnQgdHlwZXMgYXJlXG4gICAqIGBcImVycm9yXCJgIGFuZCBgXCJsaXN0ZW5cImAuICovXG4gIGFkZEV2ZW50TGlzdGVuZXIoXG4gICAgdHlwZTogXCJlcnJvclwiIHwgXCJsaXN0ZW5cIixcbiAgICBsaXN0ZW5lcjogRXZlbnRMaXN0ZW5lck9yRXZlbnRMaXN0ZW5lck9iamVjdCB8IG51bGwsXG4gICAgb3B0aW9ucz86IGJvb2xlYW4gfCBBZGRFdmVudExpc3RlbmVyT3B0aW9ucyxcbiAgKTogdm9pZCB7XG4gICAgc3VwZXIuYWRkRXZlbnRMaXN0ZW5lcih0eXBlLCBsaXN0ZW5lciwgb3B0aW9ucyk7XG4gIH1cblxuICAvKiogSGFuZGxlIGFuIGluZGl2aWR1YWwgc2VydmVyIHJlcXVlc3QsIHJldHVybmluZyB0aGUgc2VydmVyIHJlc3BvbnNlLiAgVGhpc1xuICAgKiBpcyBzaW1pbGFyIHRvIGAubGlzdGVuKClgLCBidXQgb3BlbmluZyB0aGUgY29ubmVjdGlvbiBhbmQgcmV0cmlldmluZ1xuICAgKiByZXF1ZXN0cyBhcmUgbm90IHRoZSByZXNwb25zaWJpbGl0eSBvZiB0aGUgYXBwbGljYXRpb24uICBJZiB0aGUgZ2VuZXJhdGVkXG4gICAqIGNvbnRleHQgZ2V0cyBzZXQgdG8gbm90IHRvIHJlc3BvbmQsIHRoZW4gdGhlIG1ldGhvZCByZXNvbHZlcyB3aXRoXG4gICAqIGB1bmRlZmluZWRgLCBvdGhlcndpc2UgaXQgcmVzb2x2ZXMgd2l0aCBhIHJlcXVlc3QgdGhhdCBpcyBjb21wYXRpYmxlIHdpdGhcbiAgICogYHN0ZC9odHRwL3NlcnZlcmAuICovXG4gIGhhbmRsZSA9IChhc3luYyAoXG4gICAgcmVxdWVzdDogUmVxdWVzdCxcbiAgICBzZWN1cmVPckNvbm46IERlbm8uQ29ubiB8IGJvb2xlYW4gfCB1bmRlZmluZWQsXG4gICAgc2VjdXJlOiBib29sZWFuIHwgdW5kZWZpbmVkID0gZmFsc2UsXG4gICk6IFByb21pc2U8UmVzcG9uc2UgfCB1bmRlZmluZWQ+ID0+IHtcbiAgICBpZiAoIXRoaXMuI21pZGRsZXdhcmUubGVuZ3RoKSB7XG4gICAgICB0aHJvdyBuZXcgVHlwZUVycm9yKFwiVGhlcmUgaXMgbm8gbWlkZGxld2FyZSB0byBwcm9jZXNzIHJlcXVlc3RzLlwiKTtcbiAgICB9XG4gICAgYXNzZXJ0KGlzQ29ubihzZWN1cmVPckNvbm4pIHx8IHR5cGVvZiBzZWN1cmVPckNvbm4gPT09IFwidW5kZWZpbmVkXCIpO1xuICAgIGNvbnN0IGNvbnRleHRSZXF1ZXN0ID0gbmV3IE5hdGl2ZVJlcXVlc3Qoe1xuICAgICAgcmVxdWVzdCxcbiAgICAgIHJlc3BvbmRXaXRoKCkge1xuICAgICAgICByZXR1cm4gUHJvbWlzZS5yZXNvbHZlKHVuZGVmaW5lZCk7XG4gICAgICB9LFxuICAgIH0sIHsgY29ubjogc2VjdXJlT3JDb25uIH0pO1xuICAgIGNvbnN0IGNvbnRleHQgPSBuZXcgQ29udGV4dChcbiAgICAgIHRoaXMsXG4gICAgICBjb250ZXh0UmVxdWVzdCxcbiAgICAgIHRoaXMuI2dldENvbnRleHRTdGF0ZSgpLFxuICAgICAgc2VjdXJlLFxuICAgICk7XG4gICAgdHJ5IHtcbiAgICAgIGF3YWl0IHRoaXMuI2dldENvbXBvc2VkKCkoY29udGV4dCk7XG4gICAgfSBjYXRjaCAoZXJyKSB7XG4gICAgICB0aGlzLiNoYW5kbGVFcnJvcihjb250ZXh0LCBlcnIpO1xuICAgIH1cbiAgICBpZiAoY29udGV4dC5yZXNwb25kID09PSBmYWxzZSkge1xuICAgICAgY29udGV4dC5yZXNwb25zZS5kZXN0cm95KCk7XG4gICAgICByZXR1cm47XG4gICAgfVxuICAgIHRyeSB7XG4gICAgICBjb25zdCByZXNwb25zZSA9IGF3YWl0IGNvbnRleHQucmVzcG9uc2UudG9Eb21SZXNwb25zZSgpO1xuICAgICAgY29udGV4dC5yZXNwb25zZS5kZXN0cm95KGZhbHNlKTtcbiAgICAgIHJldHVybiByZXNwb25zZTtcbiAgICB9IGNhdGNoIChlcnIpIHtcbiAgICAgIHRoaXMuI2hhbmRsZUVycm9yKGNvbnRleHQsIGVycik7XG4gICAgICB0aHJvdyBlcnI7XG4gICAgfVxuICB9KSBhcyBIYW5kbGVNZXRob2Q7XG5cbiAgLyoqIFN0YXJ0IGxpc3RlbmluZyBmb3IgcmVxdWVzdHMsIHByb2Nlc3NpbmcgcmVnaXN0ZXJlZCBtaWRkbGV3YXJlIG9uIGVhY2hcbiAgICogcmVxdWVzdC4gIElmIHRoZSBvcHRpb25zIGAuc2VjdXJlYCBpcyB1bmRlZmluZWQgb3IgYGZhbHNlYCwgdGhlIGxpc3RlbmluZ1xuICAgKiB3aWxsIGJlIG92ZXIgSFRUUC4gIElmIHRoZSBvcHRpb25zIGAuc2VjdXJlYCBwcm9wZXJ0eSBpcyBgdHJ1ZWAsIGFcbiAgICogYC5jZXJ0RmlsZWAgYW5kIGEgYC5rZXlGaWxlYCBwcm9wZXJ0eSBuZWVkIHRvIGJlIHN1cHBsaWVkIGFuZCByZXF1ZXN0c1xuICAgKiB3aWxsIGJlIHByb2Nlc3NlZCBvdmVyIEhUVFBTLiAqL1xuICBhc3luYyBsaXN0ZW4oYWRkcjogc3RyaW5nKTogUHJvbWlzZTx2b2lkPjtcbiAgLyoqIFN0YXJ0IGxpc3RlbmluZyBmb3IgcmVxdWVzdHMsIHByb2Nlc3NpbmcgcmVnaXN0ZXJlZCBtaWRkbGV3YXJlIG9uIGVhY2hcbiAgICogcmVxdWVzdC4gIElmIHRoZSBvcHRpb25zIGAuc2VjdXJlYCBpcyB1bmRlZmluZWQgb3IgYGZhbHNlYCwgdGhlIGxpc3RlbmluZ1xuICAgKiB3aWxsIGJlIG92ZXIgSFRUUC4gIElmIHRoZSBvcHRpb25zIGAuc2VjdXJlYCBwcm9wZXJ0eSBpcyBgdHJ1ZWAsIGFcbiAgICogYC5jZXJ0RmlsZWAgYW5kIGEgYC5rZXlGaWxlYCBwcm9wZXJ0eSBuZWVkIHRvIGJlIHN1cHBsaWVkIGFuZCByZXF1ZXN0c1xuICAgKiB3aWxsIGJlIHByb2Nlc3NlZCBvdmVyIEhUVFBTLlxuICAgKlxuICAgKiBPbWl0dGluZyBvcHRpb25zIHdpbGwgZGVmYXVsdCB0byBgeyBwb3J0OiAwIH1gIHdoaWNoIGFsbG93cyB0aGUgb3BlcmF0aW5nXG4gICAqIHN5c3RlbSB0byBzZWxlY3QgdGhlIHBvcnQuICovXG4gIGFzeW5jIGxpc3RlbihvcHRpb25zPzogTGlzdGVuT3B0aW9ucyk6IFByb21pc2U8dm9pZD47XG4gIGFzeW5jIGxpc3RlbihvcHRpb25zOiBzdHJpbmcgfCBMaXN0ZW5PcHRpb25zID0geyBwb3J0OiAwIH0pOiBQcm9taXNlPHZvaWQ+IHtcbiAgICBpZiAoIXRoaXMuI21pZGRsZXdhcmUubGVuZ3RoKSB7XG4gICAgICB0aHJvdyBuZXcgVHlwZUVycm9yKFwiVGhlcmUgaXMgbm8gbWlkZGxld2FyZSB0byBwcm9jZXNzIHJlcXVlc3RzLlwiKTtcbiAgICB9XG4gICAgaWYgKHR5cGVvZiBvcHRpb25zID09PSBcInN0cmluZ1wiKSB7XG4gICAgICBjb25zdCBtYXRjaCA9IEFERFJfUkVHRVhQLmV4ZWMob3B0aW9ucyk7XG4gICAgICBpZiAoIW1hdGNoKSB7XG4gICAgICAgIHRocm93IFR5cGVFcnJvcihgSW52YWxpZCBhZGRyZXNzIHBhc3NlZDogXCIke29wdGlvbnN9XCJgKTtcbiAgICAgIH1cbiAgICAgIGNvbnN0IFssIGhvc3RuYW1lLCBwb3J0U3RyXSA9IG1hdGNoO1xuICAgICAgb3B0aW9ucyA9IHsgaG9zdG5hbWUsIHBvcnQ6IHBhcnNlSW50KHBvcnRTdHIsIDEwKSB9O1xuICAgIH1cbiAgICBvcHRpb25zID0gT2JqZWN0LmFzc2lnbih7IHBvcnQ6IDAgfSwgb3B0aW9ucyk7XG4gICAgY29uc3Qgc2VydmVyID0gbmV3IHRoaXMuI3NlcnZlckNvbnN0cnVjdG9yKFxuICAgICAgdGhpcyxcbiAgICAgIG9wdGlvbnMgYXMgRGVuby5MaXN0ZW5PcHRpb25zLFxuICAgICk7XG4gICAgY29uc3QgeyBzaWduYWwgfSA9IG9wdGlvbnM7XG4gICAgY29uc3Qgc3RhdGUgPSB7XG4gICAgICBjbG9zZWQ6IGZhbHNlLFxuICAgICAgY2xvc2luZzogZmFsc2UsXG4gICAgICBoYW5kbGluZzogbmV3IFNldDxQcm9taXNlPHZvaWQ+PigpLFxuICAgICAgc2VydmVyLFxuICAgIH07XG4gICAgaWYgKHNpZ25hbCkge1xuICAgICAgc2lnbmFsLmFkZEV2ZW50TGlzdGVuZXIoXCJhYm9ydFwiLCAoKSA9PiB7XG4gICAgICAgIGlmICghc3RhdGUuaGFuZGxpbmcuc2l6ZSkge1xuICAgICAgICAgIHNlcnZlci5jbG9zZSgpO1xuICAgICAgICAgIHN0YXRlLmNsb3NlZCA9IHRydWU7XG4gICAgICAgIH1cbiAgICAgICAgc3RhdGUuY2xvc2luZyA9IHRydWU7XG4gICAgICB9KTtcbiAgICB9XG4gICAgY29uc3QgeyBzZWN1cmUgPSBmYWxzZSB9ID0gb3B0aW9ucztcbiAgICBjb25zdCBzZXJ2ZXJUeXBlID0gc2VydmVyIGluc3RhbmNlb2YgSHR0cFNlcnZlciA/IFwibmF0aXZlXCIgOiBcImN1c3RvbVwiO1xuICAgIGNvbnN0IGxpc3RlbmVyID0gc2VydmVyLmxpc3RlbigpO1xuICAgIGNvbnN0IHsgaG9zdG5hbWUsIHBvcnQgfSA9IGxpc3RlbmVyLmFkZHIgYXMgRGVuby5OZXRBZGRyO1xuICAgIHRoaXMuZGlzcGF0Y2hFdmVudChcbiAgICAgIG5ldyBBcHBsaWNhdGlvbkxpc3RlbkV2ZW50KHtcbiAgICAgICAgaG9zdG5hbWUsXG4gICAgICAgIGxpc3RlbmVyLFxuICAgICAgICBwb3J0LFxuICAgICAgICBzZWN1cmUsXG4gICAgICAgIHNlcnZlclR5cGUsXG4gICAgICB9KSxcbiAgICApO1xuICAgIHRyeSB7XG4gICAgICBmb3IgYXdhaXQgKGNvbnN0IHJlcXVlc3Qgb2Ygc2VydmVyKSB7XG4gICAgICAgIHRoaXMuI2hhbmRsZVJlcXVlc3QocmVxdWVzdCwgc2VjdXJlLCBzdGF0ZSk7XG4gICAgICB9XG4gICAgICBhd2FpdCBQcm9taXNlLmFsbChzdGF0ZS5oYW5kbGluZyk7XG4gICAgfSBjYXRjaCAoZXJyb3IpIHtcbiAgICAgIGNvbnN0IG1lc3NhZ2UgPSBlcnJvciBpbnN0YW5jZW9mIEVycm9yXG4gICAgICAgID8gZXJyb3IubWVzc2FnZVxuICAgICAgICA6IFwiQXBwbGljYXRpb24gRXJyb3JcIjtcbiAgICAgIHRoaXMuZGlzcGF0Y2hFdmVudChcbiAgICAgICAgbmV3IEFwcGxpY2F0aW9uRXJyb3JFdmVudCh7IG1lc3NhZ2UsIGVycm9yIH0pLFxuICAgICAgKTtcbiAgICB9XG4gIH1cblxuICAvKiogUmVnaXN0ZXIgbWlkZGxld2FyZSB0byBiZSB1c2VkIHdpdGggdGhlIGFwcGxpY2F0aW9uLiAgTWlkZGxld2FyZSB3aWxsXG4gICAqIGJlIHByb2Nlc3NlZCBpbiB0aGUgb3JkZXIgaXQgaXMgYWRkZWQsIGJ1dCBtaWRkbGV3YXJlIGNhbiBjb250cm9sIHRoZSBmbG93XG4gICAqIG9mIGV4ZWN1dGlvbiB2aWEgdGhlIHVzZSBvZiB0aGUgYG5leHQoKWAgZnVuY3Rpb24gdGhhdCB0aGUgbWlkZGxld2FyZVxuICAgKiBmdW5jdGlvbiB3aWxsIGJlIGNhbGxlZCB3aXRoLiAgVGhlIGBjb250ZXh0YCBvYmplY3QgcHJvdmlkZXMgaW5mb3JtYXRpb25cbiAgICogYWJvdXQgdGhlIGN1cnJlbnQgc3RhdGUgb2YgdGhlIGFwcGxpY2F0aW9uLlxuICAgKlxuICAgKiBCYXNpYyB1c2FnZTpcbiAgICpcbiAgICogYGBgdHNcbiAgICogY29uc3QgaW1wb3J0IHsgQXBwbGljYXRpb24gfSBmcm9tIFwiaHR0cHM6Ly9kZW5vLmxhbmQveC9vYWsvbW9kLnRzXCI7XG4gICAqXG4gICAqIGNvbnN0IGFwcCA9IG5ldyBBcHBsaWNhdGlvbigpO1xuICAgKlxuICAgKiBhcHAudXNlKChjdHgsIG5leHQpID0+IHtcbiAgICogICBjdHgucmVxdWVzdDsgLy8gY29udGFpbnMgcmVxdWVzdCBpbmZvcm1hdGlvblxuICAgKiAgIGN0eC5yZXNwb25zZTsgLy8gc2V0dXBzIHVwIGluZm9ybWF0aW9uIHRvIHVzZSBpbiB0aGUgcmVzcG9uc2U7XG4gICAqICAgYXdhaXQgbmV4dCgpOyAvLyBtYW5hZ2VzIHRoZSBmbG93IGNvbnRyb2wgb2YgdGhlIG1pZGRsZXdhcmUgZXhlY3V0aW9uXG4gICAqIH0pO1xuICAgKlxuICAgKiBhd2FpdCBhcHAubGlzdGVuKHsgcG9ydDogODAgfSk7XG4gICAqIGBgYFxuICAgKi9cbiAgdXNlPFMgZXh0ZW5kcyBTdGF0ZSA9IEFTPihcbiAgICBtaWRkbGV3YXJlOiBNaWRkbGV3YXJlPFMsIENvbnRleHQ8UywgQVM+PixcbiAgICAuLi5taWRkbGV3YXJlczogTWlkZGxld2FyZTxTLCBDb250ZXh0PFMsIEFTPj5bXVxuICApOiBBcHBsaWNhdGlvbjxTIGV4dGVuZHMgQVMgPyBTIDogKFMgJiBBUyk+O1xuICB1c2U8UyBleHRlbmRzIFN0YXRlID0gQVM+KFxuICAgIC4uLm1pZGRsZXdhcmU6IE1pZGRsZXdhcmU8UywgQ29udGV4dDxTLCBBUz4+W11cbiAgKTogQXBwbGljYXRpb248UyBleHRlbmRzIEFTID8gUyA6IChTICYgQVMpPiB7XG4gICAgdGhpcy4jbWlkZGxld2FyZS5wdXNoKC4uLm1pZGRsZXdhcmUpO1xuICAgIHRoaXMuI2NvbXBvc2VkTWlkZGxld2FyZSA9IHVuZGVmaW5lZDtcbiAgICAvLyBkZW5vLWxpbnQtaWdub3JlIG5vLWV4cGxpY2l0LWFueVxuICAgIHJldHVybiB0aGlzIGFzIEFwcGxpY2F0aW9uPGFueT47XG4gIH1cblxuICBbU3ltYm9sLmZvcihcIkRlbm8uY3VzdG9tSW5zcGVjdFwiKV0oaW5zcGVjdDogKHZhbHVlOiB1bmtub3duKSA9PiBzdHJpbmcpIHtcbiAgICBjb25zdCB7IGtleXMsIHByb3h5LCBzdGF0ZSB9ID0gdGhpcztcbiAgICByZXR1cm4gYCR7dGhpcy5jb25zdHJ1Y3Rvci5uYW1lfSAke1xuICAgICAgaW5zcGVjdCh7IFwiI21pZGRsZXdhcmVcIjogdGhpcy4jbWlkZGxld2FyZSwga2V5cywgcHJveHksIHN0YXRlIH0pXG4gICAgfWA7XG4gIH1cblxuICBbU3ltYm9sLmZvcihcIm5vZGVqcy51dGlsLmluc3BlY3QuY3VzdG9tXCIpXShcbiAgICBkZXB0aDogbnVtYmVyLFxuICAgIC8vIGRlbm8tbGludC1pZ25vcmUgbm8tZXhwbGljaXQtYW55XG4gICAgb3B0aW9uczogYW55LFxuICAgIGluc3BlY3Q6ICh2YWx1ZTogdW5rbm93biwgb3B0aW9ucz86IHVua25vd24pID0+IHN0cmluZyxcbiAgKSB7XG4gICAgaWYgKGRlcHRoIDwgMCkge1xuICAgICAgcmV0dXJuIG9wdGlvbnMuc3R5bGl6ZShgWyR7dGhpcy5jb25zdHJ1Y3Rvci5uYW1lfV1gLCBcInNwZWNpYWxcIik7XG4gICAgfVxuXG4gICAgY29uc3QgbmV3T3B0aW9ucyA9IE9iamVjdC5hc3NpZ24oe30sIG9wdGlvbnMsIHtcbiAgICAgIGRlcHRoOiBvcHRpb25zLmRlcHRoID09PSBudWxsID8gbnVsbCA6IG9wdGlvbnMuZGVwdGggLSAxLFxuICAgIH0pO1xuICAgIGNvbnN0IHsga2V5cywgcHJveHksIHN0YXRlIH0gPSB0aGlzO1xuICAgIHJldHVybiBgJHtvcHRpb25zLnN0eWxpemUodGhpcy5jb25zdHJ1Y3Rvci5uYW1lLCBcInNwZWNpYWxcIil9ICR7XG4gICAgICBpbnNwZWN0KFxuICAgICAgICB7IFwiI21pZGRsZXdhcmVcIjogdGhpcy4jbWlkZGxld2FyZSwga2V5cywgcHJveHksIHN0YXRlIH0sXG4gICAgICAgIG5ld09wdGlvbnMsXG4gICAgICApXG4gICAgfWA7XG4gIH1cbn1cbiJdLCJuYW1lcyI6W10sIm1hcHBpbmdzIjoiQUFBQSx5RUFBeUU7QUFFekUsU0FBUyxPQUFPLFFBQVEsY0FBYyxDQUFDO0FBQ3ZDLFNBQWlCLFdBQVcsUUFBUSxXQUFXLENBQUM7QUFDaEQsU0FBUyxVQUFVLFFBQVEseUJBQXlCLENBQUM7QUFDckQsU0FBUyxhQUFhLFFBQVEsaUNBQWlDLENBQUM7QUFDaEUsU0FBUyxRQUFRLFFBQVEsZUFBZSxDQUFDO0FBQ3pDLFNBQVMsT0FBTyxRQUFvQixpQkFBaUIsQ0FBQztBQUN0RCxTQUFTLFVBQVUsUUFBUSx1QkFBdUIsQ0FBQztBQVFuRCxTQUFTLE1BQU0sRUFBRSxNQUFNLFFBQVEsV0FBVyxDQUFDO0FBb0ozQyxNQUFNLFdBQVcsa0NBQWtDLEFBQUM7QUFFcEQsTUFBTSxjQUFjLEdBQXFDLFVBQVUsQUFBQztBQUVwRSxPQUFPLE1BQU0scUJBQXFCLFNBQ3hCLFVBQVU7SUFDbEIsT0FBTyxDQUFrQjtJQUV6QixZQUFZLGFBQStDLENBQUU7UUFDM0QsS0FBSyxDQUFDLE9BQU8sRUFBRSxhQUFhLENBQUMsQ0FBQztRQUM5QixJQUFJLENBQUMsT0FBTyxHQUFHLGFBQWEsQ0FBQyxPQUFPLENBQUM7S0FDdEM7Q0FDRjtBQUVELFNBQVMsZ0JBQWdCLENBQ3ZCLEVBQUUsS0FBSyxDQUFBLEVBQUUsT0FBTyxDQUFBLEVBQWdDLEVBQ2hEO0lBQ0EsSUFBSSxLQUFLLFlBQVksS0FBSyxFQUFFO1FBQzFCLE9BQU8sQ0FBQyxLQUFLLENBQ1gsQ0FBQyw4QkFBOEIsRUFBRSxLQUFLLENBQUMsSUFBSSxDQUFDLEdBQUcsRUFBRSxLQUFLLENBQUMsT0FBTyxDQUFDLENBQUMsQ0FDakUsQ0FBQztLQUNILE1BQU07UUFDTCxPQUFPLENBQUMsS0FBSyxDQUFDLENBQUMsOEJBQThCLENBQUMsRUFBRSxLQUFLLENBQUMsQ0FBQztLQUN4RDtJQUNELElBQUksT0FBTyxFQUFFO1FBQ1gsSUFBSSxHQUFHLEFBQVEsQUFBQztRQUNoQixJQUFJO1lBQ0YsR0FBRyxHQUFHLE9BQU8sQ0FBQyxPQUFPLENBQUMsR0FBRyxDQUFDLFFBQVEsRUFBRSxDQUFDO1NBQ3RDLENBQUMsT0FBTTtZQUNOLEdBQUcsR0FBRyxpQkFBaUIsQ0FBQztTQUN6QjtRQUNELE9BQU8sQ0FBQyxLQUFLLENBQUMsQ0FBQyxVQUFVLENBQUMsRUFBRTtZQUMxQixHQUFHO1lBQ0gsTUFBTSxFQUFFLE9BQU8sQ0FBQyxPQUFPLENBQUMsTUFBTTtZQUM5QixPQUFPLEVBQUUsT0FBTyxDQUFDLE9BQU8sQ0FBQyxPQUFPO1NBQ2pDLENBQUMsQ0FBQztRQUNILE9BQU8sQ0FBQyxLQUFLLENBQUMsQ0FBQyxTQUFTLENBQUMsRUFBRTtZQUN6QixNQUFNLEVBQUUsT0FBTyxDQUFDLFFBQVEsQ0FBQyxNQUFNO1lBQy9CLElBQUksRUFBRSxPQUFPLENBQUMsUUFBUSxDQUFDLElBQUk7WUFDM0IsT0FBTyxFQUFFLENBQUMsQ0FBQyxPQUFPLENBQUMsUUFBUSxDQUFDLElBQUk7WUFDaEMsUUFBUSxFQUFFLE9BQU8sQ0FBQyxRQUFRLENBQUMsUUFBUTtTQUNwQyxDQUFDLENBQUM7S0FDSjtJQUNELElBQUksS0FBSyxZQUFZLEtBQUssSUFBSSxLQUFLLENBQUMsS0FBSyxFQUFFO1FBQ3pDLE9BQU8sQ0FBQyxLQUFLLENBQUMsQ0FBQyxFQUFFLEVBQUUsS0FBSyxDQUFDLEtBQUssQ0FBQyxLQUFLLENBQUMsSUFBSSxDQUFDLENBQUMsS0FBSyxDQUFDLENBQUMsQ0FBQyxDQUFDLElBQUksQ0FBQyxJQUFJLENBQUMsQ0FBQyxDQUFDLENBQUMsQ0FBQztLQUNuRTtDQUNGO0FBRUQsT0FBTyxNQUFNLHNCQUFzQixTQUFTLEtBQUs7SUFDL0MsUUFBUSxDQUFTO0lBQ2pCLFFBQVEsQ0FBVztJQUNuQixJQUFJLENBQVM7SUFDYixNQUFNLENBQVU7SUFDaEIsVUFBVSxDQUFzQjtJQUVoQyxZQUFZLGFBQXlDLENBQUU7UUFDckQsS0FBSyxDQUFDLFFBQVEsRUFBRSxhQUFhLENBQUMsQ0FBQztRQUMvQixJQUFJLENBQUMsUUFBUSxHQUFHLGFBQWEsQ0FBQyxRQUFRLENBQUM7UUFDdkMsSUFBSSxDQUFDLFFBQVEsR0FBRyxhQUFhLENBQUMsUUFBUSxDQUFDO1FBQ3ZDLElBQUksQ0FBQyxJQUFJLEdBQUcsYUFBYSxDQUFDLElBQUksQ0FBQztRQUMvQixJQUFJLENBQUMsTUFBTSxHQUFHLGFBQWEsQ0FBQyxNQUFNLENBQUM7UUFDbkMsSUFBSSxDQUFDLFVBQVUsR0FBRyxhQUFhLENBQUMsVUFBVSxDQUFDO0tBQzVDO0NBQ0Y7QUFFRDs7Ozs7Ozs7Ozs7Ozs7Ozs7Ozs7Ozs7Ozs7R0EwQkcsQ0FDSCxtQ0FBbUM7QUFDbkMsT0FBTyxNQUFNLFdBQVcsU0FDZCxXQUFXO0lBQ25CLENBQUMsa0JBQWtCLENBQWtEO0lBQ3JFLENBQUMsWUFBWSxDQUE0QztJQUN6RCxDQUFDLElBQUksQ0FBWTtJQUNqQixDQUFDLFVBQVUsR0FBNEMsRUFBRSxDQUFDO0lBQzFELENBQUMsaUJBQWlCLENBQW1DO0lBRXJEOztnQkFFYyxDQUNkLElBQUksSUFBSSxHQUFpQztRQUN2QyxPQUFPLElBQUksQ0FBQyxDQUFDLElBQUksQ0FBQztLQUNuQjtJQUVELElBQUksSUFBSSxDQUFDLElBQWtDLEVBQUU7UUFDM0MsSUFBSSxDQUFDLElBQUksRUFBRTtZQUNULElBQUksQ0FBQyxDQUFDLElBQUksR0FBRyxTQUFTLENBQUM7WUFDdkIsT0FBTztTQUNSLE1BQU0sSUFBSSxLQUFLLENBQUMsT0FBTyxDQUFDLElBQUksQ0FBQyxFQUFFO1lBQzlCLElBQUksQ0FBQyxDQUFDLElBQUksR0FBRyxJQUFJLFFBQVEsQ0FBQyxJQUFJLENBQUMsQ0FBQztTQUNqQyxNQUFNO1lBQ0wsSUFBSSxDQUFDLENBQUMsSUFBSSxHQUFHLElBQUksQ0FBQztTQUNuQjtLQUNGO0lBRUQ7NEJBQzBCLENBQzFCLEtBQUssQ0FBVTtJQUVmOzs7Ozs7Ozs7Ozs7S0FZRyxDQUNILEtBQUssQ0FBSztJQUVWLFlBQVksT0FBOEMsR0FBRyxFQUFFLENBQUU7UUFDL0QsS0FBSyxFQUFFLENBQUM7UUFDUixNQUFNLEVBQ0osS0FBSyxDQUFBLEVBQ0wsSUFBSSxDQUFBLEVBQ0osS0FBSyxDQUFBLEVBQ0wsaUJBQWlCLEVBQUcsY0FBYyxDQUFBLEVBQ2xDLFlBQVksRUFBRyxPQUFPLENBQUEsRUFDdEIsU0FBUyxFQUFHLElBQUksQ0FBQSxJQUNqQixHQUFHLE9BQU8sQUFBQztRQUVaLElBQUksQ0FBQyxLQUFLLEdBQUcsS0FBSyxJQUFJLEtBQUssQ0FBQztRQUM1QixJQUFJLENBQUMsSUFBSSxHQUFHLElBQUksQ0FBQztRQUNqQixJQUFJLENBQUMsS0FBSyxHQUFHLEtBQUssSUFBSSxFQUFFLEFBQU0sQ0FBQztRQUMvQixJQUFJLENBQUMsQ0FBQyxpQkFBaUIsR0FBRyxpQkFBaUIsQ0FBQztRQUM1QyxJQUFJLENBQUMsQ0FBQyxZQUFZLEdBQUcsWUFBWSxDQUFDO1FBRWxDLElBQUksU0FBUyxFQUFFO1lBQ2IsSUFBSSxDQUFDLGdCQUFnQixDQUFDLE9BQU8sRUFBRSxnQkFBZ0IsQ0FBQyxDQUFDO1NBQ2xEO0tBQ0Y7SUFFRCxDQUFBLENBQUMsV0FBVyxHQUFxRDtRQUMvRCxJQUFJLENBQUMsSUFBSSxDQUFDLENBQUMsa0JBQWtCLEVBQUU7WUFDN0IsSUFBSSxDQUFDLENBQUMsa0JBQWtCLEdBQUcsT0FBTyxDQUFDLElBQUksQ0FBQyxDQUFDLFVBQVUsQ0FBQyxDQUFDO1NBQ3REO1FBQ0QsT0FBTyxJQUFJLENBQUMsQ0FBQyxrQkFBa0IsQ0FBQztLQUNqQztJQUVELENBQUEsQ0FBQyxlQUFlLEdBQU87UUFDckIsT0FBUSxJQUFJLENBQUMsQ0FBQyxZQUFZO1lBQ3hCLEtBQUssT0FBTztnQkFDVixPQUFPLElBQUksQ0FBQyxLQUFLLENBQUM7WUFDcEIsS0FBSyxPQUFPO2dCQUNWLE9BQU8sVUFBVSxDQUFDLElBQUksQ0FBQyxLQUFLLENBQUMsQ0FBQztZQUNoQyxLQUFLLE9BQU87Z0JBQ1YsT0FBTyxFQUFFLENBQU87WUFDbEIsS0FBSyxXQUFXO2dCQUNkLE9BQU8sTUFBTSxDQUFDLE1BQU0sQ0FBQyxJQUFJLENBQUMsS0FBSyxDQUFDLENBQUM7U0FDcEM7S0FDRjtJQUVEO2lCQUNlLENBQ2YsbUNBQW1DO0lBQ25DLENBQUEsQ0FBQyxXQUFXLENBQUMsT0FBb0IsRUFBRSxLQUFVLEVBQVE7UUFDbkQsSUFBSSxDQUFDLENBQUMsS0FBSyxZQUFZLEtBQUssQ0FBQyxFQUFFO1lBQzdCLEtBQUssR0FBRyxJQUFJLEtBQUssQ0FBQyxDQUFDLGtCQUFrQixFQUFFLElBQUksQ0FBQyxTQUFTLENBQUMsS0FBSyxDQUFDLENBQUMsQ0FBQyxDQUFDLENBQUM7U0FDakU7UUFDRCxNQUFNLEVBQUUsT0FBTyxDQUFBLEVBQUUsR0FBRyxLQUFLLEFBQUM7UUFDMUIsSUFBSSxDQUFDLGFBQWEsQ0FBQyxJQUFJLHFCQUFxQixDQUFDO1lBQUUsT0FBTztZQUFFLE9BQU87WUFBRSxLQUFLO1NBQUUsQ0FBQyxDQUFDLENBQUM7UUFDM0UsSUFBSSxDQUFDLE9BQU8sQ0FBQyxRQUFRLENBQUMsUUFBUSxFQUFFO1lBQzlCLE9BQU87U0FDUjtRQUNELEtBQUssTUFBTSxHQUFHLElBQUk7ZUFBSSxPQUFPLENBQUMsUUFBUSxDQUFDLE9BQU8sQ0FBQyxJQUFJLEVBQUU7U0FBQyxDQUFFO1lBQ3RELE9BQU8sQ0FBQyxRQUFRLENBQUMsT0FBTyxDQUFDLE1BQU0sQ0FBQyxHQUFHLENBQUMsQ0FBQztTQUN0QztRQUNELElBQUksS0FBSyxDQUFDLE9BQU8sSUFBSSxLQUFLLENBQUMsT0FBTyxZQUFZLE9BQU8sRUFBRTtZQUNyRCxLQUFLLE1BQU0sQ0FBQyxJQUFHLEVBQUUsS0FBSyxDQUFDLElBQUksS0FBSyxDQUFDLE9BQU8sQ0FBRTtnQkFDeEMsT0FBTyxDQUFDLFFBQVEsQ0FBQyxPQUFPLENBQUMsR0FBRyxDQUFDLElBQUcsRUFBRSxLQUFLLENBQUMsQ0FBQzthQUMxQztTQUNGO1FBQ0QsT0FBTyxDQUFDLFFBQVEsQ0FBQyxJQUFJLEdBQUcsTUFBTSxDQUFDO1FBQy9CLE1BQU0sTUFBTSxHQUFXLE9BQU8sQ0FBQyxRQUFRLENBQUMsTUFBTSxHQUM1QyxJQUFJLENBQUMsTUFBTSxJQUFJLEtBQUssWUFBWSxJQUFJLENBQUMsTUFBTSxDQUFDLFFBQVEsR0FDaEQsR0FBRyxHQUNILEtBQUssQ0FBQyxNQUFNLElBQUksT0FBTyxLQUFLLENBQUMsTUFBTSxLQUFLLFFBQVEsR0FDaEQsS0FBSyxDQUFDLE1BQU0sR0FDWixHQUFHLEFBQUM7UUFDVixPQUFPLENBQUMsUUFBUSxDQUFDLElBQUksR0FBRyxLQUFLLENBQUMsTUFBTSxHQUNoQyxLQUFLLENBQUMsT0FBTyxHQUNiLFdBQVcsQ0FBQyxHQUFHLENBQUMsTUFBTSxDQUFDLENBQUM7S0FDN0I7SUFFRCx3REFBd0QsQ0FDeEQsTUFBTSxDQUFDLGFBQWEsQ0FDbEIsT0FBc0IsRUFDdEIsTUFBZSxFQUNmLEtBQW1CLEVBQ0o7UUFDZixNQUFNLFFBQU8sR0FBRyxJQUFJLE9BQU8sQ0FBQyxJQUFJLEVBQUUsT0FBTyxFQUFFLElBQUksQ0FBQyxDQUFDLGVBQWUsRUFBRSxFQUFFLE1BQU0sQ0FBQyxBQUFDO1FBQzVFLElBQUksT0FBTyxBQUFZLEFBQUM7UUFDeEIsTUFBTSxlQUFlLEdBQUcsSUFBSSxPQUFPLENBQU8sQ0FBQyxHQUFHLEdBQUssT0FBTyxHQUFHLEdBQUcsQ0FBQyxBQUFDO1FBQ2xFLEtBQUssQ0FBQyxRQUFRLENBQUMsR0FBRyxDQUFDLGVBQWUsQ0FBQyxDQUFDO1FBQ3BDLElBQUksQ0FBQyxLQUFLLENBQUMsT0FBTyxJQUFJLENBQUMsS0FBSyxDQUFDLE1BQU0sRUFBRTtZQUNuQyxJQUFJO2dCQUNGLE1BQU0sSUFBSSxDQUFDLENBQUMsV0FBVyxFQUFFLENBQUMsUUFBTyxDQUFDLENBQUM7YUFDcEMsQ0FBQyxPQUFPLEdBQUcsRUFBRTtnQkFDWixJQUFJLENBQUMsQ0FBQyxXQUFXLENBQUMsUUFBTyxFQUFFLEdBQUcsQ0FBQyxDQUFDO2FBQ2pDO1NBQ0Y7UUFDRCxJQUFJLFFBQU8sQ0FBQyxPQUFPLEtBQUssS0FBSyxFQUFFO1lBQzdCLFFBQU8sQ0FBQyxRQUFRLENBQUMsT0FBTyxFQUFFLENBQUM7WUFDM0IsT0FBTyxFQUFHLENBQUM7WUFDWCxLQUFLLENBQUMsUUFBUSxDQUFDLE1BQU0sQ0FBQyxlQUFlLENBQUMsQ0FBQztZQUN2QyxPQUFPO1NBQ1I7UUFDRCxJQUFJLGNBQWMsR0FBRyxJQUFJLEFBQUM7UUFDMUIsSUFBSSxRQUFRLEFBQVUsQUFBQztRQUN2QixJQUFJO1lBQ0YsY0FBYyxHQUFHLEtBQUssQ0FBQztZQUN2QixRQUFRLEdBQUcsTUFBTSxRQUFPLENBQUMsUUFBUSxDQUFDLGFBQWEsRUFBRSxDQUFDO1NBQ25ELENBQUMsT0FBTyxJQUFHLEVBQUU7WUFDWixJQUFJLENBQUMsQ0FBQyxXQUFXLENBQUMsUUFBTyxFQUFFLElBQUcsQ0FBQyxDQUFDO1lBQ2hDLFFBQVEsR0FBRyxNQUFNLFFBQU8sQ0FBQyxRQUFRLENBQUMsYUFBYSxFQUFFLENBQUM7U0FDbkQ7UUFDRCxNQUFNLENBQUMsUUFBUSxDQUFDLENBQUM7UUFDakIsSUFBSTtZQUNGLE1BQU0sT0FBTyxDQUFDLE9BQU8sQ0FBQyxRQUFRLENBQUMsQ0FBQztTQUNqQyxDQUFDLE9BQU8sSUFBRyxFQUFFO1lBQ1osSUFBSSxDQUFDLENBQUMsV0FBVyxDQUFDLFFBQU8sRUFBRSxJQUFHLENBQUMsQ0FBQztTQUNqQyxRQUFTO1lBQ1IsUUFBTyxDQUFDLFFBQVEsQ0FBQyxPQUFPLENBQUMsY0FBYyxDQUFDLENBQUM7WUFDekMsT0FBTyxFQUFHLENBQUM7WUFDWCxLQUFLLENBQUMsUUFBUSxDQUFDLE1BQU0sQ0FBQyxlQUFlLENBQUMsQ0FBQztZQUN2QyxJQUFJLEtBQUssQ0FBQyxPQUFPLEVBQUU7Z0JBQ2pCLEtBQUssQ0FBQyxNQUFNLENBQUMsS0FBSyxFQUFFLENBQUM7Z0JBQ3JCLEtBQUssQ0FBQyxNQUFNLEdBQUcsSUFBSSxDQUFDO2FBQ3JCO1NBQ0Y7S0FDRjtJQWlCRDtpQ0FDK0IsQ0FDL0IsZ0JBQWdCLENBQ2QsSUFBd0IsRUFDeEIsUUFBbUQsRUFDbkQsT0FBMkMsRUFDckM7UUFDTixLQUFLLENBQUMsZ0JBQWdCLENBQUMsSUFBSSxFQUFFLFFBQVEsRUFBRSxPQUFPLENBQUMsQ0FBQztLQUNqRDtJQUVEOzs7OzswQkFLd0IsQ0FDeEIsTUFBTSxHQUFJLE9BQ1IsT0FBZ0IsRUFDaEIsWUFBNkMsRUFDN0MsTUFBMkIsR0FBRyxLQUFLLEdBQ0Q7UUFDbEMsSUFBSSxDQUFDLElBQUksQ0FBQyxDQUFDLFVBQVUsQ0FBQyxNQUFNLEVBQUU7WUFDNUIsTUFBTSxJQUFJLFNBQVMsQ0FBQyw2Q0FBNkMsQ0FBQyxDQUFDO1NBQ3BFO1FBQ0QsTUFBTSxDQUFDLE1BQU0sQ0FBQyxZQUFZLENBQUMsSUFBSSxPQUFPLFlBQVksS0FBSyxXQUFXLENBQUMsQ0FBQztRQUNwRSxNQUFNLGNBQWMsR0FBRyxJQUFJLGFBQWEsQ0FBQztZQUN2QyxPQUFPO1lBQ1AsV0FBVyxJQUFHO2dCQUNaLE9BQU8sT0FBTyxDQUFDLE9BQU8sQ0FBQyxTQUFTLENBQUMsQ0FBQzthQUNuQztTQUNGLEVBQUU7WUFBRSxJQUFJLEVBQUUsWUFBWTtTQUFFLENBQUMsQUFBQztRQUMzQixNQUFNLE9BQU8sR0FBRyxJQUFJLE9BQU8sQ0FDekIsSUFBSSxFQUNKLGNBQWMsRUFDZCxJQUFJLENBQUMsQ0FBQyxlQUFlLEVBQUUsRUFDdkIsTUFBTSxDQUNQLEFBQUM7UUFDRixJQUFJO1lBQ0YsTUFBTSxJQUFJLENBQUMsQ0FBQyxXQUFXLEVBQUUsQ0FBQyxPQUFPLENBQUMsQ0FBQztTQUNwQyxDQUFDLE9BQU8sR0FBRyxFQUFFO1lBQ1osSUFBSSxDQUFDLENBQUMsV0FBVyxDQUFDLE9BQU8sRUFBRSxHQUFHLENBQUMsQ0FBQztTQUNqQztRQUNELElBQUksT0FBTyxDQUFDLE9BQU8sS0FBSyxLQUFLLEVBQUU7WUFDN0IsT0FBTyxDQUFDLFFBQVEsQ0FBQyxPQUFPLEVBQUUsQ0FBQztZQUMzQixPQUFPO1NBQ1I7UUFDRCxJQUFJO1lBQ0YsTUFBTSxRQUFRLEdBQUcsTUFBTSxPQUFPLENBQUMsUUFBUSxDQUFDLGFBQWEsRUFBRSxBQUFDO1lBQ3hELE9BQU8sQ0FBQyxRQUFRLENBQUMsT0FBTyxDQUFDLEtBQUssQ0FBQyxDQUFDO1lBQ2hDLE9BQU8sUUFBUSxDQUFDO1NBQ2pCLENBQUMsT0FBTyxJQUFHLEVBQUU7WUFDWixJQUFJLENBQUMsQ0FBQyxXQUFXLENBQUMsT0FBTyxFQUFFLElBQUcsQ0FBQyxDQUFDO1lBQ2hDLE1BQU0sSUFBRyxDQUFDO1NBQ1g7S0FDRixDQUFrQjtJQWlCbkIsTUFBTSxNQUFNLENBQUMsT0FBK0IsR0FBRztRQUFFLElBQUksRUFBRSxDQUFDO0tBQUUsRUFBaUI7UUFDekUsSUFBSSxDQUFDLElBQUksQ0FBQyxDQUFDLFVBQVUsQ0FBQyxNQUFNLEVBQUU7WUFDNUIsTUFBTSxJQUFJLFNBQVMsQ0FBQyw2Q0FBNkMsQ0FBQyxDQUFDO1NBQ3BFO1FBQ0QsSUFBSSxPQUFPLE9BQU8sS0FBSyxRQUFRLEVBQUU7WUFDL0IsTUFBTSxLQUFLLEdBQUcsV0FBVyxDQUFDLElBQUksQ0FBQyxPQUFPLENBQUMsQUFBQztZQUN4QyxJQUFJLENBQUMsS0FBSyxFQUFFO2dCQUNWLE1BQU0sU0FBUyxDQUFDLENBQUMseUJBQXlCLEVBQUUsT0FBTyxDQUFDLENBQUMsQ0FBQyxDQUFDLENBQUM7YUFDekQ7WUFDRCxNQUFNLEdBQUcsUUFBUSxFQUFFLE9BQU8sQ0FBQyxHQUFHLEtBQUssQUFBQztZQUNwQyxPQUFPLEdBQUc7Z0JBQUUsUUFBUTtnQkFBRSxJQUFJLEVBQUUsUUFBUSxDQUFDLE9BQU8sRUFBRSxFQUFFLENBQUM7YUFBRSxDQUFDO1NBQ3JEO1FBQ0QsT0FBTyxHQUFHLE1BQU0sQ0FBQyxNQUFNLENBQUM7WUFBRSxJQUFJLEVBQUUsQ0FBQztTQUFFLEVBQUUsT0FBTyxDQUFDLENBQUM7UUFDOUMsTUFBTSxNQUFNLEdBQUcsSUFBSSxJQUFJLENBQUMsQ0FBQyxpQkFBaUIsQ0FDeEMsSUFBSSxFQUNKLE9BQU8sQ0FDUixBQUFDO1FBQ0YsTUFBTSxFQUFFLE1BQU0sQ0FBQSxFQUFFLEdBQUcsT0FBTyxBQUFDO1FBQzNCLE1BQU0sS0FBSyxHQUFHO1lBQ1osTUFBTSxFQUFFLEtBQUs7WUFDYixPQUFPLEVBQUUsS0FBSztZQUNkLFFBQVEsRUFBRSxJQUFJLEdBQUcsRUFBaUI7WUFDbEMsTUFBTTtTQUNQLEFBQUM7UUFDRixJQUFJLE1BQU0sRUFBRTtZQUNWLE1BQU0sQ0FBQyxnQkFBZ0IsQ0FBQyxPQUFPLEVBQUUsSUFBTTtnQkFDckMsSUFBSSxDQUFDLEtBQUssQ0FBQyxRQUFRLENBQUMsSUFBSSxFQUFFO29CQUN4QixNQUFNLENBQUMsS0FBSyxFQUFFLENBQUM7b0JBQ2YsS0FBSyxDQUFDLE1BQU0sR0FBRyxJQUFJLENBQUM7aUJBQ3JCO2dCQUNELEtBQUssQ0FBQyxPQUFPLEdBQUcsSUFBSSxDQUFDO2FBQ3RCLENBQUMsQ0FBQztTQUNKO1FBQ0QsTUFBTSxFQUFFLE1BQU0sRUFBRyxLQUFLLENBQUEsRUFBRSxHQUFHLE9BQU8sQUFBQztRQUNuQyxNQUFNLFVBQVUsR0FBRyxNQUFNLFlBQVksVUFBVSxHQUFHLFFBQVEsR0FBRyxRQUFRLEFBQUM7UUFDdEUsTUFBTSxRQUFRLEdBQUcsTUFBTSxDQUFDLE1BQU0sRUFBRSxBQUFDO1FBQ2pDLE1BQU0sRUFBRSxRQUFRLEVBQVIsU0FBUSxDQUFBLEVBQUUsSUFBSSxDQUFBLEVBQUUsR0FBRyxRQUFRLENBQUMsSUFBSSxBQUFnQixBQUFDO1FBQ3pELElBQUksQ0FBQyxhQUFhLENBQ2hCLElBQUksc0JBQXNCLENBQUM7WUFDekIsUUFBUSxFQUFSLFNBQVE7WUFDUixRQUFRO1lBQ1IsSUFBSTtZQUNKLE1BQU07WUFDTixVQUFVO1NBQ1gsQ0FBQyxDQUNILENBQUM7UUFDRixJQUFJO1lBQ0YsV0FBVyxNQUFNLE9BQU8sSUFBSSxNQUFNLENBQUU7Z0JBQ2xDLElBQUksQ0FBQyxDQUFDLGFBQWEsQ0FBQyxPQUFPLEVBQUUsTUFBTSxFQUFFLEtBQUssQ0FBQyxDQUFDO2FBQzdDO1lBQ0QsTUFBTSxPQUFPLENBQUMsR0FBRyxDQUFDLEtBQUssQ0FBQyxRQUFRLENBQUMsQ0FBQztTQUNuQyxDQUFDLE9BQU8sS0FBSyxFQUFFO1lBQ2QsTUFBTSxPQUFPLEdBQUcsS0FBSyxZQUFZLEtBQUssR0FDbEMsS0FBSyxDQUFDLE9BQU8sR0FDYixtQkFBbUIsQUFBQztZQUN4QixJQUFJLENBQUMsYUFBYSxDQUNoQixJQUFJLHFCQUFxQixDQUFDO2dCQUFFLE9BQU87Z0JBQUUsS0FBSzthQUFFLENBQUMsQ0FDOUMsQ0FBQztTQUNIO0tBQ0Y7SUE0QkQsR0FBRyxDQUNELEdBQUcsVUFBVSxBQUFpQyxFQUNKO1FBQzFDLElBQUksQ0FBQyxDQUFDLFVBQVUsQ0FBQyxJQUFJLElBQUksVUFBVSxDQUFDLENBQUM7UUFDckMsSUFBSSxDQUFDLENBQUMsa0JBQWtCLEdBQUcsU0FBUyxDQUFDO1FBQ3JDLG1DQUFtQztRQUNuQyxPQUFPLElBQUksQ0FBcUI7S0FDakM7SUFFRCxDQUFDLE1BQU0sQ0FBQyxHQUFHLENBQUMsb0JBQW9CLENBQUMsQ0FBQyxDQUFDLE9BQW1DLEVBQUU7UUFDdEUsTUFBTSxFQUFFLElBQUksQ0FBQSxFQUFFLEtBQUssQ0FBQSxFQUFFLEtBQUssQ0FBQSxFQUFFLEdBQUcsSUFBSSxBQUFDO1FBQ3BDLE9BQU8sQ0FBQyxFQUFFLElBQUksQ0FBQyxXQUFXLENBQUMsSUFBSSxDQUFDLENBQUMsRUFDL0IsT0FBTyxDQUFDO1lBQUUsYUFBYSxFQUFFLElBQUksQ0FBQyxDQUFDLFVBQVU7WUFBRSxJQUFJO1lBQUUsS0FBSztZQUFFLEtBQUs7U0FBRSxDQUFDLENBQ2pFLENBQUMsQ0FBQztLQUNKO0lBRUQsQ0FBQyxNQUFNLENBQUMsR0FBRyxDQUFDLDRCQUE0QixDQUFDLENBQUMsQ0FDeEMsS0FBYSxFQUNiLG1DQUFtQztJQUNuQyxPQUFZLEVBQ1osT0FBc0QsRUFDdEQ7UUFDQSxJQUFJLEtBQUssR0FBRyxDQUFDLEVBQUU7WUFDYixPQUFPLE9BQU8sQ0FBQyxPQUFPLENBQUMsQ0FBQyxDQUFDLEVBQUUsSUFBSSxDQUFDLFdBQVcsQ0FBQyxJQUFJLENBQUMsQ0FBQyxDQUFDLEVBQUUsU0FBUyxDQUFDLENBQUM7U0FDakU7UUFFRCxNQUFNLFVBQVUsR0FBRyxNQUFNLENBQUMsTUFBTSxDQUFDLEVBQUUsRUFBRSxPQUFPLEVBQUU7WUFDNUMsS0FBSyxFQUFFLE9BQU8sQ0FBQyxLQUFLLEtBQUssSUFBSSxHQUFHLElBQUksR0FBRyxPQUFPLENBQUMsS0FBSyxHQUFHLENBQUM7U0FDekQsQ0FBQyxBQUFDO1FBQ0gsTUFBTSxFQUFFLElBQUksQ0FBQSxFQUFFLEtBQUssQ0FBQSxFQUFFLEtBQUssQ0FBQSxFQUFFLEdBQUcsSUFBSSxBQUFDO1FBQ3BDLE9BQU8sQ0FBQyxFQUFFLE9BQU8sQ0FBQyxPQUFPLENBQUMsSUFBSSxDQUFDLFdBQVcsQ0FBQyxJQUFJLEVBQUUsU0FBUyxDQUFDLENBQUMsQ0FBQyxFQUMzRCxPQUFPLENBQ0w7WUFBRSxhQUFhLEVBQUUsSUFBSSxDQUFDLENBQUMsVUFBVTtZQUFFLElBQUk7WUFBRSxLQUFLO1lBQUUsS0FBSztTQUFFLEVBQ3ZELFVBQVUsQ0FDWCxDQUNGLENBQUMsQ0FBQztLQUNKO0NBQ0YifQ==
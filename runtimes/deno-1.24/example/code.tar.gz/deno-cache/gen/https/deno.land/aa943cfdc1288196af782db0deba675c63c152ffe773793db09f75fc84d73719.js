// Copyright 2018-2022 the oak authors. All rights reserved. MIT license.
import { BufReader } from "./buf_reader.ts";
import { getFilename } from "./content_disposition.ts";
import { equals, extension, writeAll } from "./deps.ts";
import { readHeaders, toParamRegExp, unquote } from "./headers.ts";
import { httpErrors } from "./httpError.ts";
import { getRandomFilename, skipLWSPChar, stripEol } from "./util.ts";
const decoder = new TextDecoder();
const encoder = new TextEncoder();
const BOUNDARY_PARAM_REGEX = toParamRegExp("boundary", "i");
const DEFAULT_BUFFER_SIZE = 1_048_576; // 1mb
const DEFAULT_MAX_FILE_SIZE = 10_485_760; // 10mb
const DEFAULT_MAX_SIZE = 0; // all files written to disc
const NAME_PARAM_REGEX = toParamRegExp("name", "i");
function append(a, b) {
    const ab = new Uint8Array(a.length + b.length);
    ab.set(a, 0);
    ab.set(b, a.length);
    return ab;
}
function isEqual(a, b) {
    return equals(skipLWSPChar(a), b);
}
async function readToStartOrEnd(body, start, end) {
    let lineResult;
    while(lineResult = await body.readLine()){
        if (isEqual(lineResult.bytes, start)) {
            return true;
        }
        if (isEqual(lineResult.bytes, end)) {
            return false;
        }
    }
    throw new httpErrors.BadRequest("Unable to find multi-part boundary.");
}
/** Yield up individual parts by reading the body and parsing out the ford
 * data values. */ async function* parts({ body , customContentTypes ={} , final , part , maxFileSize , maxSize , outPath , prefix  }) {
    async function getFile(contentType) {
        const ext = customContentTypes[contentType.toLowerCase()] ?? extension(contentType);
        if (!ext) {
            throw new httpErrors.BadRequest(`The form contained content type "${contentType}" which is not supported by the server.`);
        }
        if (!outPath) {
            outPath = await Deno.makeTempDir();
        }
        const filename = `${outPath}/${await getRandomFilename(prefix, ext)}`;
        const file = await Deno.open(filename, {
            write: true,
            createNew: true
        });
        return [
            filename,
            file
        ];
    }
    while(true){
        const headers = await readHeaders(body);
        const contentType = headers["content-type"];
        const contentDisposition = headers["content-disposition"];
        if (!contentDisposition) {
            throw new httpErrors.BadRequest("Form data part missing content-disposition header");
        }
        if (!contentDisposition.match(/^form-data;/i)) {
            throw new httpErrors.BadRequest(`Unexpected content-disposition header: "${contentDisposition}"`);
        }
        const matches = NAME_PARAM_REGEX.exec(contentDisposition);
        if (!matches) {
            throw new httpErrors.BadRequest(`Unable to determine name of form body part`);
        }
        let [, name] = matches;
        name = unquote(name);
        if (contentType) {
            const originalName = getFilename(contentDisposition);
            let byteLength = 0;
            let file;
            let filename;
            let buf;
            if (maxSize) {
                buf = new Uint8Array();
            } else {
                const result = await getFile(contentType);
                filename = result[0];
                file = result[1];
            }
            while(true){
                const readResult = await body.readLine(false);
                if (!readResult) {
                    throw new httpErrors.BadRequest("Unexpected EOF reached");
                }
                const { bytes  } = readResult;
                const strippedBytes = stripEol(bytes);
                if (isEqual(strippedBytes, part) || isEqual(strippedBytes, final)) {
                    if (file) {
                        // remove extra 2 bytes ([CR, LF]) from result file
                        const bytesDiff = bytes.length - strippedBytes.length;
                        if (bytesDiff) {
                            const originalBytesSize = await file.seek(-bytesDiff, Deno.SeekMode.Current);
                            await file.truncate(originalBytesSize);
                        }
                        file.close();
                    }
                    yield [
                        name,
                        {
                            content: buf,
                            contentType,
                            name,
                            filename,
                            originalName
                        }, 
                    ];
                    if (isEqual(strippedBytes, final)) {
                        return;
                    }
                    break;
                }
                byteLength += bytes.byteLength;
                if (byteLength > maxFileSize) {
                    if (file) {
                        file.close();
                    }
                    throw new httpErrors.RequestEntityTooLarge(`File size exceeds limit of ${maxFileSize} bytes.`);
                }
                if (buf) {
                    if (byteLength > maxSize) {
                        const result1 = await getFile(contentType);
                        filename = result1[0];
                        file = result1[1];
                        await writeAll(file, buf);
                        buf = undefined;
                    } else {
                        buf = append(buf, bytes);
                    }
                }
                if (file) {
                    await writeAll(file, bytes);
                }
            }
        } else {
            const lines = [];
            while(true){
                const readResult1 = await body.readLine();
                if (!readResult1) {
                    throw new httpErrors.BadRequest("Unexpected EOF reached");
                }
                const { bytes: bytes1  } = readResult1;
                if (isEqual(bytes1, part) || isEqual(bytes1, final)) {
                    yield [
                        name,
                        lines.join("\n")
                    ];
                    if (isEqual(bytes1, final)) {
                        return;
                    }
                    break;
                }
                lines.push(decoder.decode(bytes1));
            }
        }
    }
}
/** An interface which provides an interface to access the fields of a
 * `multipart/form-data` body.
 *
 * Normally an instance of this is accessed when handling a request body, and
 * dealing with decoding it.  There are options that can be set when attempting
 * to read a multi-part body (see: {@linkcode FormDataReadOptions}).
 *
 * If you `.read()` the value, then a promise is provided of type
 * {@linkcode FormDataBody}. If you use the `.stream()` property, it is an async
 * iterator which yields up a tuple of with the first element being a
 *
 * ### Examples
 *
 * Using `.read()`:
 *
 * ```ts
 * import { Application } from "https://deno.land/x/oak/mod.ts";
 *
 * const app = new Application();
 *
 * app.use(async (ctx) => {
 *   const body = ctx.request.body();
 *   if (body.type === "form-data") {
 *     const value = await body.value;
 *     const formData = await value.read();
 *     // the form data is fully available
 *   }
 * });
 * ```
 *
 *  Using `.stream()`:
 *
 * ```ts
 * import { Application } from "https://deno.land/x/oak/mod.ts";
 *
 * const app = new Application();
 *
 * app.use(async (ctx) => {
 *   const body = ctx.request.body();
 *   if (body.type === "form-data") {
 *     const value = await body.value;
 *     for await (const [name, value] of value.stream()) {
 *       // asynchronously iterate each part of the body
 *     }
 *   }
 * });
 * ```
 */ export class FormDataReader {
    #body;
    #boundaryFinal;
    #boundaryPart;
    #reading = false;
    constructor(contentType, body){
        const matches = contentType.match(BOUNDARY_PARAM_REGEX);
        if (!matches) {
            throw new httpErrors.BadRequest(`Content type "${contentType}" does not contain a valid boundary.`);
        }
        let [, boundary] = matches;
        boundary = unquote(boundary);
        this.#boundaryPart = encoder.encode(`--${boundary}`);
        this.#boundaryFinal = encoder.encode(`--${boundary}--`);
        this.#body = body;
    }
    /** Reads the multipart body of the response and resolves with an object which
   * contains fields and files that were part of the response.
   *
   * *Note*: this method handles multiple files with the same `name` attribute
   * in the request, but by design it does not handle multiple fields that share
   * the same `name`.  If you expect the request body to contain multiple form
   * data fields with the same name, it is better to use the `.stream()` method
   * which will iterate over each form data field individually. */ async read(options = {}) {
        if (this.#reading) {
            throw new Error("Body is already being read.");
        }
        this.#reading = true;
        const { outPath , maxFileSize =DEFAULT_MAX_FILE_SIZE , maxSize =DEFAULT_MAX_SIZE , bufferSize =DEFAULT_BUFFER_SIZE , customContentTypes ,  } = options;
        const body = new BufReader(this.#body, bufferSize);
        const result = {
            fields: {}
        };
        if (!await readToStartOrEnd(body, this.#boundaryPart, this.#boundaryFinal)) {
            return result;
        }
        try {
            for await (const part of parts({
                body,
                customContentTypes,
                part: this.#boundaryPart,
                final: this.#boundaryFinal,
                maxFileSize,
                maxSize,
                outPath
            })){
                const [key, value] = part;
                if (typeof value === "string") {
                    result.fields[key] = value;
                } else {
                    if (!result.files) {
                        result.files = [];
                    }
                    result.files.push(value);
                }
            }
        } catch (err) {
            if (err instanceof Deno.errors.PermissionDenied) {
                console.error(err.stack ? err.stack : `${err.name}: ${err.message}`);
            } else {
                throw err;
            }
        }
        return result;
    }
    /** Returns an iterator which will asynchronously yield each part of the form
   * data.  The yielded value is a tuple, where the first element is the name
   * of the part and the second element is a `string` or a `FormDataFile`
   * object. */ async *stream(options = {}) {
        if (this.#reading) {
            throw new Error("Body is already being read.");
        }
        this.#reading = true;
        const { outPath , customContentTypes , maxFileSize =DEFAULT_MAX_FILE_SIZE , maxSize =DEFAULT_MAX_SIZE , bufferSize =32000 ,  } = options;
        const body = new BufReader(this.#body, bufferSize);
        if (!await readToStartOrEnd(body, this.#boundaryPart, this.#boundaryFinal)) {
            return;
        }
        try {
            for await (const part of parts({
                body,
                customContentTypes,
                part: this.#boundaryPart,
                final: this.#boundaryFinal,
                maxFileSize,
                maxSize,
                outPath
            })){
                yield part;
            }
        } catch (err) {
            if (err instanceof Deno.errors.PermissionDenied) {
                console.error(err.stack ? err.stack : `${err.name}: ${err.message}`);
            } else {
                throw err;
            }
        }
    }
    [Symbol.for("Deno.customInspect")](inspect) {
        return `${this.constructor.name} ${inspect({})}`;
    }
    [Symbol.for("nodejs.util.inspect.custom")](depth, // deno-lint-ignore no-explicit-any
    options, inspect) {
        if (depth < 0) {
            return options.stylize(`[${this.constructor.name}]`, "special");
        }
        const newOptions = Object.assign({}, options, {
            depth: options.depth === null ? null : options.depth - 1
        });
        return `${options.stylize(this.constructor.name, "special")} ${inspect({}, newOptions)}`;
    }
}
//# sourceMappingURL=data:application/json;base64,eyJ2ZXJzaW9uIjozLCJzb3VyY2VzIjpbImh0dHBzOi8vZGVuby5sYW5kL3gvb2FrQHYxMC42LjAvbXVsdGlwYXJ0LnRzIl0sInNvdXJjZXNDb250ZW50IjpbIi8vIENvcHlyaWdodCAyMDE4LTIwMjIgdGhlIG9hayBhdXRob3JzLiBBbGwgcmlnaHRzIHJlc2VydmVkLiBNSVQgbGljZW5zZS5cblxuaW1wb3J0IHsgQnVmUmVhZGVyLCBSZWFkTGluZVJlc3VsdCB9IGZyb20gXCIuL2J1Zl9yZWFkZXIudHNcIjtcbmltcG9ydCB7IGdldEZpbGVuYW1lIH0gZnJvbSBcIi4vY29udGVudF9kaXNwb3NpdGlvbi50c1wiO1xuaW1wb3J0IHsgZXF1YWxzLCBleHRlbnNpb24sIHdyaXRlQWxsIH0gZnJvbSBcIi4vZGVwcy50c1wiO1xuaW1wb3J0IHsgcmVhZEhlYWRlcnMsIHRvUGFyYW1SZWdFeHAsIHVucXVvdGUgfSBmcm9tIFwiLi9oZWFkZXJzLnRzXCI7XG5pbXBvcnQgeyBodHRwRXJyb3JzIH0gZnJvbSBcIi4vaHR0cEVycm9yLnRzXCI7XG5pbXBvcnQgeyBnZXRSYW5kb21GaWxlbmFtZSwgc2tpcExXU1BDaGFyLCBzdHJpcEVvbCB9IGZyb20gXCIuL3V0aWwudHNcIjtcblxuY29uc3QgZGVjb2RlciA9IG5ldyBUZXh0RGVjb2RlcigpO1xuY29uc3QgZW5jb2RlciA9IG5ldyBUZXh0RW5jb2RlcigpO1xuXG5jb25zdCBCT1VOREFSWV9QQVJBTV9SRUdFWCA9IHRvUGFyYW1SZWdFeHAoXCJib3VuZGFyeVwiLCBcImlcIik7XG5jb25zdCBERUZBVUxUX0JVRkZFUl9TSVpFID0gMV8wNDhfNTc2OyAvLyAxbWJcbmNvbnN0IERFRkFVTFRfTUFYX0ZJTEVfU0laRSA9IDEwXzQ4NV83NjA7IC8vIDEwbWJcbmNvbnN0IERFRkFVTFRfTUFYX1NJWkUgPSAwOyAvLyBhbGwgZmlsZXMgd3JpdHRlbiB0byBkaXNjXG5jb25zdCBOQU1FX1BBUkFNX1JFR0VYID0gdG9QYXJhbVJlZ0V4cChcIm5hbWVcIiwgXCJpXCIpO1xuXG4vKiogV2hlbiByZWFkaW5nIGEgYm9keSBpbiBmdWxsIHZpYSBgLnJlYWQoKWAgZnJvbSBhIHtAbGlua2NvZGUgRm9ybURhdGFSZWFkZXJ9XG4gKiB0aGlzIGlzIHdoYXQgaXMgd2hhdCB0aGUgdmFsdWUgaXMgcmVzb2x2ZWQsIHByb3ZpZGluZyBhIHNwbGl0IGJldHdlZW4gYW55XG4gKiBmaWVsZHMsIGFuZCBtdWx0aS1wYXJ0IGZpbGVzIHRoYXQgd2VyZSBwcm92aWRlZC4gKi9cbmV4cG9ydCBpbnRlcmZhY2UgRm9ybURhdGFCb2R5IHtcbiAgLyoqIEEgcmVjb3JkIG9mIGZvcm0gcGFydHMgd2hlcmUgdGhlIGtleSB3YXMgdGhlIGBuYW1lYCBvZiB0aGUgcGFydCBhbmQgdGhlXG4gICAqIHZhbHVlIHdhcyB0aGUgdmFsdWUgb2YgdGhlIHBhcnQuIFRoaXMgcmVjb3JkIGRvZXMgbm90IGluY2x1ZGUgYW55IGZpbGVzXG4gICAqIHRoYXQgd2VyZSBwYXJ0IG9mIHRoZSBmb3JtIGRhdGEuXG4gICAqXG4gICAqICpOb3RlKjogRHVwbGljYXRlIG5hbWVzIGFyZSBub3QgaW5jbHVkZWQgaW4gdGhpcyByZWNvcmQsIGlmIHRoZXJlIGFyZVxuICAgKiBkdXBsaWNhdGVzLCB0aGUgbGFzdCB2YWx1ZSB3aWxsIGJlIHRoZSB2YWx1ZSB0aGF0IGlzIHNldCBoZXJlLiAgSWYgdGhlcmVcbiAgICogaXMgYSBwb3NzaWJpbGl0eSBvZiBkdXBsaWNhdGUgdmFsdWVzLCB1c2UgdGhlIGAuc3RyZWFtKClgIG1ldGhvZCBvblxuICAgKiB7QGxpbmtjb2RlIEZvcm1EYXRhUmVhZGVyfSB0byBpdGVyYXRlIG92ZXIgdGhlIHZhbHVlcy4gKi9cbiAgZmllbGRzOiBSZWNvcmQ8c3RyaW5nLCBzdHJpbmc+O1xuXG4gIC8qKiBBbiBhcnJheSBvZiBhbnkgZmlsZXMgdGhhdCB3ZXJlIHBhcnQgb2YgdGhlIGZvcm0gZGF0YS4gKi9cbiAgZmlsZXM/OiBGb3JtRGF0YUZpbGVbXTtcbn1cblxuLyoqIEEgcmVwcmVzZW50YXRpb24gb2YgYSBmaWxlIHRoYXQgaGFzIGJlZW4gcmVhZCBmcm9tIGEgZm9ybSBkYXRhIGJvZHkuIEJhc2VkXG4gKiBvbiB0aGUge0BsaW5rY29kZSBGb3JtRGF0YVJlYWRPcHRpb25zfSB0aGF0IHdlcmUgcGFzc2VkIHdoZW4gcmVhZGluZyB3aWxsXG4gKiBkZXRlcm1pbmUgaWYgZmlsZXMgYXJlIHdyaXR0ZW4gdG8gZGlzayBvciBub3QgYW5kIGhvdyB0aGV5IGFyZSB3cml0dGVuIHRvXG4gKiBkaXNrLiAgV2hlbiB3cml0dGVuIHRvIGRpc2ssIHRoZSBleHRlbnNpb24gb2YgdGhlIGZpbGUgd2lsbCBiZSBkZXRlcm1pbmVkIGJ5XG4gKiB0aGUgY29udGVudCB0eXBlLCB3aXRoIHRoZSBgLmZpbGVuYW1lYCBwcm9wZXJ0eSBjb250YWluaW5nIHRoZSBmdWxsIHBhdGggdG9cbiAqIHRoZSBmaWxlLlxuICpcbiAqIFRoZSBvcmlnaW5hbCBmaWxlbmFtZSBhcyBwYXJ0IG9mIHRoZSBmb3JtIGRhdGEgaXMgYXZhaWxhYmxlIGluXG4gKiBgb3JpZ2luYWxOYW1lYCwgYnV0IGZvciBzZWN1cml0eSBhbmQgc3RhYmlsaXR5IHJlYXNvbnMsIGl0IGlzIG5vdCB1c2VkIHRvXG4gKiBkZXRlcm1pbmUgdGhlIG5hbWUgb2YgdGhlIGZpbGUgb24gZGlzay4gSWYgZnVydGhlciBwcm9jZXNzaW5nIG9yIHJlbmFtaW5nXG4gKiBpcyByZXF1aXJlZCwgdGhlIGltcGxlbWVudG9yIHNob3VsZCBkbyB0aGF0IHByb2Nlc3NpbmcuICovXG5leHBvcnQgaW50ZXJmYWNlIEZvcm1EYXRhRmlsZSB7XG4gIC8qKiBXaGVuIHRoZSBmaWxlIGhhcyBub3QgYmVlbiB3cml0dGVuIG91dCB0byBkaXNjLCB0aGUgY29udGVudHMgb2YgdGhlIGZpbGVcbiAgICogYXMgYSB7QGxpbmtjb2RlIFVpbnQ4QXJyYXl9LiAqL1xuICBjb250ZW50PzogVWludDhBcnJheTtcblxuICAvKiogVGhlIGNvbnRlbnQgdHlwZSBvZiB0aGUgZm9ybSBkYXRhIGZpbGUuICovXG4gIGNvbnRlbnRUeXBlOiBzdHJpbmc7XG5cbiAgLyoqIFdoZW4gdGhlIGZpbGUgaGFzIGJlZW4gd3JpdHRlbiBvdXQgdG8gZGlzYywgdGhlIGZ1bGwgcGF0aCB0byB0aGUgZmlsZS4gKi9cbiAgZmlsZW5hbWU/OiBzdHJpbmc7XG5cbiAgLyoqIFRoZSBgbmFtZWAgdGhhdCB3YXMgYXNzaWduZWQgdG8gdGhlIGZvcm0gZGF0YSBmaWxlLiAqL1xuICBuYW1lOiBzdHJpbmc7XG5cbiAgLyoqIFRoZSBgZmlsZW5hbWVgIHRoYXQgd2FzIHByb3ZpZGVkIGluIHRoZSBmb3JtIGRhdGEgZmlsZS4gKi9cbiAgb3JpZ2luYWxOYW1lOiBzdHJpbmc7XG59XG5cbi8qKiBPcHRpb25zIHdoaWNoIGltcGFjdCBob3cgdGhlIGZvcm0gZGF0YSBpcyBkZWNvZGVkIGZvciBhXG4gKiB7QGxpbmtjb2RlIEZvcm1EYXRhUmVhZGVyfS4gQWxsIHRoZXNlIG9wdGlvbnMgaGF2ZSBzZW5zaWJsZSBkZWZhdWx0cyBmb3JcbiAqIG1vc3QgYXBwbGljYXRpb25zLCBidXQgY2FuIGJlIG1vZGlmaWVkIGZvciBkaWZmZXJlbnQgdXNlIGNhc2VzLiBNYW55IG9mIHRoZXNlXG4gKiBvcHRpb25zIGNhbiBoYXZlIGFuIGltcGFjdCBvbiB0aGUgc3RhYmlsaXR5IG9mIGEgc2VydmVyLCBlc3BlY2lhbGx5IGlmIHRoZXJlXG4gKiBpcyBzb21lb25lIGF0dGVtcHRpbmcgYSBkZW5pYWwgb2Ygc2VydmljZSBhdHRhY2sgb24geW91ciBzZXJ2ZXIsIHNvIGJlXG4gKiBjYXJlZnVsIHdoZW4gY2hhbmdpbmcgdGhlIGRlZmF1bHRzLiAqL1xuZXhwb3J0IGludGVyZmFjZSBGb3JtRGF0YVJlYWRPcHRpb25zIHtcbiAgLyoqIFRoZSBzaXplIG9mIHRoZSBidWZmZXIgdG8gcmVhZCBmcm9tIHRoZSByZXF1ZXN0IGJvZHkgYXQgYSBzaW5nbGUgdGltZS5cbiAgICogVGhpcyBkZWZhdWx0cyB0byAxbWIuICovXG4gIGJ1ZmZlclNpemU/OiBudW1iZXI7XG5cbiAgLyoqIEEgbWFwcGluZyBvZiBjdXN0b20gbWVkaWEgdHlwZXMgdGhhdCBhcmUgc3VwcG9ydGVkLCBtYXBwZWQgdG8gdGhlaXJcbiAgICogZXh0ZW5zaW9uIHdoZW4gZGV0ZXJtaW5pbmcgdGhlIGV4dGVuc2lvbiBmb3IgYSBmaWxlLiBUaGUga2V5IHNob3VsZCBiZSBhblxuICAgKiBhbGwgbG93ZXJjYXNlIG1lZGlhIHR5cGUgd2l0aCB0aGUgdmFsdWUgYmVpbmcgdGhlIGV4dGVuc2lvbiAod2l0aG91dCBhblxuICAgKiBpbml0aWFsIHBlcmlvZCksIHRvIGJlIHVzZWQgd2hlbiBkZWNvZGluZyB0aGUgZmlsZS5cbiAgICpcbiAgICogIyMjIEV4YW1wbGVcbiAgICpcbiAgICogRm9ybSBkYXRhIHRoYXQgaXMgc2VudCB3aXRoIGNvbnRlbnQgaGF2aW5nIGEgdHlwZSBvZiBgdGV4dC92ZG4uY3VzdG9tYCB3aWxsXG4gICAqIGJlIGRlY29kZWQgYW5kIGFzc2lnbmVkIGEgZmlsZW5hbWUgZW5kaW5nIHdpdGggYC50eHRgOlxuICAgKlxuICAgKiBgYGB0c1xuICAgKiBpbXBvcnQgeyBBcHBsaWNhdGlvbiB9IGZyb20gXCJodHRwczovL2Rlbm8ubGFuZC94L29hay9tb2QudHNcIjtcbiAgICpcbiAgICogY29uc3QgYXBwID0gbmV3IEFwcGxpY2F0aW9uKCk7XG4gICAqIGFwcC51c2UoYXN5bmMgKGN0eCkgPT4ge1xuICAgKiAgIGNvbnN0IGJvZHkgPSBjdHgucmVxdWVzdC5ib2R5KCk7XG4gICAqICAgaWYgKGJvZHkudHlwZSA9PT0gXCJmb3JtLWRhdGFcIikge1xuICAgKiAgICAgY29uc3QgZm9ybWF0RGF0YSA9IGF3YWl0IGJvZHkudmFsdWUucmVhZCh7XG4gICAqICAgICAgIGN1c3RvbUNvbnRlbnRUeXBlczoge1xuICAgKiAgICAgICAgIFwidGV4dC92bmQuY3VzdG9tXCI6IFwidHh0XCJcbiAgICogICAgICAgfVxuICAgKiAgICAgfSk7XG4gICAqICAgICBjb25zb2xlLmxvZyhmb3JtRGF0YSk7XG4gICAqICAgfVxuICAgKiB9KTtcbiAgICogYGBgXG4gICAqL1xuICBjdXN0b21Db250ZW50VHlwZXM/OiBSZWNvcmQ8c3RyaW5nLCBzdHJpbmc+O1xuXG4gIC8qKiBUaGUgbWF4aW11bSBmaWxlIHNpemUgdGhhdCBjYW4gYmUgaGFuZGxlZC4gIFRoaXMgZGVmYXVsdHMgdG8gMTBNQiB3aGVuXG4gICAqIG5vdCBzcGVjaWZpZWQuICBUaGlzIGlzIHRvIHRyeSB0byBhdm9pZCBET1MgYXR0YWNrcyB3aGVyZSBzb21lb25lIHdvdWxkXG4gICAqIGNvbnRpbnVlIHRvIHRyeSB0byBzZW5kIGEgXCJmaWxlXCIgY29udGludW91c2x5IHVudGlsIGEgaG9zdCBsaW1pdCB3YXNcbiAgICogcmVhY2hlZCBjcmFzaGluZyB0aGUgc2VydmVyIG9yIHRoZSBob3N0LiAqL1xuICBtYXhGaWxlU2l6ZT86IG51bWJlcjtcblxuICAvKiogVGhlIG1heGltdW0gc2l6ZSBvZiBhIGZpbGUgdG8gaG9sZCBpbiBtZW1vcnksIGFuZCBub3Qgd3JpdGUgdG8gZGlzay4gVGhpc1xuICAgKiBkZWZhdWx0cyB0byBgMGAsIHNvIHRoYXQgYWxsIG11bHRpcGFydCBmb3JtIGZpbGVzIGFyZSB3cml0dGVuIHRvIGRpc2suXG4gICAqIFdoZW4gc2V0IHRvIGEgcG9zaXRpdmUgaW50ZWdlciwgaWYgdGhlIGZvcm0gZGF0YSBmaWxlIGlzIHNtYWxsZXIsIGl0IHdpbGxcbiAgICogYmUgcmV0YWluZWQgaW4gbWVtb3J5IGFuZCBhdmFpbGFibGUgaW4gdGhlIGAuY29udGVudGAgcHJvcGVydHkgb2YgdGhlXG4gICAqIGBGb3JtRGF0YUZpbGVgIG9iamVjdC4gIElmIHRoZSBmaWxlIGV4Y2VlZHMgdGhlIGBtYXhTaXplYCBpdCB3aWxsIGJlXG4gICAqIHdyaXR0ZW4gdG8gZGlzayBhbmQgdGhlIGBmaWxlbmFtZWAgZmlsZSB3aWxsIGNvbnRhaW4gdGhlIGZ1bGwgcGF0aCB0byB0aGVcbiAgICogb3V0cHV0IGZpbGUuICovXG4gIG1heFNpemU/OiBudW1iZXI7XG5cbiAgLyoqIFdoZW4gd3JpdGluZyBmb3JtIGRhdGEgZmlsZXMgdG8gZGlzaywgdGhlIG91dHB1dCBwYXRoLiAgVGhpcyB3aWxsIGRlZmF1bHRcbiAgICogdG8gYSB0ZW1wb3JhcnkgcGF0aCBnZW5lcmF0ZWQgYnkgYERlbm8ubWFrZVRlbXBEaXIoKWAuICovXG4gIG91dFBhdGg/OiBzdHJpbmc7XG5cbiAgLyoqIFdoZW4gYSBmb3JtIGRhdGEgZmlsZSBpcyB3cml0dGVuIHRvIGRpc2ssIGl0IHdpbGwgYmUgZ2VuZXJhdGVkIHdpdGggYVxuICAgKiByYW5kb20gZmlsZW5hbWUgYW5kIGhhdmUgYW4gZXh0ZW5zaW9uIGJhc2VkIG9mZiB0aGUgY29udGVudCB0eXBlIGZvciB0aGVcbiAgICogZmlsZS4gIGBwcmVmaXhgIGNhbiBiZSBzcGVjaWZpZWQgdGhvdWdoIHRvIHByZXBlbmQgdG8gdGhlIGZpbGUgbmFtZS4gKi9cbiAgcHJlZml4Pzogc3RyaW5nO1xufVxuXG5pbnRlcmZhY2UgUGFydHNPcHRpb25zIHtcbiAgYm9keTogQnVmUmVhZGVyO1xuICBjdXN0b21Db250ZW50VHlwZXM/OiBSZWNvcmQ8c3RyaW5nLCBzdHJpbmc+O1xuICBmaW5hbDogVWludDhBcnJheTtcbiAgbWF4RmlsZVNpemU6IG51bWJlcjtcbiAgbWF4U2l6ZTogbnVtYmVyO1xuICBvdXRQYXRoPzogc3RyaW5nO1xuICBwYXJ0OiBVaW50OEFycmF5O1xuICBwcmVmaXg/OiBzdHJpbmc7XG59XG5cbmZ1bmN0aW9uIGFwcGVuZChhOiBVaW50OEFycmF5LCBiOiBVaW50OEFycmF5KTogVWludDhBcnJheSB7XG4gIGNvbnN0IGFiID0gbmV3IFVpbnQ4QXJyYXkoYS5sZW5ndGggKyBiLmxlbmd0aCk7XG4gIGFiLnNldChhLCAwKTtcbiAgYWIuc2V0KGIsIGEubGVuZ3RoKTtcbiAgcmV0dXJuIGFiO1xufVxuXG5mdW5jdGlvbiBpc0VxdWFsKGE6IFVpbnQ4QXJyYXksIGI6IFVpbnQ4QXJyYXkpOiBib29sZWFuIHtcbiAgcmV0dXJuIGVxdWFscyhza2lwTFdTUENoYXIoYSksIGIpO1xufVxuXG5hc3luYyBmdW5jdGlvbiByZWFkVG9TdGFydE9yRW5kKFxuICBib2R5OiBCdWZSZWFkZXIsXG4gIHN0YXJ0OiBVaW50OEFycmF5LFxuICBlbmQ6IFVpbnQ4QXJyYXksXG4pOiBQcm9taXNlPGJvb2xlYW4+IHtcbiAgbGV0IGxpbmVSZXN1bHQ6IFJlYWRMaW5lUmVzdWx0IHwgbnVsbDtcbiAgd2hpbGUgKChsaW5lUmVzdWx0ID0gYXdhaXQgYm9keS5yZWFkTGluZSgpKSkge1xuICAgIGlmIChpc0VxdWFsKGxpbmVSZXN1bHQuYnl0ZXMsIHN0YXJ0KSkge1xuICAgICAgcmV0dXJuIHRydWU7XG4gICAgfVxuICAgIGlmIChpc0VxdWFsKGxpbmVSZXN1bHQuYnl0ZXMsIGVuZCkpIHtcbiAgICAgIHJldHVybiBmYWxzZTtcbiAgICB9XG4gIH1cbiAgdGhyb3cgbmV3IGh0dHBFcnJvcnMuQmFkUmVxdWVzdChcbiAgICBcIlVuYWJsZSB0byBmaW5kIG11bHRpLXBhcnQgYm91bmRhcnkuXCIsXG4gICk7XG59XG5cbi8qKiBZaWVsZCB1cCBpbmRpdmlkdWFsIHBhcnRzIGJ5IHJlYWRpbmcgdGhlIGJvZHkgYW5kIHBhcnNpbmcgb3V0IHRoZSBmb3JkXG4gKiBkYXRhIHZhbHVlcy4gKi9cbmFzeW5jIGZ1bmN0aW9uKiBwYXJ0cyhcbiAge1xuICAgIGJvZHksXG4gICAgY3VzdG9tQ29udGVudFR5cGVzID0ge30sXG4gICAgZmluYWwsXG4gICAgcGFydCxcbiAgICBtYXhGaWxlU2l6ZSxcbiAgICBtYXhTaXplLFxuICAgIG91dFBhdGgsXG4gICAgcHJlZml4LFxuICB9OiBQYXJ0c09wdGlvbnMsXG4pOiBBc3luY0l0ZXJhYmxlSXRlcmF0b3I8W3N0cmluZywgc3RyaW5nIHwgRm9ybURhdGFGaWxlXT4ge1xuICBhc3luYyBmdW5jdGlvbiBnZXRGaWxlKGNvbnRlbnRUeXBlOiBzdHJpbmcpOiBQcm9taXNlPFtzdHJpbmcsIERlbm8uRnNGaWxlXT4ge1xuICAgIGNvbnN0IGV4dCA9IGN1c3RvbUNvbnRlbnRUeXBlc1tjb250ZW50VHlwZS50b0xvd2VyQ2FzZSgpXSA/P1xuICAgICAgZXh0ZW5zaW9uKGNvbnRlbnRUeXBlKTtcbiAgICBpZiAoIWV4dCkge1xuICAgICAgdGhyb3cgbmV3IGh0dHBFcnJvcnMuQmFkUmVxdWVzdChcbiAgICAgICAgYFRoZSBmb3JtIGNvbnRhaW5lZCBjb250ZW50IHR5cGUgXCIke2NvbnRlbnRUeXBlfVwiIHdoaWNoIGlzIG5vdCBzdXBwb3J0ZWQgYnkgdGhlIHNlcnZlci5gLFxuICAgICAgKTtcbiAgICB9XG4gICAgaWYgKCFvdXRQYXRoKSB7XG4gICAgICBvdXRQYXRoID0gYXdhaXQgRGVuby5tYWtlVGVtcERpcigpO1xuICAgIH1cbiAgICBjb25zdCBmaWxlbmFtZSA9IGAke291dFBhdGh9LyR7YXdhaXQgZ2V0UmFuZG9tRmlsZW5hbWUocHJlZml4LCBleHQpfWA7XG4gICAgY29uc3QgZmlsZSA9IGF3YWl0IERlbm8ub3BlbihmaWxlbmFtZSwgeyB3cml0ZTogdHJ1ZSwgY3JlYXRlTmV3OiB0cnVlIH0pO1xuICAgIHJldHVybiBbZmlsZW5hbWUsIGZpbGVdO1xuICB9XG5cbiAgd2hpbGUgKHRydWUpIHtcbiAgICBjb25zdCBoZWFkZXJzID0gYXdhaXQgcmVhZEhlYWRlcnMoYm9keSk7XG4gICAgY29uc3QgY29udGVudFR5cGUgPSBoZWFkZXJzW1wiY29udGVudC10eXBlXCJdO1xuICAgIGNvbnN0IGNvbnRlbnREaXNwb3NpdGlvbiA9IGhlYWRlcnNbXCJjb250ZW50LWRpc3Bvc2l0aW9uXCJdO1xuICAgIGlmICghY29udGVudERpc3Bvc2l0aW9uKSB7XG4gICAgICB0aHJvdyBuZXcgaHR0cEVycm9ycy5CYWRSZXF1ZXN0KFxuICAgICAgICBcIkZvcm0gZGF0YSBwYXJ0IG1pc3NpbmcgY29udGVudC1kaXNwb3NpdGlvbiBoZWFkZXJcIixcbiAgICAgICk7XG4gICAgfVxuICAgIGlmICghY29udGVudERpc3Bvc2l0aW9uLm1hdGNoKC9eZm9ybS1kYXRhOy9pKSkge1xuICAgICAgdGhyb3cgbmV3IGh0dHBFcnJvcnMuQmFkUmVxdWVzdChcbiAgICAgICAgYFVuZXhwZWN0ZWQgY29udGVudC1kaXNwb3NpdGlvbiBoZWFkZXI6IFwiJHtjb250ZW50RGlzcG9zaXRpb259XCJgLFxuICAgICAgKTtcbiAgICB9XG4gICAgY29uc3QgbWF0Y2hlcyA9IE5BTUVfUEFSQU1fUkVHRVguZXhlYyhjb250ZW50RGlzcG9zaXRpb24pO1xuICAgIGlmICghbWF0Y2hlcykge1xuICAgICAgdGhyb3cgbmV3IGh0dHBFcnJvcnMuQmFkUmVxdWVzdChcbiAgICAgICAgYFVuYWJsZSB0byBkZXRlcm1pbmUgbmFtZSBvZiBmb3JtIGJvZHkgcGFydGAsXG4gICAgICApO1xuICAgIH1cbiAgICBsZXQgWywgbmFtZV0gPSBtYXRjaGVzO1xuICAgIG5hbWUgPSB1bnF1b3RlKG5hbWUpO1xuICAgIGlmIChjb250ZW50VHlwZSkge1xuICAgICAgY29uc3Qgb3JpZ2luYWxOYW1lID0gZ2V0RmlsZW5hbWUoY29udGVudERpc3Bvc2l0aW9uKTtcbiAgICAgIGxldCBieXRlTGVuZ3RoID0gMDtcbiAgICAgIGxldCBmaWxlOiBEZW5vLkZzRmlsZSB8IHVuZGVmaW5lZDtcbiAgICAgIGxldCBmaWxlbmFtZTogc3RyaW5nIHwgdW5kZWZpbmVkO1xuICAgICAgbGV0IGJ1ZjogVWludDhBcnJheSB8IHVuZGVmaW5lZDtcbiAgICAgIGlmIChtYXhTaXplKSB7XG4gICAgICAgIGJ1ZiA9IG5ldyBVaW50OEFycmF5KCk7XG4gICAgICB9IGVsc2Uge1xuICAgICAgICBjb25zdCByZXN1bHQgPSBhd2FpdCBnZXRGaWxlKGNvbnRlbnRUeXBlKTtcbiAgICAgICAgZmlsZW5hbWUgPSByZXN1bHRbMF07XG4gICAgICAgIGZpbGUgPSByZXN1bHRbMV07XG4gICAgICB9XG4gICAgICB3aGlsZSAodHJ1ZSkge1xuICAgICAgICBjb25zdCByZWFkUmVzdWx0ID0gYXdhaXQgYm9keS5yZWFkTGluZShmYWxzZSk7XG4gICAgICAgIGlmICghcmVhZFJlc3VsdCkge1xuICAgICAgICAgIHRocm93IG5ldyBodHRwRXJyb3JzLkJhZFJlcXVlc3QoXCJVbmV4cGVjdGVkIEVPRiByZWFjaGVkXCIpO1xuICAgICAgICB9XG4gICAgICAgIGNvbnN0IHsgYnl0ZXMgfSA9IHJlYWRSZXN1bHQ7XG4gICAgICAgIGNvbnN0IHN0cmlwcGVkQnl0ZXMgPSBzdHJpcEVvbChieXRlcyk7XG4gICAgICAgIGlmIChpc0VxdWFsKHN0cmlwcGVkQnl0ZXMsIHBhcnQpIHx8IGlzRXF1YWwoc3RyaXBwZWRCeXRlcywgZmluYWwpKSB7XG4gICAgICAgICAgaWYgKGZpbGUpIHtcbiAgICAgICAgICAgIC8vIHJlbW92ZSBleHRyYSAyIGJ5dGVzIChbQ1IsIExGXSkgZnJvbSByZXN1bHQgZmlsZVxuICAgICAgICAgICAgY29uc3QgYnl0ZXNEaWZmID0gYnl0ZXMubGVuZ3RoIC0gc3RyaXBwZWRCeXRlcy5sZW5ndGg7XG4gICAgICAgICAgICBpZiAoYnl0ZXNEaWZmKSB7XG4gICAgICAgICAgICAgIGNvbnN0IG9yaWdpbmFsQnl0ZXNTaXplID0gYXdhaXQgZmlsZS5zZWVrKFxuICAgICAgICAgICAgICAgIC1ieXRlc0RpZmYsXG4gICAgICAgICAgICAgICAgRGVuby5TZWVrTW9kZS5DdXJyZW50LFxuICAgICAgICAgICAgICApO1xuICAgICAgICAgICAgICBhd2FpdCBmaWxlLnRydW5jYXRlKG9yaWdpbmFsQnl0ZXNTaXplKTtcbiAgICAgICAgICAgIH1cblxuICAgICAgICAgICAgZmlsZS5jbG9zZSgpO1xuICAgICAgICAgIH1cbiAgICAgICAgICB5aWVsZCBbXG4gICAgICAgICAgICBuYW1lLFxuICAgICAgICAgICAge1xuICAgICAgICAgICAgICBjb250ZW50OiBidWYsXG4gICAgICAgICAgICAgIGNvbnRlbnRUeXBlLFxuICAgICAgICAgICAgICBuYW1lLFxuICAgICAgICAgICAgICBmaWxlbmFtZSxcbiAgICAgICAgICAgICAgb3JpZ2luYWxOYW1lLFxuICAgICAgICAgICAgfSBhcyBGb3JtRGF0YUZpbGUsXG4gICAgICAgICAgXTtcbiAgICAgICAgICBpZiAoaXNFcXVhbChzdHJpcHBlZEJ5dGVzLCBmaW5hbCkpIHtcbiAgICAgICAgICAgIHJldHVybjtcbiAgICAgICAgICB9XG4gICAgICAgICAgYnJlYWs7XG4gICAgICAgIH1cbiAgICAgICAgYnl0ZUxlbmd0aCArPSBieXRlcy5ieXRlTGVuZ3RoO1xuICAgICAgICBpZiAoYnl0ZUxlbmd0aCA+IG1heEZpbGVTaXplKSB7XG4gICAgICAgICAgaWYgKGZpbGUpIHtcbiAgICAgICAgICAgIGZpbGUuY2xvc2UoKTtcbiAgICAgICAgICB9XG4gICAgICAgICAgdGhyb3cgbmV3IGh0dHBFcnJvcnMuUmVxdWVzdEVudGl0eVRvb0xhcmdlKFxuICAgICAgICAgICAgYEZpbGUgc2l6ZSBleGNlZWRzIGxpbWl0IG9mICR7bWF4RmlsZVNpemV9IGJ5dGVzLmAsXG4gICAgICAgICAgKTtcbiAgICAgICAgfVxuICAgICAgICBpZiAoYnVmKSB7XG4gICAgICAgICAgaWYgKGJ5dGVMZW5ndGggPiBtYXhTaXplKSB7XG4gICAgICAgICAgICBjb25zdCByZXN1bHQgPSBhd2FpdCBnZXRGaWxlKGNvbnRlbnRUeXBlKTtcbiAgICAgICAgICAgIGZpbGVuYW1lID0gcmVzdWx0WzBdO1xuICAgICAgICAgICAgZmlsZSA9IHJlc3VsdFsxXTtcbiAgICAgICAgICAgIGF3YWl0IHdyaXRlQWxsKGZpbGUsIGJ1Zik7XG4gICAgICAgICAgICBidWYgPSB1bmRlZmluZWQ7XG4gICAgICAgICAgfSBlbHNlIHtcbiAgICAgICAgICAgIGJ1ZiA9IGFwcGVuZChidWYsIGJ5dGVzKTtcbiAgICAgICAgICB9XG4gICAgICAgIH1cbiAgICAgICAgaWYgKGZpbGUpIHtcbiAgICAgICAgICBhd2FpdCB3cml0ZUFsbChmaWxlLCBieXRlcyk7XG4gICAgICAgIH1cbiAgICAgIH1cbiAgICB9IGVsc2Uge1xuICAgICAgY29uc3QgbGluZXM6IHN0cmluZ1tdID0gW107XG4gICAgICB3aGlsZSAodHJ1ZSkge1xuICAgICAgICBjb25zdCByZWFkUmVzdWx0ID0gYXdhaXQgYm9keS5yZWFkTGluZSgpO1xuICAgICAgICBpZiAoIXJlYWRSZXN1bHQpIHtcbiAgICAgICAgICB0aHJvdyBuZXcgaHR0cEVycm9ycy5CYWRSZXF1ZXN0KFwiVW5leHBlY3RlZCBFT0YgcmVhY2hlZFwiKTtcbiAgICAgICAgfVxuICAgICAgICBjb25zdCB7IGJ5dGVzIH0gPSByZWFkUmVzdWx0O1xuICAgICAgICBpZiAoaXNFcXVhbChieXRlcywgcGFydCkgfHwgaXNFcXVhbChieXRlcywgZmluYWwpKSB7XG4gICAgICAgICAgeWllbGQgW25hbWUsIGxpbmVzLmpvaW4oXCJcXG5cIildO1xuICAgICAgICAgIGlmIChpc0VxdWFsKGJ5dGVzLCBmaW5hbCkpIHtcbiAgICAgICAgICAgIHJldHVybjtcbiAgICAgICAgICB9XG4gICAgICAgICAgYnJlYWs7XG4gICAgICAgIH1cbiAgICAgICAgbGluZXMucHVzaChkZWNvZGVyLmRlY29kZShieXRlcykpO1xuICAgICAgfVxuICAgIH1cbiAgfVxufVxuXG4vKiogQW4gaW50ZXJmYWNlIHdoaWNoIHByb3ZpZGVzIGFuIGludGVyZmFjZSB0byBhY2Nlc3MgdGhlIGZpZWxkcyBvZiBhXG4gKiBgbXVsdGlwYXJ0L2Zvcm0tZGF0YWAgYm9keS5cbiAqXG4gKiBOb3JtYWxseSBhbiBpbnN0YW5jZSBvZiB0aGlzIGlzIGFjY2Vzc2VkIHdoZW4gaGFuZGxpbmcgYSByZXF1ZXN0IGJvZHksIGFuZFxuICogZGVhbGluZyB3aXRoIGRlY29kaW5nIGl0LiAgVGhlcmUgYXJlIG9wdGlvbnMgdGhhdCBjYW4gYmUgc2V0IHdoZW4gYXR0ZW1wdGluZ1xuICogdG8gcmVhZCBhIG11bHRpLXBhcnQgYm9keSAoc2VlOiB7QGxpbmtjb2RlIEZvcm1EYXRhUmVhZE9wdGlvbnN9KS5cbiAqXG4gKiBJZiB5b3UgYC5yZWFkKClgIHRoZSB2YWx1ZSwgdGhlbiBhIHByb21pc2UgaXMgcHJvdmlkZWQgb2YgdHlwZVxuICoge0BsaW5rY29kZSBGb3JtRGF0YUJvZHl9LiBJZiB5b3UgdXNlIHRoZSBgLnN0cmVhbSgpYCBwcm9wZXJ0eSwgaXQgaXMgYW4gYXN5bmNcbiAqIGl0ZXJhdG9yIHdoaWNoIHlpZWxkcyB1cCBhIHR1cGxlIG9mIHdpdGggdGhlIGZpcnN0IGVsZW1lbnQgYmVpbmcgYVxuICpcbiAqICMjIyBFeGFtcGxlc1xuICpcbiAqIFVzaW5nIGAucmVhZCgpYDpcbiAqXG4gKiBgYGB0c1xuICogaW1wb3J0IHsgQXBwbGljYXRpb24gfSBmcm9tIFwiaHR0cHM6Ly9kZW5vLmxhbmQveC9vYWsvbW9kLnRzXCI7XG4gKlxuICogY29uc3QgYXBwID0gbmV3IEFwcGxpY2F0aW9uKCk7XG4gKlxuICogYXBwLnVzZShhc3luYyAoY3R4KSA9PiB7XG4gKiAgIGNvbnN0IGJvZHkgPSBjdHgucmVxdWVzdC5ib2R5KCk7XG4gKiAgIGlmIChib2R5LnR5cGUgPT09IFwiZm9ybS1kYXRhXCIpIHtcbiAqICAgICBjb25zdCB2YWx1ZSA9IGF3YWl0IGJvZHkudmFsdWU7XG4gKiAgICAgY29uc3QgZm9ybURhdGEgPSBhd2FpdCB2YWx1ZS5yZWFkKCk7XG4gKiAgICAgLy8gdGhlIGZvcm0gZGF0YSBpcyBmdWxseSBhdmFpbGFibGVcbiAqICAgfVxuICogfSk7XG4gKiBgYGBcbiAqXG4gKiAgVXNpbmcgYC5zdHJlYW0oKWA6XG4gKlxuICogYGBgdHNcbiAqIGltcG9ydCB7IEFwcGxpY2F0aW9uIH0gZnJvbSBcImh0dHBzOi8vZGVuby5sYW5kL3gvb2FrL21vZC50c1wiO1xuICpcbiAqIGNvbnN0IGFwcCA9IG5ldyBBcHBsaWNhdGlvbigpO1xuICpcbiAqIGFwcC51c2UoYXN5bmMgKGN0eCkgPT4ge1xuICogICBjb25zdCBib2R5ID0gY3R4LnJlcXVlc3QuYm9keSgpO1xuICogICBpZiAoYm9keS50eXBlID09PSBcImZvcm0tZGF0YVwiKSB7XG4gKiAgICAgY29uc3QgdmFsdWUgPSBhd2FpdCBib2R5LnZhbHVlO1xuICogICAgIGZvciBhd2FpdCAoY29uc3QgW25hbWUsIHZhbHVlXSBvZiB2YWx1ZS5zdHJlYW0oKSkge1xuICogICAgICAgLy8gYXN5bmNocm9ub3VzbHkgaXRlcmF0ZSBlYWNoIHBhcnQgb2YgdGhlIGJvZHlcbiAqICAgICB9XG4gKiAgIH1cbiAqIH0pO1xuICogYGBgXG4gKi9cbmV4cG9ydCBjbGFzcyBGb3JtRGF0YVJlYWRlciB7XG4gICNib2R5OiBEZW5vLlJlYWRlcjtcbiAgI2JvdW5kYXJ5RmluYWw6IFVpbnQ4QXJyYXk7XG4gICNib3VuZGFyeVBhcnQ6IFVpbnQ4QXJyYXk7XG4gICNyZWFkaW5nID0gZmFsc2U7XG5cbiAgY29uc3RydWN0b3IoY29udGVudFR5cGU6IHN0cmluZywgYm9keTogRGVuby5SZWFkZXIpIHtcbiAgICBjb25zdCBtYXRjaGVzID0gY29udGVudFR5cGUubWF0Y2goQk9VTkRBUllfUEFSQU1fUkVHRVgpO1xuICAgIGlmICghbWF0Y2hlcykge1xuICAgICAgdGhyb3cgbmV3IGh0dHBFcnJvcnMuQmFkUmVxdWVzdChcbiAgICAgICAgYENvbnRlbnQgdHlwZSBcIiR7Y29udGVudFR5cGV9XCIgZG9lcyBub3QgY29udGFpbiBhIHZhbGlkIGJvdW5kYXJ5LmAsXG4gICAgICApO1xuICAgIH1cbiAgICBsZXQgWywgYm91bmRhcnldID0gbWF0Y2hlcztcbiAgICBib3VuZGFyeSA9IHVucXVvdGUoYm91bmRhcnkpO1xuICAgIHRoaXMuI2JvdW5kYXJ5UGFydCA9IGVuY29kZXIuZW5jb2RlKGAtLSR7Ym91bmRhcnl9YCk7XG4gICAgdGhpcy4jYm91bmRhcnlGaW5hbCA9IGVuY29kZXIuZW5jb2RlKGAtLSR7Ym91bmRhcnl9LS1gKTtcbiAgICB0aGlzLiNib2R5ID0gYm9keTtcbiAgfVxuXG4gIC8qKiBSZWFkcyB0aGUgbXVsdGlwYXJ0IGJvZHkgb2YgdGhlIHJlc3BvbnNlIGFuZCByZXNvbHZlcyB3aXRoIGFuIG9iamVjdCB3aGljaFxuICAgKiBjb250YWlucyBmaWVsZHMgYW5kIGZpbGVzIHRoYXQgd2VyZSBwYXJ0IG9mIHRoZSByZXNwb25zZS5cbiAgICpcbiAgICogKk5vdGUqOiB0aGlzIG1ldGhvZCBoYW5kbGVzIG11bHRpcGxlIGZpbGVzIHdpdGggdGhlIHNhbWUgYG5hbWVgIGF0dHJpYnV0ZVxuICAgKiBpbiB0aGUgcmVxdWVzdCwgYnV0IGJ5IGRlc2lnbiBpdCBkb2VzIG5vdCBoYW5kbGUgbXVsdGlwbGUgZmllbGRzIHRoYXQgc2hhcmVcbiAgICogdGhlIHNhbWUgYG5hbWVgLiAgSWYgeW91IGV4cGVjdCB0aGUgcmVxdWVzdCBib2R5IHRvIGNvbnRhaW4gbXVsdGlwbGUgZm9ybVxuICAgKiBkYXRhIGZpZWxkcyB3aXRoIHRoZSBzYW1lIG5hbWUsIGl0IGlzIGJldHRlciB0byB1c2UgdGhlIGAuc3RyZWFtKClgIG1ldGhvZFxuICAgKiB3aGljaCB3aWxsIGl0ZXJhdGUgb3ZlciBlYWNoIGZvcm0gZGF0YSBmaWVsZCBpbmRpdmlkdWFsbHkuICovXG4gIGFzeW5jIHJlYWQob3B0aW9uczogRm9ybURhdGFSZWFkT3B0aW9ucyA9IHt9KTogUHJvbWlzZTxGb3JtRGF0YUJvZHk+IHtcbiAgICBpZiAodGhpcy4jcmVhZGluZykge1xuICAgICAgdGhyb3cgbmV3IEVycm9yKFwiQm9keSBpcyBhbHJlYWR5IGJlaW5nIHJlYWQuXCIpO1xuICAgIH1cbiAgICB0aGlzLiNyZWFkaW5nID0gdHJ1ZTtcbiAgICBjb25zdCB7XG4gICAgICBvdXRQYXRoLFxuICAgICAgbWF4RmlsZVNpemUgPSBERUZBVUxUX01BWF9GSUxFX1NJWkUsXG4gICAgICBtYXhTaXplID0gREVGQVVMVF9NQVhfU0laRSxcbiAgICAgIGJ1ZmZlclNpemUgPSBERUZBVUxUX0JVRkZFUl9TSVpFLFxuICAgICAgY3VzdG9tQ29udGVudFR5cGVzLFxuICAgIH0gPSBvcHRpb25zO1xuICAgIGNvbnN0IGJvZHkgPSBuZXcgQnVmUmVhZGVyKHRoaXMuI2JvZHksIGJ1ZmZlclNpemUpO1xuICAgIGNvbnN0IHJlc3VsdDogRm9ybURhdGFCb2R5ID0geyBmaWVsZHM6IHt9IH07XG4gICAgaWYgKFxuICAgICAgIShhd2FpdCByZWFkVG9TdGFydE9yRW5kKGJvZHksIHRoaXMuI2JvdW5kYXJ5UGFydCwgdGhpcy4jYm91bmRhcnlGaW5hbCkpXG4gICAgKSB7XG4gICAgICByZXR1cm4gcmVzdWx0O1xuICAgIH1cbiAgICB0cnkge1xuICAgICAgZm9yIGF3YWl0IChcbiAgICAgICAgY29uc3QgcGFydCBvZiBwYXJ0cyh7XG4gICAgICAgICAgYm9keSxcbiAgICAgICAgICBjdXN0b21Db250ZW50VHlwZXMsXG4gICAgICAgICAgcGFydDogdGhpcy4jYm91bmRhcnlQYXJ0LFxuICAgICAgICAgIGZpbmFsOiB0aGlzLiNib3VuZGFyeUZpbmFsLFxuICAgICAgICAgIG1heEZpbGVTaXplLFxuICAgICAgICAgIG1heFNpemUsXG4gICAgICAgICAgb3V0UGF0aCxcbiAgICAgICAgfSlcbiAgICAgICkge1xuICAgICAgICBjb25zdCBba2V5LCB2YWx1ZV0gPSBwYXJ0O1xuICAgICAgICBpZiAodHlwZW9mIHZhbHVlID09PSBcInN0cmluZ1wiKSB7XG4gICAgICAgICAgcmVzdWx0LmZpZWxkc1trZXldID0gdmFsdWU7XG4gICAgICAgIH0gZWxzZSB7XG4gICAgICAgICAgaWYgKCFyZXN1bHQuZmlsZXMpIHtcbiAgICAgICAgICAgIHJlc3VsdC5maWxlcyA9IFtdO1xuICAgICAgICAgIH1cbiAgICAgICAgICByZXN1bHQuZmlsZXMucHVzaCh2YWx1ZSk7XG4gICAgICAgIH1cbiAgICAgIH1cbiAgICB9IGNhdGNoIChlcnIpIHtcbiAgICAgIGlmIChlcnIgaW5zdGFuY2VvZiBEZW5vLmVycm9ycy5QZXJtaXNzaW9uRGVuaWVkKSB7XG4gICAgICAgIGNvbnNvbGUuZXJyb3IoZXJyLnN0YWNrID8gZXJyLnN0YWNrIDogYCR7ZXJyLm5hbWV9OiAke2Vyci5tZXNzYWdlfWApO1xuICAgICAgfSBlbHNlIHtcbiAgICAgICAgdGhyb3cgZXJyO1xuICAgICAgfVxuICAgIH1cbiAgICByZXR1cm4gcmVzdWx0O1xuICB9XG5cbiAgLyoqIFJldHVybnMgYW4gaXRlcmF0b3Igd2hpY2ggd2lsbCBhc3luY2hyb25vdXNseSB5aWVsZCBlYWNoIHBhcnQgb2YgdGhlIGZvcm1cbiAgICogZGF0YS4gIFRoZSB5aWVsZGVkIHZhbHVlIGlzIGEgdHVwbGUsIHdoZXJlIHRoZSBmaXJzdCBlbGVtZW50IGlzIHRoZSBuYW1lXG4gICAqIG9mIHRoZSBwYXJ0IGFuZCB0aGUgc2Vjb25kIGVsZW1lbnQgaXMgYSBgc3RyaW5nYCBvciBhIGBGb3JtRGF0YUZpbGVgXG4gICAqIG9iamVjdC4gKi9cbiAgYXN5bmMgKnN0cmVhbShcbiAgICBvcHRpb25zOiBGb3JtRGF0YVJlYWRPcHRpb25zID0ge30sXG4gICk6IEFzeW5jSXRlcmFibGVJdGVyYXRvcjxbbmFtZTogc3RyaW5nLCB2YWx1ZTogc3RyaW5nIHwgRm9ybURhdGFGaWxlXT4ge1xuICAgIGlmICh0aGlzLiNyZWFkaW5nKSB7XG4gICAgICB0aHJvdyBuZXcgRXJyb3IoXCJCb2R5IGlzIGFscmVhZHkgYmVpbmcgcmVhZC5cIik7XG4gICAgfVxuICAgIHRoaXMuI3JlYWRpbmcgPSB0cnVlO1xuICAgIGNvbnN0IHtcbiAgICAgIG91dFBhdGgsXG4gICAgICBjdXN0b21Db250ZW50VHlwZXMsXG4gICAgICBtYXhGaWxlU2l6ZSA9IERFRkFVTFRfTUFYX0ZJTEVfU0laRSxcbiAgICAgIG1heFNpemUgPSBERUZBVUxUX01BWF9TSVpFLFxuICAgICAgYnVmZmVyU2l6ZSA9IDMyMDAwLFxuICAgIH0gPSBvcHRpb25zO1xuICAgIGNvbnN0IGJvZHkgPSBuZXcgQnVmUmVhZGVyKHRoaXMuI2JvZHksIGJ1ZmZlclNpemUpO1xuICAgIGlmIChcbiAgICAgICEoYXdhaXQgcmVhZFRvU3RhcnRPckVuZChib2R5LCB0aGlzLiNib3VuZGFyeVBhcnQsIHRoaXMuI2JvdW5kYXJ5RmluYWwpKVxuICAgICkge1xuICAgICAgcmV0dXJuO1xuICAgIH1cbiAgICB0cnkge1xuICAgICAgZm9yIGF3YWl0IChcbiAgICAgICAgY29uc3QgcGFydCBvZiBwYXJ0cyh7XG4gICAgICAgICAgYm9keSxcbiAgICAgICAgICBjdXN0b21Db250ZW50VHlwZXMsXG4gICAgICAgICAgcGFydDogdGhpcy4jYm91bmRhcnlQYXJ0LFxuICAgICAgICAgIGZpbmFsOiB0aGlzLiNib3VuZGFyeUZpbmFsLFxuICAgICAgICAgIG1heEZpbGVTaXplLFxuICAgICAgICAgIG1heFNpemUsXG4gICAgICAgICAgb3V0UGF0aCxcbiAgICAgICAgfSlcbiAgICAgICkge1xuICAgICAgICB5aWVsZCBwYXJ0O1xuICAgICAgfVxuICAgIH0gY2F0Y2ggKGVycikge1xuICAgICAgaWYgKGVyciBpbnN0YW5jZW9mIERlbm8uZXJyb3JzLlBlcm1pc3Npb25EZW5pZWQpIHtcbiAgICAgICAgY29uc29sZS5lcnJvcihlcnIuc3RhY2sgPyBlcnIuc3RhY2sgOiBgJHtlcnIubmFtZX06ICR7ZXJyLm1lc3NhZ2V9YCk7XG4gICAgICB9IGVsc2Uge1xuICAgICAgICB0aHJvdyBlcnI7XG4gICAgICB9XG4gICAgfVxuICB9XG5cbiAgW1N5bWJvbC5mb3IoXCJEZW5vLmN1c3RvbUluc3BlY3RcIildKGluc3BlY3Q6ICh2YWx1ZTogdW5rbm93bikgPT4gc3RyaW5nKSB7XG4gICAgcmV0dXJuIGAke3RoaXMuY29uc3RydWN0b3IubmFtZX0gJHtpbnNwZWN0KHt9KX1gO1xuICB9XG5cbiAgW1N5bWJvbC5mb3IoXCJub2RlanMudXRpbC5pbnNwZWN0LmN1c3RvbVwiKV0oXG4gICAgZGVwdGg6IG51bWJlcixcbiAgICAvLyBkZW5vLWxpbnQtaWdub3JlIG5vLWV4cGxpY2l0LWFueVxuICAgIG9wdGlvbnM6IGFueSxcbiAgICBpbnNwZWN0OiAodmFsdWU6IHVua25vd24sIG9wdGlvbnM/OiB1bmtub3duKSA9PiBzdHJpbmcsXG4gICkge1xuICAgIGlmIChkZXB0aCA8IDApIHtcbiAgICAgIHJldHVybiBvcHRpb25zLnN0eWxpemUoYFske3RoaXMuY29uc3RydWN0b3IubmFtZX1dYCwgXCJzcGVjaWFsXCIpO1xuICAgIH1cblxuICAgIGNvbnN0IG5ld09wdGlvbnMgPSBPYmplY3QuYXNzaWduKHt9LCBvcHRpb25zLCB7XG4gICAgICBkZXB0aDogb3B0aW9ucy5kZXB0aCA9PT0gbnVsbCA/IG51bGwgOiBvcHRpb25zLmRlcHRoIC0gMSxcbiAgICB9KTtcbiAgICByZXR1cm4gYCR7b3B0aW9ucy5zdHlsaXplKHRoaXMuY29uc3RydWN0b3IubmFtZSwgXCJzcGVjaWFsXCIpfSAke1xuICAgICAgaW5zcGVjdCh7fSwgbmV3T3B0aW9ucylcbiAgICB9YDtcbiAgfVxufVxuIl0sIm5hbWVzIjpbXSwibWFwcGluZ3MiOiJBQUFBLHlFQUF5RTtBQUV6RSxTQUFTLFNBQVMsUUFBd0IsaUJBQWlCLENBQUM7QUFDNUQsU0FBUyxXQUFXLFFBQVEsMEJBQTBCLENBQUM7QUFDdkQsU0FBUyxNQUFNLEVBQUUsU0FBUyxFQUFFLFFBQVEsUUFBUSxXQUFXLENBQUM7QUFDeEQsU0FBUyxXQUFXLEVBQUUsYUFBYSxFQUFFLE9BQU8sUUFBUSxjQUFjLENBQUM7QUFDbkUsU0FBUyxVQUFVLFFBQVEsZ0JBQWdCLENBQUM7QUFDNUMsU0FBUyxpQkFBaUIsRUFBRSxZQUFZLEVBQUUsUUFBUSxRQUFRLFdBQVcsQ0FBQztBQUV0RSxNQUFNLE9BQU8sR0FBRyxJQUFJLFdBQVcsRUFBRSxBQUFDO0FBQ2xDLE1BQU0sT0FBTyxHQUFHLElBQUksV0FBVyxFQUFFLEFBQUM7QUFFbEMsTUFBTSxvQkFBb0IsR0FBRyxhQUFhLENBQUMsVUFBVSxFQUFFLEdBQUcsQ0FBQyxBQUFDO0FBQzVELE1BQU0sbUJBQW1CLEdBQUcsU0FBUyxBQUFDLEVBQUMsTUFBTTtBQUM3QyxNQUFNLHFCQUFxQixHQUFHLFVBQVUsQUFBQyxFQUFDLE9BQU87QUFDakQsTUFBTSxnQkFBZ0IsR0FBRyxDQUFDLEFBQUMsRUFBQyw0QkFBNEI7QUFDeEQsTUFBTSxnQkFBZ0IsR0FBRyxhQUFhLENBQUMsTUFBTSxFQUFFLEdBQUcsQ0FBQyxBQUFDO0FBNkhwRCxTQUFTLE1BQU0sQ0FBQyxDQUFhLEVBQUUsQ0FBYSxFQUFjO0lBQ3hELE1BQU0sRUFBRSxHQUFHLElBQUksVUFBVSxDQUFDLENBQUMsQ0FBQyxNQUFNLEdBQUcsQ0FBQyxDQUFDLE1BQU0sQ0FBQyxBQUFDO0lBQy9DLEVBQUUsQ0FBQyxHQUFHLENBQUMsQ0FBQyxFQUFFLENBQUMsQ0FBQyxDQUFDO0lBQ2IsRUFBRSxDQUFDLEdBQUcsQ0FBQyxDQUFDLEVBQUUsQ0FBQyxDQUFDLE1BQU0sQ0FBQyxDQUFDO0lBQ3BCLE9BQU8sRUFBRSxDQUFDO0NBQ1g7QUFFRCxTQUFTLE9BQU8sQ0FBQyxDQUFhLEVBQUUsQ0FBYSxFQUFXO0lBQ3RELE9BQU8sTUFBTSxDQUFDLFlBQVksQ0FBQyxDQUFDLENBQUMsRUFBRSxDQUFDLENBQUMsQ0FBQztDQUNuQztBQUVELGVBQWUsZ0JBQWdCLENBQzdCLElBQWUsRUFDZixLQUFpQixFQUNqQixHQUFlLEVBQ0c7SUFDbEIsSUFBSSxVQUFVLEFBQXVCLEFBQUM7SUFDdEMsTUFBUSxVQUFVLEdBQUcsTUFBTSxJQUFJLENBQUMsUUFBUSxFQUFFLENBQUc7UUFDM0MsSUFBSSxPQUFPLENBQUMsVUFBVSxDQUFDLEtBQUssRUFBRSxLQUFLLENBQUMsRUFBRTtZQUNwQyxPQUFPLElBQUksQ0FBQztTQUNiO1FBQ0QsSUFBSSxPQUFPLENBQUMsVUFBVSxDQUFDLEtBQUssRUFBRSxHQUFHLENBQUMsRUFBRTtZQUNsQyxPQUFPLEtBQUssQ0FBQztTQUNkO0tBQ0Y7SUFDRCxNQUFNLElBQUksVUFBVSxDQUFDLFVBQVUsQ0FDN0IscUNBQXFDLENBQ3RDLENBQUM7Q0FDSDtBQUVEO2tCQUNrQixDQUNsQixnQkFBZ0IsS0FBSyxDQUNuQixFQUNFLElBQUksQ0FBQSxFQUNKLGtCQUFrQixFQUFHLEVBQUUsQ0FBQSxFQUN2QixLQUFLLENBQUEsRUFDTCxJQUFJLENBQUEsRUFDSixXQUFXLENBQUEsRUFDWCxPQUFPLENBQUEsRUFDUCxPQUFPLENBQUEsRUFDUCxNQUFNLENBQUEsRUFDTyxFQUN5QztJQUN4RCxlQUFlLE9BQU8sQ0FBQyxXQUFtQixFQUFrQztRQUMxRSxNQUFNLEdBQUcsR0FBRyxrQkFBa0IsQ0FBQyxXQUFXLENBQUMsV0FBVyxFQUFFLENBQUMsSUFDdkQsU0FBUyxDQUFDLFdBQVcsQ0FBQyxBQUFDO1FBQ3pCLElBQUksQ0FBQyxHQUFHLEVBQUU7WUFDUixNQUFNLElBQUksVUFBVSxDQUFDLFVBQVUsQ0FDN0IsQ0FBQyxpQ0FBaUMsRUFBRSxXQUFXLENBQUMsdUNBQXVDLENBQUMsQ0FDekYsQ0FBQztTQUNIO1FBQ0QsSUFBSSxDQUFDLE9BQU8sRUFBRTtZQUNaLE9BQU8sR0FBRyxNQUFNLElBQUksQ0FBQyxXQUFXLEVBQUUsQ0FBQztTQUNwQztRQUNELE1BQU0sUUFBUSxHQUFHLENBQUMsRUFBRSxPQUFPLENBQUMsQ0FBQyxFQUFFLE1BQU0saUJBQWlCLENBQUMsTUFBTSxFQUFFLEdBQUcsQ0FBQyxDQUFDLENBQUMsQUFBQztRQUN0RSxNQUFNLElBQUksR0FBRyxNQUFNLElBQUksQ0FBQyxJQUFJLENBQUMsUUFBUSxFQUFFO1lBQUUsS0FBSyxFQUFFLElBQUk7WUFBRSxTQUFTLEVBQUUsSUFBSTtTQUFFLENBQUMsQUFBQztRQUN6RSxPQUFPO1lBQUMsUUFBUTtZQUFFLElBQUk7U0FBQyxDQUFDO0tBQ3pCO0lBRUQsTUFBTyxJQUFJLENBQUU7UUFDWCxNQUFNLE9BQU8sR0FBRyxNQUFNLFdBQVcsQ0FBQyxJQUFJLENBQUMsQUFBQztRQUN4QyxNQUFNLFdBQVcsR0FBRyxPQUFPLENBQUMsY0FBYyxDQUFDLEFBQUM7UUFDNUMsTUFBTSxrQkFBa0IsR0FBRyxPQUFPLENBQUMscUJBQXFCLENBQUMsQUFBQztRQUMxRCxJQUFJLENBQUMsa0JBQWtCLEVBQUU7WUFDdkIsTUFBTSxJQUFJLFVBQVUsQ0FBQyxVQUFVLENBQzdCLG1EQUFtRCxDQUNwRCxDQUFDO1NBQ0g7UUFDRCxJQUFJLENBQUMsa0JBQWtCLENBQUMsS0FBSyxnQkFBZ0IsRUFBRTtZQUM3QyxNQUFNLElBQUksVUFBVSxDQUFDLFVBQVUsQ0FDN0IsQ0FBQyx3Q0FBd0MsRUFBRSxrQkFBa0IsQ0FBQyxDQUFDLENBQUMsQ0FDakUsQ0FBQztTQUNIO1FBQ0QsTUFBTSxPQUFPLEdBQUcsZ0JBQWdCLENBQUMsSUFBSSxDQUFDLGtCQUFrQixDQUFDLEFBQUM7UUFDMUQsSUFBSSxDQUFDLE9BQU8sRUFBRTtZQUNaLE1BQU0sSUFBSSxVQUFVLENBQUMsVUFBVSxDQUM3QixDQUFDLDBDQUEwQyxDQUFDLENBQzdDLENBQUM7U0FDSDtRQUNELElBQUksR0FBRyxJQUFJLENBQUMsR0FBRyxPQUFPLEFBQUM7UUFDdkIsSUFBSSxHQUFHLE9BQU8sQ0FBQyxJQUFJLENBQUMsQ0FBQztRQUNyQixJQUFJLFdBQVcsRUFBRTtZQUNmLE1BQU0sWUFBWSxHQUFHLFdBQVcsQ0FBQyxrQkFBa0IsQ0FBQyxBQUFDO1lBQ3JELElBQUksVUFBVSxHQUFHLENBQUMsQUFBQztZQUNuQixJQUFJLElBQUksQUFBeUIsQUFBQztZQUNsQyxJQUFJLFFBQVEsQUFBb0IsQUFBQztZQUNqQyxJQUFJLEdBQUcsQUFBd0IsQUFBQztZQUNoQyxJQUFJLE9BQU8sRUFBRTtnQkFDWCxHQUFHLEdBQUcsSUFBSSxVQUFVLEVBQUUsQ0FBQzthQUN4QixNQUFNO2dCQUNMLE1BQU0sTUFBTSxHQUFHLE1BQU0sT0FBTyxDQUFDLFdBQVcsQ0FBQyxBQUFDO2dCQUMxQyxRQUFRLEdBQUcsTUFBTSxDQUFDLENBQUMsQ0FBQyxDQUFDO2dCQUNyQixJQUFJLEdBQUcsTUFBTSxDQUFDLENBQUMsQ0FBQyxDQUFDO2FBQ2xCO1lBQ0QsTUFBTyxJQUFJLENBQUU7Z0JBQ1gsTUFBTSxVQUFVLEdBQUcsTUFBTSxJQUFJLENBQUMsUUFBUSxDQUFDLEtBQUssQ0FBQyxBQUFDO2dCQUM5QyxJQUFJLENBQUMsVUFBVSxFQUFFO29CQUNmLE1BQU0sSUFBSSxVQUFVLENBQUMsVUFBVSxDQUFDLHdCQUF3QixDQUFDLENBQUM7aUJBQzNEO2dCQUNELE1BQU0sRUFBRSxLQUFLLENBQUEsRUFBRSxHQUFHLFVBQVUsQUFBQztnQkFDN0IsTUFBTSxhQUFhLEdBQUcsUUFBUSxDQUFDLEtBQUssQ0FBQyxBQUFDO2dCQUN0QyxJQUFJLE9BQU8sQ0FBQyxhQUFhLEVBQUUsSUFBSSxDQUFDLElBQUksT0FBTyxDQUFDLGFBQWEsRUFBRSxLQUFLLENBQUMsRUFBRTtvQkFDakUsSUFBSSxJQUFJLEVBQUU7d0JBQ1IsbURBQW1EO3dCQUNuRCxNQUFNLFNBQVMsR0FBRyxLQUFLLENBQUMsTUFBTSxHQUFHLGFBQWEsQ0FBQyxNQUFNLEFBQUM7d0JBQ3RELElBQUksU0FBUyxFQUFFOzRCQUNiLE1BQU0saUJBQWlCLEdBQUcsTUFBTSxJQUFJLENBQUMsSUFBSSxDQUN2QyxDQUFDLFNBQVMsRUFDVixJQUFJLENBQUMsUUFBUSxDQUFDLE9BQU8sQ0FDdEIsQUFBQzs0QkFDRixNQUFNLElBQUksQ0FBQyxRQUFRLENBQUMsaUJBQWlCLENBQUMsQ0FBQzt5QkFDeEM7d0JBRUQsSUFBSSxDQUFDLEtBQUssRUFBRSxDQUFDO3FCQUNkO29CQUNELE1BQU07d0JBQ0osSUFBSTt3QkFDSjs0QkFDRSxPQUFPLEVBQUUsR0FBRzs0QkFDWixXQUFXOzRCQUNYLElBQUk7NEJBQ0osUUFBUTs0QkFDUixZQUFZO3lCQUNiO3FCQUNGLENBQUM7b0JBQ0YsSUFBSSxPQUFPLENBQUMsYUFBYSxFQUFFLEtBQUssQ0FBQyxFQUFFO3dCQUNqQyxPQUFPO3FCQUNSO29CQUNELE1BQU07aUJBQ1A7Z0JBQ0QsVUFBVSxJQUFJLEtBQUssQ0FBQyxVQUFVLENBQUM7Z0JBQy9CLElBQUksVUFBVSxHQUFHLFdBQVcsRUFBRTtvQkFDNUIsSUFBSSxJQUFJLEVBQUU7d0JBQ1IsSUFBSSxDQUFDLEtBQUssRUFBRSxDQUFDO3FCQUNkO29CQUNELE1BQU0sSUFBSSxVQUFVLENBQUMscUJBQXFCLENBQ3hDLENBQUMsMkJBQTJCLEVBQUUsV0FBVyxDQUFDLE9BQU8sQ0FBQyxDQUNuRCxDQUFDO2lCQUNIO2dCQUNELElBQUksR0FBRyxFQUFFO29CQUNQLElBQUksVUFBVSxHQUFHLE9BQU8sRUFBRTt3QkFDeEIsTUFBTSxPQUFNLEdBQUcsTUFBTSxPQUFPLENBQUMsV0FBVyxDQUFDLEFBQUM7d0JBQzFDLFFBQVEsR0FBRyxPQUFNLENBQUMsQ0FBQyxDQUFDLENBQUM7d0JBQ3JCLElBQUksR0FBRyxPQUFNLENBQUMsQ0FBQyxDQUFDLENBQUM7d0JBQ2pCLE1BQU0sUUFBUSxDQUFDLElBQUksRUFBRSxHQUFHLENBQUMsQ0FBQzt3QkFDMUIsR0FBRyxHQUFHLFNBQVMsQ0FBQztxQkFDakIsTUFBTTt3QkFDTCxHQUFHLEdBQUcsTUFBTSxDQUFDLEdBQUcsRUFBRSxLQUFLLENBQUMsQ0FBQztxQkFDMUI7aUJBQ0Y7Z0JBQ0QsSUFBSSxJQUFJLEVBQUU7b0JBQ1IsTUFBTSxRQUFRLENBQUMsSUFBSSxFQUFFLEtBQUssQ0FBQyxDQUFDO2lCQUM3QjthQUNGO1NBQ0YsTUFBTTtZQUNMLE1BQU0sS0FBSyxHQUFhLEVBQUUsQUFBQztZQUMzQixNQUFPLElBQUksQ0FBRTtnQkFDWCxNQUFNLFdBQVUsR0FBRyxNQUFNLElBQUksQ0FBQyxRQUFRLEVBQUUsQUFBQztnQkFDekMsSUFBSSxDQUFDLFdBQVUsRUFBRTtvQkFDZixNQUFNLElBQUksVUFBVSxDQUFDLFVBQVUsQ0FBQyx3QkFBd0IsQ0FBQyxDQUFDO2lCQUMzRDtnQkFDRCxNQUFNLEVBQUUsS0FBSyxFQUFMLE1BQUssQ0FBQSxFQUFFLEdBQUcsV0FBVSxBQUFDO2dCQUM3QixJQUFJLE9BQU8sQ0FBQyxNQUFLLEVBQUUsSUFBSSxDQUFDLElBQUksT0FBTyxDQUFDLE1BQUssRUFBRSxLQUFLLENBQUMsRUFBRTtvQkFDakQsTUFBTTt3QkFBQyxJQUFJO3dCQUFFLEtBQUssQ0FBQyxJQUFJLENBQUMsSUFBSSxDQUFDO3FCQUFDLENBQUM7b0JBQy9CLElBQUksT0FBTyxDQUFDLE1BQUssRUFBRSxLQUFLLENBQUMsRUFBRTt3QkFDekIsT0FBTztxQkFDUjtvQkFDRCxNQUFNO2lCQUNQO2dCQUNELEtBQUssQ0FBQyxJQUFJLENBQUMsT0FBTyxDQUFDLE1BQU0sQ0FBQyxNQUFLLENBQUMsQ0FBQyxDQUFDO2FBQ25DO1NBQ0Y7S0FDRjtDQUNGO0FBRUQ7Ozs7Ozs7Ozs7Ozs7Ozs7Ozs7Ozs7Ozs7Ozs7Ozs7Ozs7Ozs7Ozs7Ozs7Ozs7O0dBK0NHLENBQ0gsT0FBTyxNQUFNLGNBQWM7SUFDekIsQ0FBQyxJQUFJLENBQWM7SUFDbkIsQ0FBQyxhQUFhLENBQWE7SUFDM0IsQ0FBQyxZQUFZLENBQWE7SUFDMUIsQ0FBQyxPQUFPLEdBQUcsS0FBSyxDQUFDO0lBRWpCLFlBQVksV0FBbUIsRUFBRSxJQUFpQixDQUFFO1FBQ2xELE1BQU0sT0FBTyxHQUFHLFdBQVcsQ0FBQyxLQUFLLENBQUMsb0JBQW9CLENBQUMsQUFBQztRQUN4RCxJQUFJLENBQUMsT0FBTyxFQUFFO1lBQ1osTUFBTSxJQUFJLFVBQVUsQ0FBQyxVQUFVLENBQzdCLENBQUMsY0FBYyxFQUFFLFdBQVcsQ0FBQyxvQ0FBb0MsQ0FBQyxDQUNuRSxDQUFDO1NBQ0g7UUFDRCxJQUFJLEdBQUcsUUFBUSxDQUFDLEdBQUcsT0FBTyxBQUFDO1FBQzNCLFFBQVEsR0FBRyxPQUFPLENBQUMsUUFBUSxDQUFDLENBQUM7UUFDN0IsSUFBSSxDQUFDLENBQUMsWUFBWSxHQUFHLE9BQU8sQ0FBQyxNQUFNLENBQUMsQ0FBQyxFQUFFLEVBQUUsUUFBUSxDQUFDLENBQUMsQ0FBQyxDQUFDO1FBQ3JELElBQUksQ0FBQyxDQUFDLGFBQWEsR0FBRyxPQUFPLENBQUMsTUFBTSxDQUFDLENBQUMsRUFBRSxFQUFFLFFBQVEsQ0FBQyxFQUFFLENBQUMsQ0FBQyxDQUFDO1FBQ3hELElBQUksQ0FBQyxDQUFDLElBQUksR0FBRyxJQUFJLENBQUM7S0FDbkI7SUFFRDs7Ozs7OztrRUFPZ0UsQ0FDaEUsTUFBTSxJQUFJLENBQUMsT0FBNEIsR0FBRyxFQUFFLEVBQXlCO1FBQ25FLElBQUksSUFBSSxDQUFDLENBQUMsT0FBTyxFQUFFO1lBQ2pCLE1BQU0sSUFBSSxLQUFLLENBQUMsNkJBQTZCLENBQUMsQ0FBQztTQUNoRDtRQUNELElBQUksQ0FBQyxDQUFDLE9BQU8sR0FBRyxJQUFJLENBQUM7UUFDckIsTUFBTSxFQUNKLE9BQU8sQ0FBQSxFQUNQLFdBQVcsRUFBRyxxQkFBcUIsQ0FBQSxFQUNuQyxPQUFPLEVBQUcsZ0JBQWdCLENBQUEsRUFDMUIsVUFBVSxFQUFHLG1CQUFtQixDQUFBLEVBQ2hDLGtCQUFrQixDQUFBLElBQ25CLEdBQUcsT0FBTyxBQUFDO1FBQ1osTUFBTSxJQUFJLEdBQUcsSUFBSSxTQUFTLENBQUMsSUFBSSxDQUFDLENBQUMsSUFBSSxFQUFFLFVBQVUsQ0FBQyxBQUFDO1FBQ25ELE1BQU0sTUFBTSxHQUFpQjtZQUFFLE1BQU0sRUFBRSxFQUFFO1NBQUUsQUFBQztRQUM1QyxJQUNFLENBQUUsTUFBTSxnQkFBZ0IsQ0FBQyxJQUFJLEVBQUUsSUFBSSxDQUFDLENBQUMsWUFBWSxFQUFFLElBQUksQ0FBQyxDQUFDLGFBQWEsQ0FBQyxBQUFDLEVBQ3hFO1lBQ0EsT0FBTyxNQUFNLENBQUM7U0FDZjtRQUNELElBQUk7WUFDRixXQUNFLE1BQU0sSUFBSSxJQUFJLEtBQUssQ0FBQztnQkFDbEIsSUFBSTtnQkFDSixrQkFBa0I7Z0JBQ2xCLElBQUksRUFBRSxJQUFJLENBQUMsQ0FBQyxZQUFZO2dCQUN4QixLQUFLLEVBQUUsSUFBSSxDQUFDLENBQUMsYUFBYTtnQkFDMUIsV0FBVztnQkFDWCxPQUFPO2dCQUNQLE9BQU87YUFDUixDQUFDLENBQ0Y7Z0JBQ0EsTUFBTSxDQUFDLEdBQUcsRUFBRSxLQUFLLENBQUMsR0FBRyxJQUFJLEFBQUM7Z0JBQzFCLElBQUksT0FBTyxLQUFLLEtBQUssUUFBUSxFQUFFO29CQUM3QixNQUFNLENBQUMsTUFBTSxDQUFDLEdBQUcsQ0FBQyxHQUFHLEtBQUssQ0FBQztpQkFDNUIsTUFBTTtvQkFDTCxJQUFJLENBQUMsTUFBTSxDQUFDLEtBQUssRUFBRTt3QkFDakIsTUFBTSxDQUFDLEtBQUssR0FBRyxFQUFFLENBQUM7cUJBQ25CO29CQUNELE1BQU0sQ0FBQyxLQUFLLENBQUMsSUFBSSxDQUFDLEtBQUssQ0FBQyxDQUFDO2lCQUMxQjthQUNGO1NBQ0YsQ0FBQyxPQUFPLEdBQUcsRUFBRTtZQUNaLElBQUksR0FBRyxZQUFZLElBQUksQ0FBQyxNQUFNLENBQUMsZ0JBQWdCLEVBQUU7Z0JBQy9DLE9BQU8sQ0FBQyxLQUFLLENBQUMsR0FBRyxDQUFDLEtBQUssR0FBRyxHQUFHLENBQUMsS0FBSyxHQUFHLENBQUMsRUFBRSxHQUFHLENBQUMsSUFBSSxDQUFDLEVBQUUsRUFBRSxHQUFHLENBQUMsT0FBTyxDQUFDLENBQUMsQ0FBQyxDQUFDO2FBQ3RFLE1BQU07Z0JBQ0wsTUFBTSxHQUFHLENBQUM7YUFDWDtTQUNGO1FBQ0QsT0FBTyxNQUFNLENBQUM7S0FDZjtJQUVEOzs7ZUFHYSxDQUNiLE9BQU8sTUFBTSxDQUNYLE9BQTRCLEdBQUcsRUFBRSxFQUNvQztRQUNyRSxJQUFJLElBQUksQ0FBQyxDQUFDLE9BQU8sRUFBRTtZQUNqQixNQUFNLElBQUksS0FBSyxDQUFDLDZCQUE2QixDQUFDLENBQUM7U0FDaEQ7UUFDRCxJQUFJLENBQUMsQ0FBQyxPQUFPLEdBQUcsSUFBSSxDQUFDO1FBQ3JCLE1BQU0sRUFDSixPQUFPLENBQUEsRUFDUCxrQkFBa0IsQ0FBQSxFQUNsQixXQUFXLEVBQUcscUJBQXFCLENBQUEsRUFDbkMsT0FBTyxFQUFHLGdCQUFnQixDQUFBLEVBQzFCLFVBQVUsRUFBRyxLQUFLLENBQUEsSUFDbkIsR0FBRyxPQUFPLEFBQUM7UUFDWixNQUFNLElBQUksR0FBRyxJQUFJLFNBQVMsQ0FBQyxJQUFJLENBQUMsQ0FBQyxJQUFJLEVBQUUsVUFBVSxDQUFDLEFBQUM7UUFDbkQsSUFDRSxDQUFFLE1BQU0sZ0JBQWdCLENBQUMsSUFBSSxFQUFFLElBQUksQ0FBQyxDQUFDLFlBQVksRUFBRSxJQUFJLENBQUMsQ0FBQyxhQUFhLENBQUMsQUFBQyxFQUN4RTtZQUNBLE9BQU87U0FDUjtRQUNELElBQUk7WUFDRixXQUNFLE1BQU0sSUFBSSxJQUFJLEtBQUssQ0FBQztnQkFDbEIsSUFBSTtnQkFDSixrQkFBa0I7Z0JBQ2xCLElBQUksRUFBRSxJQUFJLENBQUMsQ0FBQyxZQUFZO2dCQUN4QixLQUFLLEVBQUUsSUFBSSxDQUFDLENBQUMsYUFBYTtnQkFDMUIsV0FBVztnQkFDWCxPQUFPO2dCQUNQLE9BQU87YUFDUixDQUFDLENBQ0Y7Z0JBQ0EsTUFBTSxJQUFJLENBQUM7YUFDWjtTQUNGLENBQUMsT0FBTyxHQUFHLEVBQUU7WUFDWixJQUFJLEdBQUcsWUFBWSxJQUFJLENBQUMsTUFBTSxDQUFDLGdCQUFnQixFQUFFO2dCQUMvQyxPQUFPLENBQUMsS0FBSyxDQUFDLEdBQUcsQ0FBQyxLQUFLLEdBQUcsR0FBRyxDQUFDLEtBQUssR0FBRyxDQUFDLEVBQUUsR0FBRyxDQUFDLElBQUksQ0FBQyxFQUFFLEVBQUUsR0FBRyxDQUFDLE9BQU8sQ0FBQyxDQUFDLENBQUMsQ0FBQzthQUN0RSxNQUFNO2dCQUNMLE1BQU0sR0FBRyxDQUFDO2FBQ1g7U0FDRjtLQUNGO0lBRUQsQ0FBQyxNQUFNLENBQUMsR0FBRyxDQUFDLG9CQUFvQixDQUFDLENBQUMsQ0FBQyxPQUFtQyxFQUFFO1FBQ3RFLE9BQU8sQ0FBQyxFQUFFLElBQUksQ0FBQyxXQUFXLENBQUMsSUFBSSxDQUFDLENBQUMsRUFBRSxPQUFPLENBQUMsRUFBRSxDQUFDLENBQUMsQ0FBQyxDQUFDO0tBQ2xEO0lBRUQsQ0FBQyxNQUFNLENBQUMsR0FBRyxDQUFDLDRCQUE0QixDQUFDLENBQUMsQ0FDeEMsS0FBYSxFQUNiLG1DQUFtQztJQUNuQyxPQUFZLEVBQ1osT0FBc0QsRUFDdEQ7UUFDQSxJQUFJLEtBQUssR0FBRyxDQUFDLEVBQUU7WUFDYixPQUFPLE9BQU8sQ0FBQyxPQUFPLENBQUMsQ0FBQyxDQUFDLEVBQUUsSUFBSSxDQUFDLFdBQVcsQ0FBQyxJQUFJLENBQUMsQ0FBQyxDQUFDLEVBQUUsU0FBUyxDQUFDLENBQUM7U0FDakU7UUFFRCxNQUFNLFVBQVUsR0FBRyxNQUFNLENBQUMsTUFBTSxDQUFDLEVBQUUsRUFBRSxPQUFPLEVBQUU7WUFDNUMsS0FBSyxFQUFFLE9BQU8sQ0FBQyxLQUFLLEtBQUssSUFBSSxHQUFHLElBQUksR0FBRyxPQUFPLENBQUMsS0FBSyxHQUFHLENBQUM7U0FDekQsQ0FBQyxBQUFDO1FBQ0gsT0FBTyxDQUFDLEVBQUUsT0FBTyxDQUFDLE9BQU8sQ0FBQyxJQUFJLENBQUMsV0FBVyxDQUFDLElBQUksRUFBRSxTQUFTLENBQUMsQ0FBQyxDQUFDLEVBQzNELE9BQU8sQ0FBQyxFQUFFLEVBQUUsVUFBVSxDQUFDLENBQ3hCLENBQUMsQ0FBQztLQUNKO0NBQ0YifQ==
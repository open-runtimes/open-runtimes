import { RequestBody } from "./body.ts";
import { preferredCharsets } from "./negotiation/charset.ts";
import { preferredEncodings } from "./negotiation/encoding.ts";
import { preferredLanguages } from "./negotiation/language.ts";
import { preferredMediaTypes } from "./negotiation/mediaType.ts";
/** An interface which provides information about the current request. The
 * instance related to the current request is available on the
 * {@linkcode Context}'s `.request` property.
 *
 * The interface contains several properties to get information about the
 * request as well as several methods, which include content negotiation and
 * the ability to decode a request body.
 */ export class Request {
    #body;
    #proxy;
    #secure;
    #serverRequest;
    #url;
     #getRemoteAddr() {
        return this.#serverRequest.remoteAddr ?? "";
    }
    /** Is `true` if the request might have a body, otherwise `false`.
   *
   * **WARNING** this is an unreliable API. In HTTP/2 in many situations you
   * cannot determine if a request has a body or not unless you attempt to read
   * the body, due to the streaming nature of HTTP/2. As of Deno 1.16.1, for
   * HTTP/1.1, Deno also reflects that behaviour.  The only reliable way to
   * determine if a request has a body or not is to attempt to read the body.
   */ get hasBody() {
        return this.#body.has();
    }
    /** The `Headers` supplied in the request. */ get headers() {
        return this.#serverRequest.headers;
    }
    /** Request remote address. When the application's `.proxy` is true, the
   * `X-Forwarded-For` will be used to determine the requesting remote address.
   */ get ip() {
        return (this.#proxy ? this.ips[0] : this.#getRemoteAddr()) ?? "";
    }
    /** When the application's `.proxy` is `true`, this will be set to an array of
   * IPs, ordered from upstream to downstream, based on the value of the header
   * `X-Forwarded-For`.  When `false` an empty array is returned. */ get ips() {
        return this.#proxy ? (this.#serverRequest.headers.get("x-forwarded-for") ?? this.#getRemoteAddr()).split(/\s*,\s*/) : [];
    }
    /** The HTTP Method used by the request. */ get method() {
        return this.#serverRequest.method;
    }
    /** Shortcut to `request.url.protocol === "https:"`. */ get secure() {
        return this.#secure;
    }
    /** Set to the value of the _original_ Deno server request. */ get originalRequest() {
        return this.#serverRequest;
    }
    /** A parsed URL for the request which complies with the browser standards.
   * When the application's `.proxy` is `true`, this value will be based off of
   * the `X-Forwarded-Proto` and `X-Forwarded-Host` header values if present in
   * the request. */ get url() {
        if (!this.#url) {
            const serverRequest = this.#serverRequest;
            if (!this.#proxy) {
                // between 1.9.0 and 1.9.1 the request.url of the native HTTP started
                // returning the full URL, where previously it only returned the path
                // so we will try to use that URL here, but default back to old logic
                // if the URL isn't valid.
                try {
                    if (serverRequest.rawUrl) {
                        this.#url = new URL(serverRequest.rawUrl);
                        return this.#url;
                    }
                } catch  {
                // we don't care about errors here
                }
            }
            let proto;
            let host;
            if (this.#proxy) {
                proto = serverRequest.headers.get("x-forwarded-proto")?.split(/\s*,\s*/, 1)[0] ?? "http";
                host = (serverRequest.headers.get("x-forwarded-host") ?? serverRequest.headers.get("host")) ?? "";
            } else {
                proto = this.#secure ? "https" : "http";
                host = serverRequest.headers.get("host") ?? "";
            }
            try {
                this.#url = new URL(`${proto}://${host}${serverRequest.url}`);
            } catch  {
                throw new TypeError(`The server request URL of "${proto}://${host}${serverRequest.url}" is invalid.`);
            }
        }
        return this.#url;
    }
    constructor(serverRequest, proxy = false, secure = false){
        this.#proxy = proxy;
        this.#secure = secure;
        this.#serverRequest = serverRequest;
        this.#body = new RequestBody(serverRequest.getBody(), serverRequest.headers);
    }
    accepts(...types) {
        const acceptValue = this.#serverRequest.headers.get("Accept");
        if (!acceptValue) {
            return types.length ? types[0] : [
                "*/*"
            ];
        }
        if (types.length) {
            return preferredMediaTypes(acceptValue, types)[0];
        }
        return preferredMediaTypes(acceptValue);
    }
    /** @deprecated the header behind this is no longer used in browsers */ acceptsCharsets(...charsets) {
        const acceptCharsetValue = this.#serverRequest.headers.get("Accept-Charset");
        if (!acceptCharsetValue) {
            return charsets.length ? charsets[0] : [
                "*"
            ];
        }
        if (charsets.length) {
            return preferredCharsets(acceptCharsetValue, charsets)[0];
        }
        return preferredCharsets(acceptCharsetValue);
    }
    acceptsEncodings(...encodings) {
        const acceptEncodingValue = this.#serverRequest.headers.get("Accept-Encoding");
        if (!acceptEncodingValue) {
            return encodings.length ? encodings[0] : [
                "*"
            ];
        }
        if (encodings.length) {
            return preferredEncodings(acceptEncodingValue, encodings)[0];
        }
        return preferredEncodings(acceptEncodingValue);
    }
    acceptsLanguages(...langs) {
        const acceptLanguageValue = this.#serverRequest.headers.get("Accept-Language");
        if (!acceptLanguageValue) {
            return langs.length ? langs[0] : [
                "*"
            ];
        }
        if (langs.length) {
            return preferredLanguages(acceptLanguageValue, langs)[0];
        }
        return preferredLanguages(acceptLanguageValue);
    }
    /** Access the body of the request. This is a method, because there are
   * several options which can be provided which can influence how the body is
   * handled. */ body(options = {}) {
        return this.#body.get(options);
    }
    [Symbol.for("Deno.customInspect")](inspect) {
        const { hasBody , headers , ip , ips , method , secure , url  } = this;
        return `${this.constructor.name} ${inspect({
            hasBody,
            headers,
            ip,
            ips,
            method,
            secure,
            url: url.toString()
        })}`;
    }
    [Symbol.for("nodejs.util.inspect.custom")](depth, // deno-lint-ignore no-explicit-any
    options, inspect) {
        if (depth < 0) {
            return options.stylize(`[${this.constructor.name}]`, "special");
        }
        const newOptions = Object.assign({}, options, {
            depth: options.depth === null ? null : options.depth - 1
        });
        const { hasBody , headers , ip , ips , method , secure , url  } = this;
        return `${options.stylize(this.constructor.name, "special")} ${inspect({
            hasBody,
            headers,
            ip,
            ips,
            method,
            secure,
            url
        }, newOptions)}`;
    }
}
//# sourceMappingURL=data:application/json;base64,eyJ2ZXJzaW9uIjozLCJzb3VyY2VzIjpbImh0dHBzOi8vZGVuby5sYW5kL3gvb2FrQHYxMC42LjAvcmVxdWVzdC50cyJdLCJzb3VyY2VzQ29udGVudCI6WyIvLyBDb3B5cmlnaHQgMjAxOC0yMDIyIHRoZSBvYWsgYXV0aG9ycy4gQWxsIHJpZ2h0cyByZXNlcnZlZC4gTUlUIGxpY2Vuc2UuXG5cbmltcG9ydCB0eXBlIHtcbiAgQm9keSxcbiAgQm9keUJ5dGVzLFxuICBCb2R5Rm9ybSxcbiAgQm9keUZvcm1EYXRhLFxuICBCb2R5SnNvbixcbiAgQm9keU9wdGlvbnMsXG4gIEJvZHlSZWFkZXIsXG4gIEJvZHlTdHJlYW0sXG4gIEJvZHlUZXh0LFxufSBmcm9tIFwiLi9ib2R5LnRzXCI7XG5pbXBvcnQgeyBSZXF1ZXN0Qm9keSB9IGZyb20gXCIuL2JvZHkudHNcIjtcbmltcG9ydCB0eXBlIHsgSFRUUE1ldGhvZHMsIFNlcnZlclJlcXVlc3QgfSBmcm9tIFwiLi90eXBlcy5kLnRzXCI7XG5pbXBvcnQgeyBwcmVmZXJyZWRDaGFyc2V0cyB9IGZyb20gXCIuL25lZ290aWF0aW9uL2NoYXJzZXQudHNcIjtcbmltcG9ydCB7IHByZWZlcnJlZEVuY29kaW5ncyB9IGZyb20gXCIuL25lZ290aWF0aW9uL2VuY29kaW5nLnRzXCI7XG5pbXBvcnQgeyBwcmVmZXJyZWRMYW5ndWFnZXMgfSBmcm9tIFwiLi9uZWdvdGlhdGlvbi9sYW5ndWFnZS50c1wiO1xuaW1wb3J0IHsgcHJlZmVycmVkTWVkaWFUeXBlcyB9IGZyb20gXCIuL25lZ290aWF0aW9uL21lZGlhVHlwZS50c1wiO1xuXG4vKiogQW4gaW50ZXJmYWNlIHdoaWNoIHByb3ZpZGVzIGluZm9ybWF0aW9uIGFib3V0IHRoZSBjdXJyZW50IHJlcXVlc3QuIFRoZVxuICogaW5zdGFuY2UgcmVsYXRlZCB0byB0aGUgY3VycmVudCByZXF1ZXN0IGlzIGF2YWlsYWJsZSBvbiB0aGVcbiAqIHtAbGlua2NvZGUgQ29udGV4dH0ncyBgLnJlcXVlc3RgIHByb3BlcnR5LlxuICpcbiAqIFRoZSBpbnRlcmZhY2UgY29udGFpbnMgc2V2ZXJhbCBwcm9wZXJ0aWVzIHRvIGdldCBpbmZvcm1hdGlvbiBhYm91dCB0aGVcbiAqIHJlcXVlc3QgYXMgd2VsbCBhcyBzZXZlcmFsIG1ldGhvZHMsIHdoaWNoIGluY2x1ZGUgY29udGVudCBuZWdvdGlhdGlvbiBhbmRcbiAqIHRoZSBhYmlsaXR5IHRvIGRlY29kZSBhIHJlcXVlc3QgYm9keS5cbiAqL1xuZXhwb3J0IGNsYXNzIFJlcXVlc3Qge1xuICAjYm9keTogUmVxdWVzdEJvZHk7XG4gICNwcm94eTogYm9vbGVhbjtcbiAgI3NlY3VyZTogYm9vbGVhbjtcbiAgI3NlcnZlclJlcXVlc3Q6IFNlcnZlclJlcXVlc3Q7XG4gICN1cmw/OiBVUkw7XG5cbiAgI2dldFJlbW90ZUFkZHIoKTogc3RyaW5nIHtcbiAgICByZXR1cm4gdGhpcy4jc2VydmVyUmVxdWVzdC5yZW1vdGVBZGRyID8/IFwiXCI7XG4gIH1cblxuICAvKiogSXMgYHRydWVgIGlmIHRoZSByZXF1ZXN0IG1pZ2h0IGhhdmUgYSBib2R5LCBvdGhlcndpc2UgYGZhbHNlYC5cbiAgICpcbiAgICogKipXQVJOSU5HKiogdGhpcyBpcyBhbiB1bnJlbGlhYmxlIEFQSS4gSW4gSFRUUC8yIGluIG1hbnkgc2l0dWF0aW9ucyB5b3VcbiAgICogY2Fubm90IGRldGVybWluZSBpZiBhIHJlcXVlc3QgaGFzIGEgYm9keSBvciBub3QgdW5sZXNzIHlvdSBhdHRlbXB0IHRvIHJlYWRcbiAgICogdGhlIGJvZHksIGR1ZSB0byB0aGUgc3RyZWFtaW5nIG5hdHVyZSBvZiBIVFRQLzIuIEFzIG9mIERlbm8gMS4xNi4xLCBmb3JcbiAgICogSFRUUC8xLjEsIERlbm8gYWxzbyByZWZsZWN0cyB0aGF0IGJlaGF2aW91ci4gIFRoZSBvbmx5IHJlbGlhYmxlIHdheSB0b1xuICAgKiBkZXRlcm1pbmUgaWYgYSByZXF1ZXN0IGhhcyBhIGJvZHkgb3Igbm90IGlzIHRvIGF0dGVtcHQgdG8gcmVhZCB0aGUgYm9keS5cbiAgICovXG4gIGdldCBoYXNCb2R5KCk6IGJvb2xlYW4ge1xuICAgIHJldHVybiB0aGlzLiNib2R5LmhhcygpO1xuICB9XG5cbiAgLyoqIFRoZSBgSGVhZGVyc2Agc3VwcGxpZWQgaW4gdGhlIHJlcXVlc3QuICovXG4gIGdldCBoZWFkZXJzKCk6IEhlYWRlcnMge1xuICAgIHJldHVybiB0aGlzLiNzZXJ2ZXJSZXF1ZXN0LmhlYWRlcnM7XG4gIH1cblxuICAvKiogUmVxdWVzdCByZW1vdGUgYWRkcmVzcy4gV2hlbiB0aGUgYXBwbGljYXRpb24ncyBgLnByb3h5YCBpcyB0cnVlLCB0aGVcbiAgICogYFgtRm9yd2FyZGVkLUZvcmAgd2lsbCBiZSB1c2VkIHRvIGRldGVybWluZSB0aGUgcmVxdWVzdGluZyByZW1vdGUgYWRkcmVzcy5cbiAgICovXG4gIGdldCBpcCgpOiBzdHJpbmcge1xuICAgIHJldHVybiAodGhpcy4jcHJveHkgPyB0aGlzLmlwc1swXSA6IHRoaXMuI2dldFJlbW90ZUFkZHIoKSkgPz8gXCJcIjtcbiAgfVxuXG4gIC8qKiBXaGVuIHRoZSBhcHBsaWNhdGlvbidzIGAucHJveHlgIGlzIGB0cnVlYCwgdGhpcyB3aWxsIGJlIHNldCB0byBhbiBhcnJheSBvZlxuICAgKiBJUHMsIG9yZGVyZWQgZnJvbSB1cHN0cmVhbSB0byBkb3duc3RyZWFtLCBiYXNlZCBvbiB0aGUgdmFsdWUgb2YgdGhlIGhlYWRlclxuICAgKiBgWC1Gb3J3YXJkZWQtRm9yYC4gIFdoZW4gYGZhbHNlYCBhbiBlbXB0eSBhcnJheSBpcyByZXR1cm5lZC4gKi9cbiAgZ2V0IGlwcygpOiBzdHJpbmdbXSB7XG4gICAgcmV0dXJuIHRoaXMuI3Byb3h5XG4gICAgICA/ICh0aGlzLiNzZXJ2ZXJSZXF1ZXN0LmhlYWRlcnMuZ2V0KFwieC1mb3J3YXJkZWQtZm9yXCIpID8/XG4gICAgICAgIHRoaXMuI2dldFJlbW90ZUFkZHIoKSkuc3BsaXQoL1xccyosXFxzKi8pXG4gICAgICA6IFtdO1xuICB9XG5cbiAgLyoqIFRoZSBIVFRQIE1ldGhvZCB1c2VkIGJ5IHRoZSByZXF1ZXN0LiAqL1xuICBnZXQgbWV0aG9kKCk6IEhUVFBNZXRob2RzIHtcbiAgICByZXR1cm4gdGhpcy4jc2VydmVyUmVxdWVzdC5tZXRob2QgYXMgSFRUUE1ldGhvZHM7XG4gIH1cblxuICAvKiogU2hvcnRjdXQgdG8gYHJlcXVlc3QudXJsLnByb3RvY29sID09PSBcImh0dHBzOlwiYC4gKi9cbiAgZ2V0IHNlY3VyZSgpOiBib29sZWFuIHtcbiAgICByZXR1cm4gdGhpcy4jc2VjdXJlO1xuICB9XG5cbiAgLyoqIFNldCB0byB0aGUgdmFsdWUgb2YgdGhlIF9vcmlnaW5hbF8gRGVubyBzZXJ2ZXIgcmVxdWVzdC4gKi9cbiAgZ2V0IG9yaWdpbmFsUmVxdWVzdCgpOiBTZXJ2ZXJSZXF1ZXN0IHtcbiAgICByZXR1cm4gdGhpcy4jc2VydmVyUmVxdWVzdDtcbiAgfVxuXG4gIC8qKiBBIHBhcnNlZCBVUkwgZm9yIHRoZSByZXF1ZXN0IHdoaWNoIGNvbXBsaWVzIHdpdGggdGhlIGJyb3dzZXIgc3RhbmRhcmRzLlxuICAgKiBXaGVuIHRoZSBhcHBsaWNhdGlvbidzIGAucHJveHlgIGlzIGB0cnVlYCwgdGhpcyB2YWx1ZSB3aWxsIGJlIGJhc2VkIG9mZiBvZlxuICAgKiB0aGUgYFgtRm9yd2FyZGVkLVByb3RvYCBhbmQgYFgtRm9yd2FyZGVkLUhvc3RgIGhlYWRlciB2YWx1ZXMgaWYgcHJlc2VudCBpblxuICAgKiB0aGUgcmVxdWVzdC4gKi9cbiAgZ2V0IHVybCgpOiBVUkwge1xuICAgIGlmICghdGhpcy4jdXJsKSB7XG4gICAgICBjb25zdCBzZXJ2ZXJSZXF1ZXN0ID0gdGhpcy4jc2VydmVyUmVxdWVzdDtcbiAgICAgIGlmICghdGhpcy4jcHJveHkpIHtcbiAgICAgICAgLy8gYmV0d2VlbiAxLjkuMCBhbmQgMS45LjEgdGhlIHJlcXVlc3QudXJsIG9mIHRoZSBuYXRpdmUgSFRUUCBzdGFydGVkXG4gICAgICAgIC8vIHJldHVybmluZyB0aGUgZnVsbCBVUkwsIHdoZXJlIHByZXZpb3VzbHkgaXQgb25seSByZXR1cm5lZCB0aGUgcGF0aFxuICAgICAgICAvLyBzbyB3ZSB3aWxsIHRyeSB0byB1c2UgdGhhdCBVUkwgaGVyZSwgYnV0IGRlZmF1bHQgYmFjayB0byBvbGQgbG9naWNcbiAgICAgICAgLy8gaWYgdGhlIFVSTCBpc24ndCB2YWxpZC5cbiAgICAgICAgdHJ5IHtcbiAgICAgICAgICBpZiAoc2VydmVyUmVxdWVzdC5yYXdVcmwpIHtcbiAgICAgICAgICAgIHRoaXMuI3VybCA9IG5ldyBVUkwoc2VydmVyUmVxdWVzdC5yYXdVcmwpO1xuICAgICAgICAgICAgcmV0dXJuIHRoaXMuI3VybDtcbiAgICAgICAgICB9XG4gICAgICAgIH0gY2F0Y2gge1xuICAgICAgICAgIC8vIHdlIGRvbid0IGNhcmUgYWJvdXQgZXJyb3JzIGhlcmVcbiAgICAgICAgfVxuICAgICAgfVxuICAgICAgbGV0IHByb3RvOiBzdHJpbmc7XG4gICAgICBsZXQgaG9zdDogc3RyaW5nO1xuICAgICAgaWYgKHRoaXMuI3Byb3h5KSB7XG4gICAgICAgIHByb3RvID0gc2VydmVyUmVxdWVzdFxuICAgICAgICAgIC5oZWFkZXJzLmdldChcIngtZm9yd2FyZGVkLXByb3RvXCIpPy5zcGxpdCgvXFxzKixcXHMqLywgMSlbMF0gPz9cbiAgICAgICAgICBcImh0dHBcIjtcbiAgICAgICAgaG9zdCA9IHNlcnZlclJlcXVlc3QuaGVhZGVycy5nZXQoXCJ4LWZvcndhcmRlZC1ob3N0XCIpID8/XG4gICAgICAgICAgc2VydmVyUmVxdWVzdC5oZWFkZXJzLmdldChcImhvc3RcIikgPz8gXCJcIjtcbiAgICAgIH0gZWxzZSB7XG4gICAgICAgIHByb3RvID0gdGhpcy4jc2VjdXJlID8gXCJodHRwc1wiIDogXCJodHRwXCI7XG4gICAgICAgIGhvc3QgPSBzZXJ2ZXJSZXF1ZXN0LmhlYWRlcnMuZ2V0KFwiaG9zdFwiKSA/PyBcIlwiO1xuICAgICAgfVxuICAgICAgdHJ5IHtcbiAgICAgICAgdGhpcy4jdXJsID0gbmV3IFVSTChgJHtwcm90b306Ly8ke2hvc3R9JHtzZXJ2ZXJSZXF1ZXN0LnVybH1gKTtcbiAgICAgIH0gY2F0Y2gge1xuICAgICAgICB0aHJvdyBuZXcgVHlwZUVycm9yKFxuICAgICAgICAgIGBUaGUgc2VydmVyIHJlcXVlc3QgVVJMIG9mIFwiJHtwcm90b306Ly8ke2hvc3R9JHtzZXJ2ZXJSZXF1ZXN0LnVybH1cIiBpcyBpbnZhbGlkLmAsXG4gICAgICAgICk7XG4gICAgICB9XG4gICAgfVxuICAgIHJldHVybiB0aGlzLiN1cmw7XG4gIH1cblxuICBjb25zdHJ1Y3RvcihcbiAgICBzZXJ2ZXJSZXF1ZXN0OiBTZXJ2ZXJSZXF1ZXN0LFxuICAgIHByb3h5ID0gZmFsc2UsXG4gICAgc2VjdXJlID0gZmFsc2UsXG4gICkge1xuICAgIHRoaXMuI3Byb3h5ID0gcHJveHk7XG4gICAgdGhpcy4jc2VjdXJlID0gc2VjdXJlO1xuICAgIHRoaXMuI3NlcnZlclJlcXVlc3QgPSBzZXJ2ZXJSZXF1ZXN0O1xuICAgIHRoaXMuI2JvZHkgPSBuZXcgUmVxdWVzdEJvZHkoXG4gICAgICBzZXJ2ZXJSZXF1ZXN0LmdldEJvZHkoKSxcbiAgICAgIHNlcnZlclJlcXVlc3QuaGVhZGVycyxcbiAgICApO1xuICB9XG5cbiAgLyoqIFJldHVybnMgYW4gYXJyYXkgb2YgbWVkaWEgdHlwZXMsIGFjY2VwdGVkIGJ5IHRoZSByZXF1ZXN0b3IsIGluIG9yZGVyIG9mXG4gICAqIHByZWZlcmVuY2UuICBJZiB0aGVyZSBhcmUgbm8gZW5jb2RpbmdzIHN1cHBsaWVkIGJ5IHRoZSByZXF1ZXN0b3IsXG4gICAqIHRoZW4gYWNjZXB0aW5nIGFueSBpcyBpbXBsaWVkIGlzIHJldHVybmVkLlxuICAgKi9cbiAgYWNjZXB0cygpOiBzdHJpbmdbXSB8IHVuZGVmaW5lZDtcbiAgLyoqIEZvciBhIGdpdmVuIHNldCBvZiBtZWRpYSB0eXBlcywgcmV0dXJuIHRoZSBiZXN0IG1hdGNoIGFjY2VwdGVkIGJ5IHRoZVxuICAgKiByZXF1ZXN0b3IuICBJZiB0aGVyZSBhcmUgbm8gZW5jb2RpbmcgdGhhdCBtYXRjaCwgdGhlbiB0aGUgbWV0aG9kIHJldHVybnNcbiAgICogYHVuZGVmaW5lZGAuXG4gICAqL1xuICBhY2NlcHRzKC4uLnR5cGVzOiBzdHJpbmdbXSk6IHN0cmluZyB8IHVuZGVmaW5lZDtcbiAgYWNjZXB0cyguLi50eXBlczogc3RyaW5nW10pOiBzdHJpbmcgfCBzdHJpbmdbXSB8IHVuZGVmaW5lZCB7XG4gICAgY29uc3QgYWNjZXB0VmFsdWUgPSB0aGlzLiNzZXJ2ZXJSZXF1ZXN0LmhlYWRlcnMuZ2V0KFwiQWNjZXB0XCIpO1xuICAgIGlmICghYWNjZXB0VmFsdWUpIHtcbiAgICAgIHJldHVybiB0eXBlcy5sZW5ndGggPyB0eXBlc1swXSA6IFtcIiovKlwiXTtcbiAgICB9XG4gICAgaWYgKHR5cGVzLmxlbmd0aCkge1xuICAgICAgcmV0dXJuIHByZWZlcnJlZE1lZGlhVHlwZXMoYWNjZXB0VmFsdWUsIHR5cGVzKVswXTtcbiAgICB9XG4gICAgcmV0dXJuIHByZWZlcnJlZE1lZGlhVHlwZXMoYWNjZXB0VmFsdWUpO1xuICB9XG5cbiAgLyoqXG4gICAqIEBkZXByZWNhdGVkIHRoZSBoZWFkZXIgYmVoaW5kIHRoaXMgaXMgbm8gbG9uZ2VyIHVzZWQgaW4gYnJvd3NlcnNcbiAgICovXG4gIGFjY2VwdHNDaGFyc2V0cygpOiBzdHJpbmdbXSB8IHVuZGVmaW5lZDtcbiAgLyoqXG4gICAqIEBkZXByZWNhdGVkIHRoZSBoZWFkZXIgYmVoaW5kIHRoaXMgaXMgbm8gbG9uZ2VyIHVzZWQgaW4gYnJvd3NlcnNcbiAgICovXG4gIGFjY2VwdHNDaGFyc2V0cyguLi5jaGFyc2V0czogc3RyaW5nW10pOiBzdHJpbmcgfCB1bmRlZmluZWQ7XG4gIC8qKiBAZGVwcmVjYXRlZCB0aGUgaGVhZGVyIGJlaGluZCB0aGlzIGlzIG5vIGxvbmdlciB1c2VkIGluIGJyb3dzZXJzICovXG4gIGFjY2VwdHNDaGFyc2V0cyguLi5jaGFyc2V0czogc3RyaW5nW10pOiBzdHJpbmdbXSB8IHN0cmluZyB8IHVuZGVmaW5lZCB7XG4gICAgY29uc3QgYWNjZXB0Q2hhcnNldFZhbHVlID0gdGhpcy4jc2VydmVyUmVxdWVzdC5oZWFkZXJzLmdldChcbiAgICAgIFwiQWNjZXB0LUNoYXJzZXRcIixcbiAgICApO1xuICAgIGlmICghYWNjZXB0Q2hhcnNldFZhbHVlKSB7XG4gICAgICByZXR1cm4gY2hhcnNldHMubGVuZ3RoID8gY2hhcnNldHNbMF0gOiBbXCIqXCJdO1xuICAgIH1cbiAgICBpZiAoY2hhcnNldHMubGVuZ3RoKSB7XG4gICAgICByZXR1cm4gcHJlZmVycmVkQ2hhcnNldHMoYWNjZXB0Q2hhcnNldFZhbHVlLCBjaGFyc2V0cylbMF07XG4gICAgfVxuICAgIHJldHVybiBwcmVmZXJyZWRDaGFyc2V0cyhhY2NlcHRDaGFyc2V0VmFsdWUpO1xuICB9XG5cbiAgLyoqIFJldHVybnMgYW4gYXJyYXkgb2YgZW5jb2RpbmdzLCBhY2NlcHRlZCBieSB0aGUgcmVxdWVzdG9yLCBpbiBvcmRlciBvZlxuICAgKiBwcmVmZXJlbmNlLiAgSWYgdGhlcmUgYXJlIG5vIGVuY29kaW5ncyBzdXBwbGllZCBieSB0aGUgcmVxdWVzdG9yLFxuICAgKiB0aGVuIGBbXCIqXCJdYCBpcyByZXR1cm5lZCwgbWF0Y2hpbmcgYW55LlxuICAgKi9cbiAgYWNjZXB0c0VuY29kaW5ncygpOiBzdHJpbmdbXSB8IHVuZGVmaW5lZDtcbiAgLyoqIEZvciBhIGdpdmVuIHNldCBvZiBlbmNvZGluZ3MsIHJldHVybiB0aGUgYmVzdCBtYXRjaCBhY2NlcHRlZCBieSB0aGVcbiAgICogcmVxdWVzdG9yLiAgSWYgdGhlcmUgYXJlIG5vIGVuY29kaW5ncyB0aGF0IG1hdGNoLCB0aGVuIHRoZSBtZXRob2QgcmV0dXJuc1xuICAgKiBgdW5kZWZpbmVkYC5cbiAgICpcbiAgICogKipOT1RFOioqIFlvdSBzaG91bGQgYWx3YXlzIHN1cHBseSBgaWRlbnRpdHlgIGFzIG9uZSBvZiB0aGUgZW5jb2RpbmdzXG4gICAqIHRvIGVuc3VyZSB0aGF0IHRoZXJlIGlzIGEgbWF0Y2ggd2hlbiB0aGUgYEFjY2VwdC1FbmNvZGluZ2AgaGVhZGVyIGlzIHBhcnRcbiAgICogb2YgdGhlIHJlcXVlc3QuXG4gICAqL1xuICBhY2NlcHRzRW5jb2RpbmdzKC4uLmVuY29kaW5nczogc3RyaW5nW10pOiBzdHJpbmcgfCB1bmRlZmluZWQ7XG4gIGFjY2VwdHNFbmNvZGluZ3MoLi4uZW5jb2RpbmdzOiBzdHJpbmdbXSk6IHN0cmluZ1tdIHwgc3RyaW5nIHwgdW5kZWZpbmVkIHtcbiAgICBjb25zdCBhY2NlcHRFbmNvZGluZ1ZhbHVlID0gdGhpcy4jc2VydmVyUmVxdWVzdC5oZWFkZXJzLmdldChcbiAgICAgIFwiQWNjZXB0LUVuY29kaW5nXCIsXG4gICAgKTtcbiAgICBpZiAoIWFjY2VwdEVuY29kaW5nVmFsdWUpIHtcbiAgICAgIHJldHVybiBlbmNvZGluZ3MubGVuZ3RoID8gZW5jb2RpbmdzWzBdIDogW1wiKlwiXTtcbiAgICB9XG4gICAgaWYgKGVuY29kaW5ncy5sZW5ndGgpIHtcbiAgICAgIHJldHVybiBwcmVmZXJyZWRFbmNvZGluZ3MoYWNjZXB0RW5jb2RpbmdWYWx1ZSwgZW5jb2RpbmdzKVswXTtcbiAgICB9XG4gICAgcmV0dXJuIHByZWZlcnJlZEVuY29kaW5ncyhhY2NlcHRFbmNvZGluZ1ZhbHVlKTtcbiAgfVxuXG4gIC8qKiBSZXR1cm5zIGFuIGFycmF5IG9mIGxhbmd1YWdlcywgYWNjZXB0ZWQgYnkgdGhlIHJlcXVlc3RvciwgaW4gb3JkZXIgb2ZcbiAgICogcHJlZmVyZW5jZS4gIElmIHRoZXJlIGFyZSBubyBsYW5ndWFnZXMgc3VwcGxpZWQgYnkgdGhlIHJlcXVlc3RvcixcbiAgICogYFtcIipcIl1gIGlzIHJldHVybmVkLCBpbmRpY2F0aW5nIGFueSBsYW5ndWFnZSBpcyBhY2NlcHRlZC5cbiAgICovXG4gIGFjY2VwdHNMYW5ndWFnZXMoKTogc3RyaW5nW10gfCB1bmRlZmluZWQ7XG4gIC8qKiBGb3IgYSBnaXZlbiBzZXQgb2YgbGFuZ3VhZ2VzLCByZXR1cm4gdGhlIGJlc3QgbWF0Y2ggYWNjZXB0ZWQgYnkgdGhlXG4gICAqIHJlcXVlc3Rvci4gIElmIHRoZXJlIGFyZSBubyBsYW5ndWFnZXMgdGhhdCBtYXRjaCwgdGhlbiB0aGUgbWV0aG9kIHJldHVybnNcbiAgICogYHVuZGVmaW5lZGAuICovXG4gIGFjY2VwdHNMYW5ndWFnZXMoLi4ubGFuZ3M6IHN0cmluZ1tdKTogc3RyaW5nIHwgdW5kZWZpbmVkO1xuICBhY2NlcHRzTGFuZ3VhZ2VzKC4uLmxhbmdzOiBzdHJpbmdbXSk6IHN0cmluZ1tdIHwgc3RyaW5nIHwgdW5kZWZpbmVkIHtcbiAgICBjb25zdCBhY2NlcHRMYW5ndWFnZVZhbHVlID0gdGhpcy4jc2VydmVyUmVxdWVzdC5oZWFkZXJzLmdldChcbiAgICAgIFwiQWNjZXB0LUxhbmd1YWdlXCIsXG4gICAgKTtcbiAgICBpZiAoIWFjY2VwdExhbmd1YWdlVmFsdWUpIHtcbiAgICAgIHJldHVybiBsYW5ncy5sZW5ndGggPyBsYW5nc1swXSA6IFtcIipcIl07XG4gICAgfVxuICAgIGlmIChsYW5ncy5sZW5ndGgpIHtcbiAgICAgIHJldHVybiBwcmVmZXJyZWRMYW5ndWFnZXMoYWNjZXB0TGFuZ3VhZ2VWYWx1ZSwgbGFuZ3MpWzBdO1xuICAgIH1cbiAgICByZXR1cm4gcHJlZmVycmVkTGFuZ3VhZ2VzKGFjY2VwdExhbmd1YWdlVmFsdWUpO1xuICB9XG5cbiAgYm9keShvcHRpb25zOiBCb2R5T3B0aW9uczxcImJ5dGVzXCI+KTogQm9keUJ5dGVzO1xuICBib2R5KG9wdGlvbnM6IEJvZHlPcHRpb25zPFwiZm9ybVwiPik6IEJvZHlGb3JtO1xuICBib2R5KG9wdGlvbnM6IEJvZHlPcHRpb25zPFwiZm9ybS1kYXRhXCI+KTogQm9keUZvcm1EYXRhO1xuICBib2R5KG9wdGlvbnM6IEJvZHlPcHRpb25zPFwianNvblwiPik6IEJvZHlKc29uO1xuICBib2R5KG9wdGlvbnM6IEJvZHlPcHRpb25zPFwicmVhZGVyXCI+KTogQm9keVJlYWRlcjtcbiAgYm9keShvcHRpb25zOiBCb2R5T3B0aW9uczxcInN0cmVhbVwiPik6IEJvZHlTdHJlYW07XG4gIGJvZHkob3B0aW9uczogQm9keU9wdGlvbnM8XCJ0ZXh0XCI+KTogQm9keVRleHQ7XG4gIGJvZHkob3B0aW9ucz86IEJvZHlPcHRpb25zKTogQm9keTtcbiAgLyoqIEFjY2VzcyB0aGUgYm9keSBvZiB0aGUgcmVxdWVzdC4gVGhpcyBpcyBhIG1ldGhvZCwgYmVjYXVzZSB0aGVyZSBhcmVcbiAgICogc2V2ZXJhbCBvcHRpb25zIHdoaWNoIGNhbiBiZSBwcm92aWRlZCB3aGljaCBjYW4gaW5mbHVlbmNlIGhvdyB0aGUgYm9keSBpc1xuICAgKiBoYW5kbGVkLiAqL1xuICBib2R5KG9wdGlvbnM6IEJvZHlPcHRpb25zID0ge30pOiBCb2R5IHwgQm9keVJlYWRlciB8IEJvZHlTdHJlYW0ge1xuICAgIHJldHVybiB0aGlzLiNib2R5LmdldChvcHRpb25zKTtcbiAgfVxuXG4gIFtTeW1ib2wuZm9yKFwiRGVuby5jdXN0b21JbnNwZWN0XCIpXShpbnNwZWN0OiAodmFsdWU6IHVua25vd24pID0+IHN0cmluZykge1xuICAgIGNvbnN0IHsgaGFzQm9keSwgaGVhZGVycywgaXAsIGlwcywgbWV0aG9kLCBzZWN1cmUsIHVybCB9ID0gdGhpcztcbiAgICByZXR1cm4gYCR7dGhpcy5jb25zdHJ1Y3Rvci5uYW1lfSAke1xuICAgICAgaW5zcGVjdCh7XG4gICAgICAgIGhhc0JvZHksXG4gICAgICAgIGhlYWRlcnMsXG4gICAgICAgIGlwLFxuICAgICAgICBpcHMsXG4gICAgICAgIG1ldGhvZCxcbiAgICAgICAgc2VjdXJlLFxuICAgICAgICB1cmw6IHVybC50b1N0cmluZygpLFxuICAgICAgfSlcbiAgICB9YDtcbiAgfVxuXG4gIFtTeW1ib2wuZm9yKFwibm9kZWpzLnV0aWwuaW5zcGVjdC5jdXN0b21cIildKFxuICAgIGRlcHRoOiBudW1iZXIsXG4gICAgLy8gZGVuby1saW50LWlnbm9yZSBuby1leHBsaWNpdC1hbnlcbiAgICBvcHRpb25zOiBhbnksXG4gICAgaW5zcGVjdDogKHZhbHVlOiB1bmtub3duLCBvcHRpb25zPzogdW5rbm93bikgPT4gc3RyaW5nLFxuICApIHtcbiAgICBpZiAoZGVwdGggPCAwKSB7XG4gICAgICByZXR1cm4gb3B0aW9ucy5zdHlsaXplKGBbJHt0aGlzLmNvbnN0cnVjdG9yLm5hbWV9XWAsIFwic3BlY2lhbFwiKTtcbiAgICB9XG5cbiAgICBjb25zdCBuZXdPcHRpb25zID0gT2JqZWN0LmFzc2lnbih7fSwgb3B0aW9ucywge1xuICAgICAgZGVwdGg6IG9wdGlvbnMuZGVwdGggPT09IG51bGwgPyBudWxsIDogb3B0aW9ucy5kZXB0aCAtIDEsXG4gICAgfSk7XG4gICAgY29uc3QgeyBoYXNCb2R5LCBoZWFkZXJzLCBpcCwgaXBzLCBtZXRob2QsIHNlY3VyZSwgdXJsIH0gPSB0aGlzO1xuICAgIHJldHVybiBgJHtvcHRpb25zLnN0eWxpemUodGhpcy5jb25zdHJ1Y3Rvci5uYW1lLCBcInNwZWNpYWxcIil9ICR7XG4gICAgICBpbnNwZWN0KFxuICAgICAgICB7IGhhc0JvZHksIGhlYWRlcnMsIGlwLCBpcHMsIG1ldGhvZCwgc2VjdXJlLCB1cmwgfSxcbiAgICAgICAgbmV3T3B0aW9ucyxcbiAgICAgIClcbiAgICB9YDtcbiAgfVxufVxuIl0sIm5hbWVzIjpbXSwibWFwcGluZ3MiOiJBQWFBLFNBQVMsV0FBVyxRQUFRLFdBQVcsQ0FBQztBQUV4QyxTQUFTLGlCQUFpQixRQUFRLDBCQUEwQixDQUFDO0FBQzdELFNBQVMsa0JBQWtCLFFBQVEsMkJBQTJCLENBQUM7QUFDL0QsU0FBUyxrQkFBa0IsUUFBUSwyQkFBMkIsQ0FBQztBQUMvRCxTQUFTLG1CQUFtQixRQUFRLDRCQUE0QixDQUFDO0FBRWpFOzs7Ozs7O0dBT0csQ0FDSCxPQUFPLE1BQU0sT0FBTztJQUNsQixDQUFDLElBQUksQ0FBYztJQUNuQixDQUFDLEtBQUssQ0FBVTtJQUNoQixDQUFDLE1BQU0sQ0FBVTtJQUNqQixDQUFDLGFBQWEsQ0FBZ0I7SUFDOUIsQ0FBQyxHQUFHLENBQU87SUFFWCxDQUFBLENBQUMsYUFBYSxHQUFXO1FBQ3ZCLE9BQU8sSUFBSSxDQUFDLENBQUMsYUFBYSxDQUFDLFVBQVUsSUFBSSxFQUFFLENBQUM7S0FDN0M7SUFFRDs7Ozs7OztLQU9HLENBQ0gsSUFBSSxPQUFPLEdBQVk7UUFDckIsT0FBTyxJQUFJLENBQUMsQ0FBQyxJQUFJLENBQUMsR0FBRyxFQUFFLENBQUM7S0FDekI7SUFFRCw2Q0FBNkMsQ0FDN0MsSUFBSSxPQUFPLEdBQVk7UUFDckIsT0FBTyxJQUFJLENBQUMsQ0FBQyxhQUFhLENBQUMsT0FBTyxDQUFDO0tBQ3BDO0lBRUQ7O0tBRUcsQ0FDSCxJQUFJLEVBQUUsR0FBVztRQUNmLE9BQU8sQ0FBQyxJQUFJLENBQUMsQ0FBQyxLQUFLLEdBQUcsSUFBSSxDQUFDLEdBQUcsQ0FBQyxDQUFDLENBQUMsR0FBRyxJQUFJLENBQUMsQ0FBQyxhQUFhLEVBQUUsQ0FBQyxJQUFJLEVBQUUsQ0FBQztLQUNsRTtJQUVEOztvRUFFa0UsQ0FDbEUsSUFBSSxHQUFHLEdBQWE7UUFDbEIsT0FBTyxJQUFJLENBQUMsQ0FBQyxLQUFLLEdBQ2QsQ0FBQyxJQUFJLENBQUMsQ0FBQyxhQUFhLENBQUMsT0FBTyxDQUFDLEdBQUcsQ0FBQyxpQkFBaUIsQ0FBQyxJQUNuRCxJQUFJLENBQUMsQ0FBQyxhQUFhLEVBQUUsQ0FBQyxDQUFDLEtBQUssV0FBVyxHQUN2QyxFQUFFLENBQUM7S0FDUjtJQUVELDJDQUEyQyxDQUMzQyxJQUFJLE1BQU0sR0FBZ0I7UUFDeEIsT0FBTyxJQUFJLENBQUMsQ0FBQyxhQUFhLENBQUMsTUFBTSxDQUFnQjtLQUNsRDtJQUVELHVEQUF1RCxDQUN2RCxJQUFJLE1BQU0sR0FBWTtRQUNwQixPQUFPLElBQUksQ0FBQyxDQUFDLE1BQU0sQ0FBQztLQUNyQjtJQUVELDhEQUE4RCxDQUM5RCxJQUFJLGVBQWUsR0FBa0I7UUFDbkMsT0FBTyxJQUFJLENBQUMsQ0FBQyxhQUFhLENBQUM7S0FDNUI7SUFFRDs7O29CQUdrQixDQUNsQixJQUFJLEdBQUcsR0FBUTtRQUNiLElBQUksQ0FBQyxJQUFJLENBQUMsQ0FBQyxHQUFHLEVBQUU7WUFDZCxNQUFNLGFBQWEsR0FBRyxJQUFJLENBQUMsQ0FBQyxhQUFhLEFBQUM7WUFDMUMsSUFBSSxDQUFDLElBQUksQ0FBQyxDQUFDLEtBQUssRUFBRTtnQkFDaEIscUVBQXFFO2dCQUNyRSxxRUFBcUU7Z0JBQ3JFLHFFQUFxRTtnQkFDckUsMEJBQTBCO2dCQUMxQixJQUFJO29CQUNGLElBQUksYUFBYSxDQUFDLE1BQU0sRUFBRTt3QkFDeEIsSUFBSSxDQUFDLENBQUMsR0FBRyxHQUFHLElBQUksR0FBRyxDQUFDLGFBQWEsQ0FBQyxNQUFNLENBQUMsQ0FBQzt3QkFDMUMsT0FBTyxJQUFJLENBQUMsQ0FBQyxHQUFHLENBQUM7cUJBQ2xCO2lCQUNGLENBQUMsT0FBTTtnQkFDTixrQ0FBa0M7aUJBQ25DO2FBQ0Y7WUFDRCxJQUFJLEtBQUssQUFBUSxBQUFDO1lBQ2xCLElBQUksSUFBSSxBQUFRLEFBQUM7WUFDakIsSUFBSSxJQUFJLENBQUMsQ0FBQyxLQUFLLEVBQUU7Z0JBQ2YsS0FBSyxHQUFHLGFBQWEsQ0FDbEIsT0FBTyxDQUFDLEdBQUcsQ0FBQyxtQkFBbUIsQ0FBQyxFQUFFLEtBQUssWUFBWSxDQUFDLENBQUMsQ0FBQyxDQUFDLENBQUMsSUFDekQsTUFBTSxDQUFDO2dCQUNULElBQUksR0FBRyxDQUFBLGFBQWEsQ0FBQyxPQUFPLENBQUMsR0FBRyxDQUFDLGtCQUFrQixDQUFDLElBQ2xELGFBQWEsQ0FBQyxPQUFPLENBQUMsR0FBRyxDQUFDLE1BQU0sQ0FBQyxDQUFBLElBQUksRUFBRSxDQUFDO2FBQzNDLE1BQU07Z0JBQ0wsS0FBSyxHQUFHLElBQUksQ0FBQyxDQUFDLE1BQU0sR0FBRyxPQUFPLEdBQUcsTUFBTSxDQUFDO2dCQUN4QyxJQUFJLEdBQUcsYUFBYSxDQUFDLE9BQU8sQ0FBQyxHQUFHLENBQUMsTUFBTSxDQUFDLElBQUksRUFBRSxDQUFDO2FBQ2hEO1lBQ0QsSUFBSTtnQkFDRixJQUFJLENBQUMsQ0FBQyxHQUFHLEdBQUcsSUFBSSxHQUFHLENBQUMsQ0FBQyxFQUFFLEtBQUssQ0FBQyxHQUFHLEVBQUUsSUFBSSxDQUFDLEVBQUUsYUFBYSxDQUFDLEdBQUcsQ0FBQyxDQUFDLENBQUMsQ0FBQzthQUMvRCxDQUFDLE9BQU07Z0JBQ04sTUFBTSxJQUFJLFNBQVMsQ0FDakIsQ0FBQywyQkFBMkIsRUFBRSxLQUFLLENBQUMsR0FBRyxFQUFFLElBQUksQ0FBQyxFQUFFLGFBQWEsQ0FBQyxHQUFHLENBQUMsYUFBYSxDQUFDLENBQ2pGLENBQUM7YUFDSDtTQUNGO1FBQ0QsT0FBTyxJQUFJLENBQUMsQ0FBQyxHQUFHLENBQUM7S0FDbEI7SUFFRCxZQUNFLGFBQTRCLEVBQzVCLEtBQUssR0FBRyxLQUFLLEVBQ2IsTUFBTSxHQUFHLEtBQUssQ0FDZDtRQUNBLElBQUksQ0FBQyxDQUFDLEtBQUssR0FBRyxLQUFLLENBQUM7UUFDcEIsSUFBSSxDQUFDLENBQUMsTUFBTSxHQUFHLE1BQU0sQ0FBQztRQUN0QixJQUFJLENBQUMsQ0FBQyxhQUFhLEdBQUcsYUFBYSxDQUFDO1FBQ3BDLElBQUksQ0FBQyxDQUFDLElBQUksR0FBRyxJQUFJLFdBQVcsQ0FDMUIsYUFBYSxDQUFDLE9BQU8sRUFBRSxFQUN2QixhQUFhLENBQUMsT0FBTyxDQUN0QixDQUFDO0tBQ0g7SUFZRCxPQUFPLENBQUMsR0FBRyxLQUFLLEFBQVUsRUFBaUM7UUFDekQsTUFBTSxXQUFXLEdBQUcsSUFBSSxDQUFDLENBQUMsYUFBYSxDQUFDLE9BQU8sQ0FBQyxHQUFHLENBQUMsUUFBUSxDQUFDLEFBQUM7UUFDOUQsSUFBSSxDQUFDLFdBQVcsRUFBRTtZQUNoQixPQUFPLEtBQUssQ0FBQyxNQUFNLEdBQUcsS0FBSyxDQUFDLENBQUMsQ0FBQyxHQUFHO2dCQUFDLEtBQUs7YUFBQyxDQUFDO1NBQzFDO1FBQ0QsSUFBSSxLQUFLLENBQUMsTUFBTSxFQUFFO1lBQ2hCLE9BQU8sbUJBQW1CLENBQUMsV0FBVyxFQUFFLEtBQUssQ0FBQyxDQUFDLENBQUMsQ0FBQyxDQUFDO1NBQ25EO1FBQ0QsT0FBTyxtQkFBbUIsQ0FBQyxXQUFXLENBQUMsQ0FBQztLQUN6QztJQVVELHVFQUF1RSxDQUN2RSxlQUFlLENBQUMsR0FBRyxRQUFRLEFBQVUsRUFBaUM7UUFDcEUsTUFBTSxrQkFBa0IsR0FBRyxJQUFJLENBQUMsQ0FBQyxhQUFhLENBQUMsT0FBTyxDQUFDLEdBQUcsQ0FDeEQsZ0JBQWdCLENBQ2pCLEFBQUM7UUFDRixJQUFJLENBQUMsa0JBQWtCLEVBQUU7WUFDdkIsT0FBTyxRQUFRLENBQUMsTUFBTSxHQUFHLFFBQVEsQ0FBQyxDQUFDLENBQUMsR0FBRztnQkFBQyxHQUFHO2FBQUMsQ0FBQztTQUM5QztRQUNELElBQUksUUFBUSxDQUFDLE1BQU0sRUFBRTtZQUNuQixPQUFPLGlCQUFpQixDQUFDLGtCQUFrQixFQUFFLFFBQVEsQ0FBQyxDQUFDLENBQUMsQ0FBQyxDQUFDO1NBQzNEO1FBQ0QsT0FBTyxpQkFBaUIsQ0FBQyxrQkFBa0IsQ0FBQyxDQUFDO0tBQzlDO0lBZ0JELGdCQUFnQixDQUFDLEdBQUcsU0FBUyxBQUFVLEVBQWlDO1FBQ3RFLE1BQU0sbUJBQW1CLEdBQUcsSUFBSSxDQUFDLENBQUMsYUFBYSxDQUFDLE9BQU8sQ0FBQyxHQUFHLENBQ3pELGlCQUFpQixDQUNsQixBQUFDO1FBQ0YsSUFBSSxDQUFDLG1CQUFtQixFQUFFO1lBQ3hCLE9BQU8sU0FBUyxDQUFDLE1BQU0sR0FBRyxTQUFTLENBQUMsQ0FBQyxDQUFDLEdBQUc7Z0JBQUMsR0FBRzthQUFDLENBQUM7U0FDaEQ7UUFDRCxJQUFJLFNBQVMsQ0FBQyxNQUFNLEVBQUU7WUFDcEIsT0FBTyxrQkFBa0IsQ0FBQyxtQkFBbUIsRUFBRSxTQUFTLENBQUMsQ0FBQyxDQUFDLENBQUMsQ0FBQztTQUM5RDtRQUNELE9BQU8sa0JBQWtCLENBQUMsbUJBQW1CLENBQUMsQ0FBQztLQUNoRDtJQVdELGdCQUFnQixDQUFDLEdBQUcsS0FBSyxBQUFVLEVBQWlDO1FBQ2xFLE1BQU0sbUJBQW1CLEdBQUcsSUFBSSxDQUFDLENBQUMsYUFBYSxDQUFDLE9BQU8sQ0FBQyxHQUFHLENBQ3pELGlCQUFpQixDQUNsQixBQUFDO1FBQ0YsSUFBSSxDQUFDLG1CQUFtQixFQUFFO1lBQ3hCLE9BQU8sS0FBSyxDQUFDLE1BQU0sR0FBRyxLQUFLLENBQUMsQ0FBQyxDQUFDLEdBQUc7Z0JBQUMsR0FBRzthQUFDLENBQUM7U0FDeEM7UUFDRCxJQUFJLEtBQUssQ0FBQyxNQUFNLEVBQUU7WUFDaEIsT0FBTyxrQkFBa0IsQ0FBQyxtQkFBbUIsRUFBRSxLQUFLLENBQUMsQ0FBQyxDQUFDLENBQUMsQ0FBQztTQUMxRDtRQUNELE9BQU8sa0JBQWtCLENBQUMsbUJBQW1CLENBQUMsQ0FBQztLQUNoRDtJQVVEOztnQkFFYyxDQUNkLElBQUksQ0FBQyxPQUFvQixHQUFHLEVBQUUsRUFBa0M7UUFDOUQsT0FBTyxJQUFJLENBQUMsQ0FBQyxJQUFJLENBQUMsR0FBRyxDQUFDLE9BQU8sQ0FBQyxDQUFDO0tBQ2hDO0lBRUQsQ0FBQyxNQUFNLENBQUMsR0FBRyxDQUFDLG9CQUFvQixDQUFDLENBQUMsQ0FBQyxPQUFtQyxFQUFFO1FBQ3RFLE1BQU0sRUFBRSxPQUFPLENBQUEsRUFBRSxPQUFPLENBQUEsRUFBRSxFQUFFLENBQUEsRUFBRSxHQUFHLENBQUEsRUFBRSxNQUFNLENBQUEsRUFBRSxNQUFNLENBQUEsRUFBRSxHQUFHLENBQUEsRUFBRSxHQUFHLElBQUksQUFBQztRQUNoRSxPQUFPLENBQUMsRUFBRSxJQUFJLENBQUMsV0FBVyxDQUFDLElBQUksQ0FBQyxDQUFDLEVBQy9CLE9BQU8sQ0FBQztZQUNOLE9BQU87WUFDUCxPQUFPO1lBQ1AsRUFBRTtZQUNGLEdBQUc7WUFDSCxNQUFNO1lBQ04sTUFBTTtZQUNOLEdBQUcsRUFBRSxHQUFHLENBQUMsUUFBUSxFQUFFO1NBQ3BCLENBQUMsQ0FDSCxDQUFDLENBQUM7S0FDSjtJQUVELENBQUMsTUFBTSxDQUFDLEdBQUcsQ0FBQyw0QkFBNEIsQ0FBQyxDQUFDLENBQ3hDLEtBQWEsRUFDYixtQ0FBbUM7SUFDbkMsT0FBWSxFQUNaLE9BQXNELEVBQ3REO1FBQ0EsSUFBSSxLQUFLLEdBQUcsQ0FBQyxFQUFFO1lBQ2IsT0FBTyxPQUFPLENBQUMsT0FBTyxDQUFDLENBQUMsQ0FBQyxFQUFFLElBQUksQ0FBQyxXQUFXLENBQUMsSUFBSSxDQUFDLENBQUMsQ0FBQyxFQUFFLFNBQVMsQ0FBQyxDQUFDO1NBQ2pFO1FBRUQsTUFBTSxVQUFVLEdBQUcsTUFBTSxDQUFDLE1BQU0sQ0FBQyxFQUFFLEVBQUUsT0FBTyxFQUFFO1lBQzVDLEtBQUssRUFBRSxPQUFPLENBQUMsS0FBSyxLQUFLLElBQUksR0FBRyxJQUFJLEdBQUcsT0FBTyxDQUFDLEtBQUssR0FBRyxDQUFDO1NBQ3pELENBQUMsQUFBQztRQUNILE1BQU0sRUFBRSxPQUFPLENBQUEsRUFBRSxPQUFPLENBQUEsRUFBRSxFQUFFLENBQUEsRUFBRSxHQUFHLENBQUEsRUFBRSxNQUFNLENBQUEsRUFBRSxNQUFNLENBQUEsRUFBRSxHQUFHLENBQUEsRUFBRSxHQUFHLElBQUksQUFBQztRQUNoRSxPQUFPLENBQUMsRUFBRSxPQUFPLENBQUMsT0FBTyxDQUFDLElBQUksQ0FBQyxXQUFXLENBQUMsSUFBSSxFQUFFLFNBQVMsQ0FBQyxDQUFDLENBQUMsRUFDM0QsT0FBTyxDQUNMO1lBQUUsT0FBTztZQUFFLE9BQU87WUFBRSxFQUFFO1lBQUUsR0FBRztZQUFFLE1BQU07WUFBRSxNQUFNO1lBQUUsR0FBRztTQUFFLEVBQ2xELFVBQVUsQ0FDWCxDQUNGLENBQUMsQ0FBQztLQUNKO0NBQ0YifQ==
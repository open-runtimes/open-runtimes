import { base64, isAbsolute, join, normalize, sep, Status } from "./deps.ts";
import { createHttpError } from "./httpError.ts";
const ENCODE_CHARS_REGEXP = /(?:[^\x21\x25\x26-\x3B\x3D\x3F-\x5B\x5D\x5F\x61-\x7A\x7E]|%(?:[^0-9A-Fa-f]|[0-9A-Fa-f][^0-9A-Fa-f]|$))+/g;
const HTAB = "\t".charCodeAt(0);
const SPACE = " ".charCodeAt(0);
const CR = "\r".charCodeAt(0);
const LF = "\n".charCodeAt(0);
const UNMATCHED_SURROGATE_PAIR_REGEXP = /(^|[^\uD800-\uDBFF])[\uDC00-\uDFFF]|[\uD800-\uDBFF]([^\uDC00-\uDFFF]|$)/g;
const UNMATCHED_SURROGATE_PAIR_REPLACE = "$1\uFFFD$2";
export const DEFAULT_CHUNK_SIZE = 16_640; // 17 Kib
/** Body types which will be coerced into strings before being sent. */ export const BODY_TYPES = [
    "string",
    "number",
    "bigint",
    "boolean",
    "symbol"
];
export function assert(cond, msg = "Assertion failed") {
    if (!cond) {
        throw new Error(msg);
    }
}
/** Safely decode a URI component, where if it fails, instead of throwing,
 * just returns the original string
 */ export function decodeComponent(text) {
    try {
        return decodeURIComponent(text);
    } catch  {
        return text;
    }
}
/** Encodes the url preventing double enconding */ export function encodeUrl(url) {
    return String(url).replace(UNMATCHED_SURROGATE_PAIR_REGEXP, UNMATCHED_SURROGATE_PAIR_REPLACE).replace(ENCODE_CHARS_REGEXP, encodeURI);
}
function bufferToHex(buffer) {
    const arr = Array.from(new Uint8Array(buffer));
    return arr.map((b)=>b.toString(16).padStart(2, "0")).join("");
}
export async function getRandomFilename(prefix = "", extension = "") {
    const buffer = await crypto.subtle.digest("SHA-1", crypto.getRandomValues(new Uint8Array(256)));
    return `${prefix}${bufferToHex(buffer)}${extension ? `.${extension}` : ""}`;
}
export async function getBoundary() {
    const buffer = await crypto.subtle.digest("SHA-1", crypto.getRandomValues(new Uint8Array(256)));
    return `oak_${bufferToHex(buffer)}`;
}
/** Guard for Async Iterables */ export function isAsyncIterable(value) {
    return typeof value === "object" && value !== null && Symbol.asyncIterator in value && // deno-lint-ignore no-explicit-any
    typeof value[Symbol.asyncIterator] === "function";
}
export function isRouterContext(value) {
    return "params" in value;
}
/** Guard for `Deno.Reader`. */ export function isReader(value) {
    return typeof value === "object" && value !== null && "read" in value && typeof value.read === "function";
}
function isCloser(value) {
    return typeof value === "object" && value != null && "close" in value && // deno-lint-ignore no-explicit-any
    typeof value["close"] === "function";
}
export function isConn(value) {
    return typeof value === "object" && value != null && "rid" in value && // deno-lint-ignore no-explicit-any
    typeof value.rid === "number" && "localAddr" in value && "remoteAddr" in value;
}
export function isListenTlsOptions(value) {
    return typeof value === "object" && value !== null && ("cert" in value || "certFile" in value) && ("key" in value || "keyFile" in value) && "port" in value;
}
/**
 * Create a `ReadableStream<Uint8Array>` from an `AsyncIterable`.
 */ export function readableStreamFromAsyncIterable(source) {
    return new ReadableStream({
        async start (controller) {
            for await (const chunk of source){
                if (BODY_TYPES.includes(typeof chunk)) {
                    controller.enqueue(encoder.encode(String(chunk)));
                } else if (chunk instanceof Uint8Array) {
                    controller.enqueue(chunk);
                } else if (ArrayBuffer.isView(chunk)) {
                    controller.enqueue(new Uint8Array(chunk.buffer));
                } else if (chunk instanceof ArrayBuffer) {
                    controller.enqueue(new Uint8Array(chunk));
                } else {
                    try {
                        controller.enqueue(encoder.encode(JSON.stringify(chunk)));
                    } catch  {
                    // we just swallow errors here
                    }
                }
            }
            controller.close();
        }
    });
}
/**
 * Create a `ReadableStream<Uint8Array>` from a `Deno.Reader`.
 *
 * When the pull algorithm is called on the stream, a chunk from the reader
 * will be read.  When `null` is returned from the reader, the stream will be
 * closed along with the reader (if it is also a `Deno.Closer`).
 *
 * An example converting a `Deno.FsFile` into a readable stream:
 *
 * ```ts
 * import { readableStreamFromReader } from "https://deno.land/std/io/mod.ts";
 *
 * const file = await Deno.open("./file.txt", { read: true });
 * const fileStream = readableStreamFromReader(file);
 * ```
 */ export function readableStreamFromReader(reader, options = {}) {
    const { autoClose =true , chunkSize =DEFAULT_CHUNK_SIZE , strategy ,  } = options;
    return new ReadableStream({
        async pull (controller) {
            const chunk = new Uint8Array(chunkSize);
            try {
                const read = await reader.read(chunk);
                if (read === null) {
                    if (isCloser(reader) && autoClose) {
                        reader.close();
                    }
                    controller.close();
                    return;
                }
                controller.enqueue(chunk.subarray(0, read));
            } catch (e) {
                controller.error(e);
                if (isCloser(reader)) {
                    reader.close();
                }
            }
        },
        cancel () {
            if (isCloser(reader) && autoClose) {
                reader.close();
            }
        }
    }, strategy);
}
/** Determines if a HTTP `Status` is an `ErrorStatus` (4XX or 5XX). */ export function isErrorStatus(value) {
    return [
        Status.BadRequest,
        Status.Unauthorized,
        Status.PaymentRequired,
        Status.Forbidden,
        Status.NotFound,
        Status.MethodNotAllowed,
        Status.NotAcceptable,
        Status.ProxyAuthRequired,
        Status.RequestTimeout,
        Status.Conflict,
        Status.Gone,
        Status.LengthRequired,
        Status.PreconditionFailed,
        Status.RequestEntityTooLarge,
        Status.RequestURITooLong,
        Status.UnsupportedMediaType,
        Status.RequestedRangeNotSatisfiable,
        Status.ExpectationFailed,
        Status.Teapot,
        Status.MisdirectedRequest,
        Status.UnprocessableEntity,
        Status.Locked,
        Status.FailedDependency,
        Status.UpgradeRequired,
        Status.PreconditionRequired,
        Status.TooManyRequests,
        Status.RequestHeaderFieldsTooLarge,
        Status.UnavailableForLegalReasons,
        Status.InternalServerError,
        Status.NotImplemented,
        Status.BadGateway,
        Status.ServiceUnavailable,
        Status.GatewayTimeout,
        Status.HTTPVersionNotSupported,
        Status.VariantAlsoNegotiates,
        Status.InsufficientStorage,
        Status.LoopDetected,
        Status.NotExtended,
        Status.NetworkAuthenticationRequired, 
    ].includes(value);
}
/** Determines if a HTTP `Status` is a `RedirectStatus` (3XX). */ export function isRedirectStatus(value) {
    return [
        Status.MultipleChoices,
        Status.MovedPermanently,
        Status.Found,
        Status.SeeOther,
        Status.UseProxy,
        Status.TemporaryRedirect,
        Status.PermanentRedirect, 
    ].includes(value);
}
/** Determines if a string "looks" like HTML */ export function isHtml(value) {
    return /^\s*<(?:!DOCTYPE|html|body)/i.test(value);
}
/** Returns `u8` with leading white space removed. */ export function skipLWSPChar(u8) {
    const result = new Uint8Array(u8.length);
    let j = 0;
    for(let i = 0; i < u8.length; i++){
        if (u8[i] === SPACE || u8[i] === HTAB) continue;
        result[j++] = u8[i];
    }
    return result.slice(0, j);
}
export function stripEol(value) {
    if (value[value.byteLength - 1] == LF) {
        let drop = 1;
        if (value.byteLength > 1 && value[value.byteLength - 2] === CR) {
            drop = 2;
        }
        return value.subarray(0, value.byteLength - drop);
    }
    return value;
}
/*!
 * Adapted directly from https://github.com/pillarjs/resolve-path
 * which is licensed as follows:
 *
 * The MIT License (MIT)
 *
 * Copyright (c) 2014 Jonathan Ong <me@jongleberry.com>
 * Copyright (c) 2015-2018 Douglas Christopher Wilson <doug@somethingdoug.com>
 *
 * Permission is hereby granted, free of charge, to any person obtaining
 * a copy of this software and associated documentation files (the
 * 'Software'), to deal in the Software without restriction, including
 * without limitation the rights to use, copy, modify, merge, publish,
 * distribute, sublicense, and/or sell copies of the Software, and to
 * permit persons to whom the Software is furnished to do so, subject to
 * the following conditions:
 *
 * The above copyright notice and this permission notice shall be
 * included in all copies or substantial portions of the Software.
 *
 * THE SOFTWARE IS PROVIDED 'AS IS', WITHOUT WARRANTY OF ANY KIND,
 * EXPRESS OR IMPLIED, INCLUDING BUT NOT LIMITED TO THE WARRANTIES OF
 * MERCHANTABILITY, FITNESS FOR A PARTICULAR PURPOSE AND NONINFRINGEMENT.
 * IN NO EVENT SHALL THE AUTHORS OR COPYRIGHT HOLDERS BE LIABLE FOR ANY
 * CLAIM, DAMAGES OR OTHER LIABILITY, WHETHER IN AN ACTION OF CONTRACT,
 * TORT OR OTHERWISE, ARISING FROM, OUT OF OR IN CONNECTION WITH THE
 * SOFTWARE OR THE USE OR OTHER DEALINGS IN THE SOFTWARE.
 */ const UP_PATH_REGEXP = /(?:^|[\\/])\.\.(?:[\\/]|$)/;
export function resolvePath(rootPath, relativePath) {
    let path = relativePath;
    let root = rootPath;
    // root is optional, similar to root.resolve
    if (relativePath === undefined) {
        path = rootPath;
        root = ".";
    }
    if (path == null) {
        throw new TypeError("Argument relativePath is required.");
    }
    // containing NULL bytes is malicious
    if (path.includes("\0")) {
        throw createHttpError(400, "Malicious Path");
    }
    // path should never be absolute
    if (isAbsolute(path)) {
        throw createHttpError(400, "Malicious Path");
    }
    // path outside root
    if (UP_PATH_REGEXP.test(normalize("." + sep + path))) {
        throw createHttpError(403);
    }
    // join the relative path
    return normalize(join(root, path));
}
/** A utility class that transforms "any" chunk into an `Uint8Array`. */ export class Uint8ArrayTransformStream extends TransformStream {
    constructor(){
        const init = {
            async transform (chunk, controller) {
                chunk = await chunk;
                switch(typeof chunk){
                    case "object":
                        if (chunk === null) {
                            controller.terminate();
                        } else if (ArrayBuffer.isView(chunk)) {
                            controller.enqueue(new Uint8Array(chunk.buffer, chunk.byteOffset, chunk.byteLength));
                        } else if (Array.isArray(chunk) && chunk.every((value)=>typeof value === "number")) {
                            controller.enqueue(new Uint8Array(chunk));
                        } else if (typeof chunk.valueOf === "function" && chunk.valueOf() !== chunk) {
                            this.transform(chunk.valueOf(), controller);
                        } else if ("toJSON" in chunk) {
                            this.transform(JSON.stringify(chunk), controller);
                        }
                        break;
                    case "symbol":
                        controller.error(new TypeError("Cannot transform a symbol to a Uint8Array"));
                        break;
                    case "undefined":
                        controller.error(new TypeError("Cannot transform undefined to a Uint8Array"));
                        break;
                    default:
                        controller.enqueue(this.encoder.encode(String(chunk)));
                }
            },
            encoder: new TextEncoder()
        };
        super(init);
    }
}
const replacements = {
    "/": "_",
    "+": "-",
    "=": ""
};
const encoder = new TextEncoder();
export function encodeBase64Safe(data) {
    return base64.encode(data).replace(/\/|\+|=/g, (c)=>replacements[c]);
}
export function isNode() {
    return "process" in globalThis && "global" in globalThis;
}
export function importKey(key) {
    if (typeof key === "string") {
        key = encoder.encode(key);
    } else if (Array.isArray(key)) {
        key = new Uint8Array(key);
    }
    return crypto.subtle.importKey("raw", key, {
        name: "HMAC",
        hash: {
            name: "SHA-256"
        }
    }, true, [
        "sign",
        "verify"
    ]);
}
export function sign(data, key) {
    if (typeof data === "string") {
        data = encoder.encode(data);
    } else if (Array.isArray(data)) {
        data = Uint8Array.from(data);
    }
    return crypto.subtle.sign("HMAC", key, data);
}
//# sourceMappingURL=data:application/json;base64,eyJ2ZXJzaW9uIjozLCJzb3VyY2VzIjpbImh0dHBzOi8vZGVuby5sYW5kL3gvb2FrQHYxMC42LjAvdXRpbC50cyJdLCJzb3VyY2VzQ29udGVudCI6WyIvLyBDb3B5cmlnaHQgMjAxOC0yMDIyIHRoZSBvYWsgYXV0aG9ycy4gQWxsIHJpZ2h0cyByZXNlcnZlZC4gTUlUIGxpY2Vuc2UuXG5cbmltcG9ydCB0eXBlIHsgU3RhdGUgfSBmcm9tIFwiLi9hcHBsaWNhdGlvbi50c1wiO1xuaW1wb3J0IHR5cGUgeyBDb250ZXh0IH0gZnJvbSBcIi4vY29udGV4dC50c1wiO1xuaW1wb3J0IHsgYmFzZTY0LCBpc0Fic29sdXRlLCBqb2luLCBub3JtYWxpemUsIHNlcCwgU3RhdHVzIH0gZnJvbSBcIi4vZGVwcy50c1wiO1xuaW1wb3J0IHsgY3JlYXRlSHR0cEVycm9yIH0gZnJvbSBcIi4vaHR0cEVycm9yLnRzXCI7XG5pbXBvcnQgdHlwZSB7IFJvdXRlUGFyYW1zLCBSb3V0ZXJDb250ZXh0IH0gZnJvbSBcIi4vcm91dGVyLnRzXCI7XG5pbXBvcnQgdHlwZSB7IERhdGEsIEVycm9yU3RhdHVzLCBLZXksIFJlZGlyZWN0U3RhdHVzIH0gZnJvbSBcIi4vdHlwZXMuZC50c1wiO1xuXG5jb25zdCBFTkNPREVfQ0hBUlNfUkVHRVhQID1cbiAgLyg/OlteXFx4MjFcXHgyNVxceDI2LVxceDNCXFx4M0RcXHgzRi1cXHg1QlxceDVEXFx4NUZcXHg2MS1cXHg3QVxceDdFXXwlKD86W14wLTlBLUZhLWZdfFswLTlBLUZhLWZdW14wLTlBLUZhLWZdfCQpKSsvZztcbmNvbnN0IEhUQUIgPSBcIlxcdFwiLmNoYXJDb2RlQXQoMCk7XG5jb25zdCBTUEFDRSA9IFwiIFwiLmNoYXJDb2RlQXQoMCk7XG5jb25zdCBDUiA9IFwiXFxyXCIuY2hhckNvZGVBdCgwKTtcbmNvbnN0IExGID0gXCJcXG5cIi5jaGFyQ29kZUF0KDApO1xuY29uc3QgVU5NQVRDSEVEX1NVUlJPR0FURV9QQUlSX1JFR0VYUCA9XG4gIC8oXnxbXlxcdUQ4MDAtXFx1REJGRl0pW1xcdURDMDAtXFx1REZGRl18W1xcdUQ4MDAtXFx1REJGRl0oW15cXHVEQzAwLVxcdURGRkZdfCQpL2c7XG5jb25zdCBVTk1BVENIRURfU1VSUk9HQVRFX1BBSVJfUkVQTEFDRSA9IFwiJDFcXHVGRkZEJDJcIjtcbmV4cG9ydCBjb25zdCBERUZBVUxUX0NIVU5LX1NJWkUgPSAxNl82NDA7IC8vIDE3IEtpYlxuXG4vKiogQm9keSB0eXBlcyB3aGljaCB3aWxsIGJlIGNvZXJjZWQgaW50byBzdHJpbmdzIGJlZm9yZSBiZWluZyBzZW50LiAqL1xuZXhwb3J0IGNvbnN0IEJPRFlfVFlQRVMgPSBbXCJzdHJpbmdcIiwgXCJudW1iZXJcIiwgXCJiaWdpbnRcIiwgXCJib29sZWFuXCIsIFwic3ltYm9sXCJdO1xuXG5leHBvcnQgZnVuY3Rpb24gYXNzZXJ0KGNvbmQ6IHVua25vd24sIG1zZyA9IFwiQXNzZXJ0aW9uIGZhaWxlZFwiKTogYXNzZXJ0cyBjb25kIHtcbiAgaWYgKCFjb25kKSB7XG4gICAgdGhyb3cgbmV3IEVycm9yKG1zZyk7XG4gIH1cbn1cblxuLyoqIFNhZmVseSBkZWNvZGUgYSBVUkkgY29tcG9uZW50LCB3aGVyZSBpZiBpdCBmYWlscywgaW5zdGVhZCBvZiB0aHJvd2luZyxcbiAqIGp1c3QgcmV0dXJucyB0aGUgb3JpZ2luYWwgc3RyaW5nXG4gKi9cbmV4cG9ydCBmdW5jdGlvbiBkZWNvZGVDb21wb25lbnQodGV4dDogc3RyaW5nKSB7XG4gIHRyeSB7XG4gICAgcmV0dXJuIGRlY29kZVVSSUNvbXBvbmVudCh0ZXh0KTtcbiAgfSBjYXRjaCB7XG4gICAgcmV0dXJuIHRleHQ7XG4gIH1cbn1cblxuLyoqIEVuY29kZXMgdGhlIHVybCBwcmV2ZW50aW5nIGRvdWJsZSBlbmNvbmRpbmcgKi9cbmV4cG9ydCBmdW5jdGlvbiBlbmNvZGVVcmwodXJsOiBzdHJpbmcpIHtcbiAgcmV0dXJuIFN0cmluZyh1cmwpXG4gICAgLnJlcGxhY2UoVU5NQVRDSEVEX1NVUlJPR0FURV9QQUlSX1JFR0VYUCwgVU5NQVRDSEVEX1NVUlJPR0FURV9QQUlSX1JFUExBQ0UpXG4gICAgLnJlcGxhY2UoRU5DT0RFX0NIQVJTX1JFR0VYUCwgZW5jb2RlVVJJKTtcbn1cblxuZnVuY3Rpb24gYnVmZmVyVG9IZXgoYnVmZmVyOiBBcnJheUJ1ZmZlcik6IHN0cmluZyB7XG4gIGNvbnN0IGFyciA9IEFycmF5LmZyb20obmV3IFVpbnQ4QXJyYXkoYnVmZmVyKSk7XG4gIHJldHVybiBhcnIubWFwKChiKSA9PiBiLnRvU3RyaW5nKDE2KS5wYWRTdGFydCgyLCBcIjBcIikpLmpvaW4oXCJcIik7XG59XG5cbmV4cG9ydCBhc3luYyBmdW5jdGlvbiBnZXRSYW5kb21GaWxlbmFtZShcbiAgcHJlZml4ID0gXCJcIixcbiAgZXh0ZW5zaW9uID0gXCJcIixcbik6IFByb21pc2U8c3RyaW5nPiB7XG4gIGNvbnN0IGJ1ZmZlciA9IGF3YWl0IGNyeXB0by5zdWJ0bGUuZGlnZXN0KFxuICAgIFwiU0hBLTFcIixcbiAgICBjcnlwdG8uZ2V0UmFuZG9tVmFsdWVzKG5ldyBVaW50OEFycmF5KDI1NikpLFxuICApO1xuICByZXR1cm4gYCR7cHJlZml4fSR7YnVmZmVyVG9IZXgoYnVmZmVyKX0ke2V4dGVuc2lvbiA/IGAuJHtleHRlbnNpb259YCA6IFwiXCJ9YDtcbn1cblxuZXhwb3J0IGFzeW5jIGZ1bmN0aW9uIGdldEJvdW5kYXJ5KCk6IFByb21pc2U8c3RyaW5nPiB7XG4gIGNvbnN0IGJ1ZmZlciA9IGF3YWl0IGNyeXB0by5zdWJ0bGUuZGlnZXN0KFxuICAgIFwiU0hBLTFcIixcbiAgICBjcnlwdG8uZ2V0UmFuZG9tVmFsdWVzKG5ldyBVaW50OEFycmF5KDI1NikpLFxuICApO1xuICByZXR1cm4gYG9ha18ke2J1ZmZlclRvSGV4KGJ1ZmZlcil9YDtcbn1cblxuLyoqIEd1YXJkIGZvciBBc3luYyBJdGVyYWJsZXMgKi9cbmV4cG9ydCBmdW5jdGlvbiBpc0FzeW5jSXRlcmFibGUoXG4gIHZhbHVlOiB1bmtub3duLFxuKTogdmFsdWUgaXMgQXN5bmNJdGVyYWJsZTx1bmtub3duPiB7XG4gIHJldHVybiB0eXBlb2YgdmFsdWUgPT09IFwib2JqZWN0XCIgJiYgdmFsdWUgIT09IG51bGwgJiZcbiAgICBTeW1ib2wuYXN5bmNJdGVyYXRvciBpbiB2YWx1ZSAmJlxuICAgIC8vIGRlbm8tbGludC1pZ25vcmUgbm8tZXhwbGljaXQtYW55XG4gICAgdHlwZW9mICh2YWx1ZSBhcyBhbnkpW1N5bWJvbC5hc3luY0l0ZXJhdG9yXSA9PT0gXCJmdW5jdGlvblwiO1xufVxuXG5leHBvcnQgZnVuY3Rpb24gaXNSb3V0ZXJDb250ZXh0PFxuICBSIGV4dGVuZHMgc3RyaW5nLFxuICBQIGV4dGVuZHMgUm91dGVQYXJhbXM8Uj4sXG4gIFMgZXh0ZW5kcyBTdGF0ZSxcbj4oXG4gIHZhbHVlOiBDb250ZXh0PFM+LFxuKTogdmFsdWUgaXMgUm91dGVyQ29udGV4dDxSLCBQLCBTPiB7XG4gIHJldHVybiBcInBhcmFtc1wiIGluIHZhbHVlO1xufVxuXG4vKiogR3VhcmQgZm9yIGBEZW5vLlJlYWRlcmAuICovXG5leHBvcnQgZnVuY3Rpb24gaXNSZWFkZXIodmFsdWU6IHVua25vd24pOiB2YWx1ZSBpcyBEZW5vLlJlYWRlciB7XG4gIHJldHVybiB0eXBlb2YgdmFsdWUgPT09IFwib2JqZWN0XCIgJiYgdmFsdWUgIT09IG51bGwgJiYgXCJyZWFkXCIgaW4gdmFsdWUgJiZcbiAgICB0eXBlb2YgKHZhbHVlIGFzIFJlY29yZDxzdHJpbmcsIHVua25vd24+KS5yZWFkID09PSBcImZ1bmN0aW9uXCI7XG59XG5cbmZ1bmN0aW9uIGlzQ2xvc2VyKHZhbHVlOiB1bmtub3duKTogdmFsdWUgaXMgRGVuby5DbG9zZXIge1xuICByZXR1cm4gdHlwZW9mIHZhbHVlID09PSBcIm9iamVjdFwiICYmIHZhbHVlICE9IG51bGwgJiYgXCJjbG9zZVwiIGluIHZhbHVlICYmXG4gICAgLy8gZGVuby1saW50LWlnbm9yZSBuby1leHBsaWNpdC1hbnlcbiAgICB0eXBlb2YgKHZhbHVlIGFzIFJlY29yZDxzdHJpbmcsIGFueT4pW1wiY2xvc2VcIl0gPT09IFwiZnVuY3Rpb25cIjtcbn1cblxuZXhwb3J0IGZ1bmN0aW9uIGlzQ29ubih2YWx1ZTogdW5rbm93bik6IHZhbHVlIGlzIERlbm8uQ29ubiB7XG4gIHJldHVybiB0eXBlb2YgdmFsdWUgPT09IFwib2JqZWN0XCIgJiYgdmFsdWUgIT0gbnVsbCAmJiBcInJpZFwiIGluIHZhbHVlICYmXG4gICAgLy8gZGVuby1saW50LWlnbm9yZSBuby1leHBsaWNpdC1hbnlcbiAgICB0eXBlb2YgKHZhbHVlIGFzIGFueSkucmlkID09PSBcIm51bWJlclwiICYmIFwibG9jYWxBZGRyXCIgaW4gdmFsdWUgJiZcbiAgICBcInJlbW90ZUFkZHJcIiBpbiB2YWx1ZTtcbn1cblxuZXhwb3J0IGZ1bmN0aW9uIGlzTGlzdGVuVGxzT3B0aW9ucyhcbiAgdmFsdWU6IHVua25vd24sXG4pOiB2YWx1ZSBpcyBEZW5vLkxpc3RlblRsc09wdGlvbnMge1xuICByZXR1cm4gdHlwZW9mIHZhbHVlID09PSBcIm9iamVjdFwiICYmIHZhbHVlICE9PSBudWxsICYmXG4gICAgKFwiY2VydFwiIGluIHZhbHVlIHx8IFwiY2VydEZpbGVcIiBpbiB2YWx1ZSkgJiZcbiAgICAoXCJrZXlcIiBpbiB2YWx1ZSB8fCBcImtleUZpbGVcIiBpbiB2YWx1ZSkgJiYgXCJwb3J0XCIgaW4gdmFsdWU7XG59XG5cbmV4cG9ydCBpbnRlcmZhY2UgUmVhZGFibGVTdHJlYW1Gcm9tUmVhZGVyT3B0aW9ucyB7XG4gIC8qKiBJZiB0aGUgYHJlYWRlcmAgaXMgYWxzbyBhIGBEZW5vLkNsb3NlcmAsIGF1dG9tYXRpY2FsbHkgY2xvc2UgdGhlIGByZWFkZXJgXG4gICAqIHdoZW4gYEVPRmAgaXMgZW5jb3VudGVyZWQsIG9yIGEgcmVhZCBlcnJvciBvY2N1cnMuXG4gICAqXG4gICAqIERlZmF1bHRzIHRvIGB0cnVlYC4gKi9cbiAgYXV0b0Nsb3NlPzogYm9vbGVhbjtcblxuICAvKiogVGhlIHNpemUgb2YgY2h1bmtzIHRvIGFsbG9jYXRlIHRvIHJlYWQsIHRoZSBkZWZhdWx0IGlzIH4xNktpQiwgd2hpY2ggaXNcbiAgICogdGhlIG1heGltdW0gc2l6ZSB0aGF0IERlbm8gb3BlcmF0aW9ucyBjYW4gY3VycmVudGx5IHN1cHBvcnQuICovXG4gIGNodW5rU2l6ZT86IG51bWJlcjtcblxuICAvKiogVGhlIHF1ZXVpbmcgc3RyYXRlZ3kgdG8gY3JlYXRlIHRoZSBgUmVhZGFibGVTdHJlYW1gIHdpdGguICovXG4gIHN0cmF0ZWd5PzogeyBoaWdoV2F0ZXJNYXJrPzogbnVtYmVyIHwgdW5kZWZpbmVkOyBzaXplPzogdW5kZWZpbmVkIH07XG59XG5cbi8qKlxuICogQ3JlYXRlIGEgYFJlYWRhYmxlU3RyZWFtPFVpbnQ4QXJyYXk+YCBmcm9tIGFuIGBBc3luY0l0ZXJhYmxlYC5cbiAqL1xuZXhwb3J0IGZ1bmN0aW9uIHJlYWRhYmxlU3RyZWFtRnJvbUFzeW5jSXRlcmFibGUoXG4gIHNvdXJjZTogQXN5bmNJdGVyYWJsZTx1bmtub3duPixcbik6IFJlYWRhYmxlU3RyZWFtPFVpbnQ4QXJyYXk+IHtcbiAgcmV0dXJuIG5ldyBSZWFkYWJsZVN0cmVhbSh7XG4gICAgYXN5bmMgc3RhcnQoY29udHJvbGxlcikge1xuICAgICAgZm9yIGF3YWl0IChjb25zdCBjaHVuayBvZiBzb3VyY2UpIHtcbiAgICAgICAgaWYgKEJPRFlfVFlQRVMuaW5jbHVkZXModHlwZW9mIGNodW5rKSkge1xuICAgICAgICAgIGNvbnRyb2xsZXIuZW5xdWV1ZShlbmNvZGVyLmVuY29kZShTdHJpbmcoY2h1bmspKSk7XG4gICAgICAgIH0gZWxzZSBpZiAoY2h1bmsgaW5zdGFuY2VvZiBVaW50OEFycmF5KSB7XG4gICAgICAgICAgY29udHJvbGxlci5lbnF1ZXVlKGNodW5rKTtcbiAgICAgICAgfSBlbHNlIGlmIChBcnJheUJ1ZmZlci5pc1ZpZXcoY2h1bmspKSB7XG4gICAgICAgICAgY29udHJvbGxlci5lbnF1ZXVlKG5ldyBVaW50OEFycmF5KGNodW5rLmJ1ZmZlcikpO1xuICAgICAgICB9IGVsc2UgaWYgKGNodW5rIGluc3RhbmNlb2YgQXJyYXlCdWZmZXIpIHtcbiAgICAgICAgICBjb250cm9sbGVyLmVucXVldWUobmV3IFVpbnQ4QXJyYXkoY2h1bmspKTtcbiAgICAgICAgfSBlbHNlIHtcbiAgICAgICAgICB0cnkge1xuICAgICAgICAgICAgY29udHJvbGxlci5lbnF1ZXVlKGVuY29kZXIuZW5jb2RlKEpTT04uc3RyaW5naWZ5KGNodW5rKSkpO1xuICAgICAgICAgIH0gY2F0Y2gge1xuICAgICAgICAgICAgLy8gd2UganVzdCBzd2FsbG93IGVycm9ycyBoZXJlXG4gICAgICAgICAgfVxuICAgICAgICB9XG4gICAgICB9XG4gICAgICBjb250cm9sbGVyLmNsb3NlKCk7XG4gICAgfSxcbiAgfSk7XG59XG5cbi8qKlxuICogQ3JlYXRlIGEgYFJlYWRhYmxlU3RyZWFtPFVpbnQ4QXJyYXk+YCBmcm9tIGEgYERlbm8uUmVhZGVyYC5cbiAqXG4gKiBXaGVuIHRoZSBwdWxsIGFsZ29yaXRobSBpcyBjYWxsZWQgb24gdGhlIHN0cmVhbSwgYSBjaHVuayBmcm9tIHRoZSByZWFkZXJcbiAqIHdpbGwgYmUgcmVhZC4gIFdoZW4gYG51bGxgIGlzIHJldHVybmVkIGZyb20gdGhlIHJlYWRlciwgdGhlIHN0cmVhbSB3aWxsIGJlXG4gKiBjbG9zZWQgYWxvbmcgd2l0aCB0aGUgcmVhZGVyIChpZiBpdCBpcyBhbHNvIGEgYERlbm8uQ2xvc2VyYCkuXG4gKlxuICogQW4gZXhhbXBsZSBjb252ZXJ0aW5nIGEgYERlbm8uRnNGaWxlYCBpbnRvIGEgcmVhZGFibGUgc3RyZWFtOlxuICpcbiAqIGBgYHRzXG4gKiBpbXBvcnQgeyByZWFkYWJsZVN0cmVhbUZyb21SZWFkZXIgfSBmcm9tIFwiaHR0cHM6Ly9kZW5vLmxhbmQvc3RkL2lvL21vZC50c1wiO1xuICpcbiAqIGNvbnN0IGZpbGUgPSBhd2FpdCBEZW5vLm9wZW4oXCIuL2ZpbGUudHh0XCIsIHsgcmVhZDogdHJ1ZSB9KTtcbiAqIGNvbnN0IGZpbGVTdHJlYW0gPSByZWFkYWJsZVN0cmVhbUZyb21SZWFkZXIoZmlsZSk7XG4gKiBgYGBcbiAqL1xuZXhwb3J0IGZ1bmN0aW9uIHJlYWRhYmxlU3RyZWFtRnJvbVJlYWRlcihcbiAgcmVhZGVyOiBEZW5vLlJlYWRlciB8IChEZW5vLlJlYWRlciAmIERlbm8uQ2xvc2VyKSxcbiAgb3B0aW9uczogUmVhZGFibGVTdHJlYW1Gcm9tUmVhZGVyT3B0aW9ucyA9IHt9LFxuKTogUmVhZGFibGVTdHJlYW08VWludDhBcnJheT4ge1xuICBjb25zdCB7XG4gICAgYXV0b0Nsb3NlID0gdHJ1ZSxcbiAgICBjaHVua1NpemUgPSBERUZBVUxUX0NIVU5LX1NJWkUsXG4gICAgc3RyYXRlZ3ksXG4gIH0gPSBvcHRpb25zO1xuXG4gIHJldHVybiBuZXcgUmVhZGFibGVTdHJlYW0oe1xuICAgIGFzeW5jIHB1bGwoY29udHJvbGxlcikge1xuICAgICAgY29uc3QgY2h1bmsgPSBuZXcgVWludDhBcnJheShjaHVua1NpemUpO1xuICAgICAgdHJ5IHtcbiAgICAgICAgY29uc3QgcmVhZCA9IGF3YWl0IHJlYWRlci5yZWFkKGNodW5rKTtcbiAgICAgICAgaWYgKHJlYWQgPT09IG51bGwpIHtcbiAgICAgICAgICBpZiAoaXNDbG9zZXIocmVhZGVyKSAmJiBhdXRvQ2xvc2UpIHtcbiAgICAgICAgICAgIHJlYWRlci5jbG9zZSgpO1xuICAgICAgICAgIH1cbiAgICAgICAgICBjb250cm9sbGVyLmNsb3NlKCk7XG4gICAgICAgICAgcmV0dXJuO1xuICAgICAgICB9XG4gICAgICAgIGNvbnRyb2xsZXIuZW5xdWV1ZShjaHVuay5zdWJhcnJheSgwLCByZWFkKSk7XG4gICAgICB9IGNhdGNoIChlKSB7XG4gICAgICAgIGNvbnRyb2xsZXIuZXJyb3IoZSk7XG4gICAgICAgIGlmIChpc0Nsb3NlcihyZWFkZXIpKSB7XG4gICAgICAgICAgcmVhZGVyLmNsb3NlKCk7XG4gICAgICAgIH1cbiAgICAgIH1cbiAgICB9LFxuICAgIGNhbmNlbCgpIHtcbiAgICAgIGlmIChpc0Nsb3NlcihyZWFkZXIpICYmIGF1dG9DbG9zZSkge1xuICAgICAgICByZWFkZXIuY2xvc2UoKTtcbiAgICAgIH1cbiAgICB9LFxuICB9LCBzdHJhdGVneSk7XG59XG5cbi8qKiBEZXRlcm1pbmVzIGlmIGEgSFRUUCBgU3RhdHVzYCBpcyBhbiBgRXJyb3JTdGF0dXNgICg0WFggb3IgNVhYKS4gKi9cbmV4cG9ydCBmdW5jdGlvbiBpc0Vycm9yU3RhdHVzKHZhbHVlOiBTdGF0dXMpOiB2YWx1ZSBpcyBFcnJvclN0YXR1cyB7XG4gIHJldHVybiBbXG4gICAgU3RhdHVzLkJhZFJlcXVlc3QsXG4gICAgU3RhdHVzLlVuYXV0aG9yaXplZCxcbiAgICBTdGF0dXMuUGF5bWVudFJlcXVpcmVkLFxuICAgIFN0YXR1cy5Gb3JiaWRkZW4sXG4gICAgU3RhdHVzLk5vdEZvdW5kLFxuICAgIFN0YXR1cy5NZXRob2ROb3RBbGxvd2VkLFxuICAgIFN0YXR1cy5Ob3RBY2NlcHRhYmxlLFxuICAgIFN0YXR1cy5Qcm94eUF1dGhSZXF1aXJlZCxcbiAgICBTdGF0dXMuUmVxdWVzdFRpbWVvdXQsXG4gICAgU3RhdHVzLkNvbmZsaWN0LFxuICAgIFN0YXR1cy5Hb25lLFxuICAgIFN0YXR1cy5MZW5ndGhSZXF1aXJlZCxcbiAgICBTdGF0dXMuUHJlY29uZGl0aW9uRmFpbGVkLFxuICAgIFN0YXR1cy5SZXF1ZXN0RW50aXR5VG9vTGFyZ2UsXG4gICAgU3RhdHVzLlJlcXVlc3RVUklUb29Mb25nLFxuICAgIFN0YXR1cy5VbnN1cHBvcnRlZE1lZGlhVHlwZSxcbiAgICBTdGF0dXMuUmVxdWVzdGVkUmFuZ2VOb3RTYXRpc2ZpYWJsZSxcbiAgICBTdGF0dXMuRXhwZWN0YXRpb25GYWlsZWQsXG4gICAgU3RhdHVzLlRlYXBvdCxcbiAgICBTdGF0dXMuTWlzZGlyZWN0ZWRSZXF1ZXN0LFxuICAgIFN0YXR1cy5VbnByb2Nlc3NhYmxlRW50aXR5LFxuICAgIFN0YXR1cy5Mb2NrZWQsXG4gICAgU3RhdHVzLkZhaWxlZERlcGVuZGVuY3ksXG4gICAgU3RhdHVzLlVwZ3JhZGVSZXF1aXJlZCxcbiAgICBTdGF0dXMuUHJlY29uZGl0aW9uUmVxdWlyZWQsXG4gICAgU3RhdHVzLlRvb01hbnlSZXF1ZXN0cyxcbiAgICBTdGF0dXMuUmVxdWVzdEhlYWRlckZpZWxkc1Rvb0xhcmdlLFxuICAgIFN0YXR1cy5VbmF2YWlsYWJsZUZvckxlZ2FsUmVhc29ucyxcbiAgICBTdGF0dXMuSW50ZXJuYWxTZXJ2ZXJFcnJvcixcbiAgICBTdGF0dXMuTm90SW1wbGVtZW50ZWQsXG4gICAgU3RhdHVzLkJhZEdhdGV3YXksXG4gICAgU3RhdHVzLlNlcnZpY2VVbmF2YWlsYWJsZSxcbiAgICBTdGF0dXMuR2F0ZXdheVRpbWVvdXQsXG4gICAgU3RhdHVzLkhUVFBWZXJzaW9uTm90U3VwcG9ydGVkLFxuICAgIFN0YXR1cy5WYXJpYW50QWxzb05lZ290aWF0ZXMsXG4gICAgU3RhdHVzLkluc3VmZmljaWVudFN0b3JhZ2UsXG4gICAgU3RhdHVzLkxvb3BEZXRlY3RlZCxcbiAgICBTdGF0dXMuTm90RXh0ZW5kZWQsXG4gICAgU3RhdHVzLk5ldHdvcmtBdXRoZW50aWNhdGlvblJlcXVpcmVkLFxuICBdLmluY2x1ZGVzKHZhbHVlKTtcbn1cblxuLyoqIERldGVybWluZXMgaWYgYSBIVFRQIGBTdGF0dXNgIGlzIGEgYFJlZGlyZWN0U3RhdHVzYCAoM1hYKS4gKi9cbmV4cG9ydCBmdW5jdGlvbiBpc1JlZGlyZWN0U3RhdHVzKHZhbHVlOiBTdGF0dXMpOiB2YWx1ZSBpcyBSZWRpcmVjdFN0YXR1cyB7XG4gIHJldHVybiBbXG4gICAgU3RhdHVzLk11bHRpcGxlQ2hvaWNlcyxcbiAgICBTdGF0dXMuTW92ZWRQZXJtYW5lbnRseSxcbiAgICBTdGF0dXMuRm91bmQsXG4gICAgU3RhdHVzLlNlZU90aGVyLFxuICAgIFN0YXR1cy5Vc2VQcm94eSxcbiAgICBTdGF0dXMuVGVtcG9yYXJ5UmVkaXJlY3QsXG4gICAgU3RhdHVzLlBlcm1hbmVudFJlZGlyZWN0LFxuICBdLmluY2x1ZGVzKHZhbHVlKTtcbn1cblxuLyoqIERldGVybWluZXMgaWYgYSBzdHJpbmcgXCJsb29rc1wiIGxpa2UgSFRNTCAqL1xuZXhwb3J0IGZ1bmN0aW9uIGlzSHRtbCh2YWx1ZTogc3RyaW5nKTogYm9vbGVhbiB7XG4gIHJldHVybiAvXlxccyo8KD86IURPQ1RZUEV8aHRtbHxib2R5KS9pLnRlc3QodmFsdWUpO1xufVxuXG4vKiogUmV0dXJucyBgdThgIHdpdGggbGVhZGluZyB3aGl0ZSBzcGFjZSByZW1vdmVkLiAqL1xuZXhwb3J0IGZ1bmN0aW9uIHNraXBMV1NQQ2hhcih1ODogVWludDhBcnJheSk6IFVpbnQ4QXJyYXkge1xuICBjb25zdCByZXN1bHQgPSBuZXcgVWludDhBcnJheSh1OC5sZW5ndGgpO1xuICBsZXQgaiA9IDA7XG4gIGZvciAobGV0IGkgPSAwOyBpIDwgdTgubGVuZ3RoOyBpKyspIHtcbiAgICBpZiAodThbaV0gPT09IFNQQUNFIHx8IHU4W2ldID09PSBIVEFCKSBjb250aW51ZTtcbiAgICByZXN1bHRbaisrXSA9IHU4W2ldO1xuICB9XG4gIHJldHVybiByZXN1bHQuc2xpY2UoMCwgaik7XG59XG5cbmV4cG9ydCBmdW5jdGlvbiBzdHJpcEVvbCh2YWx1ZTogVWludDhBcnJheSk6IFVpbnQ4QXJyYXkge1xuICBpZiAodmFsdWVbdmFsdWUuYnl0ZUxlbmd0aCAtIDFdID09IExGKSB7XG4gICAgbGV0IGRyb3AgPSAxO1xuICAgIGlmICh2YWx1ZS5ieXRlTGVuZ3RoID4gMSAmJiB2YWx1ZVt2YWx1ZS5ieXRlTGVuZ3RoIC0gMl0gPT09IENSKSB7XG4gICAgICBkcm9wID0gMjtcbiAgICB9XG4gICAgcmV0dXJuIHZhbHVlLnN1YmFycmF5KDAsIHZhbHVlLmJ5dGVMZW5ndGggLSBkcm9wKTtcbiAgfVxuICByZXR1cm4gdmFsdWU7XG59XG5cbi8qIVxuICogQWRhcHRlZCBkaXJlY3RseSBmcm9tIGh0dHBzOi8vZ2l0aHViLmNvbS9waWxsYXJqcy9yZXNvbHZlLXBhdGhcbiAqIHdoaWNoIGlzIGxpY2Vuc2VkIGFzIGZvbGxvd3M6XG4gKlxuICogVGhlIE1JVCBMaWNlbnNlIChNSVQpXG4gKlxuICogQ29weXJpZ2h0IChjKSAyMDE0IEpvbmF0aGFuIE9uZyA8bWVAam9uZ2xlYmVycnkuY29tPlxuICogQ29weXJpZ2h0IChjKSAyMDE1LTIwMTggRG91Z2xhcyBDaHJpc3RvcGhlciBXaWxzb24gPGRvdWdAc29tZXRoaW5nZG91Zy5jb20+XG4gKlxuICogUGVybWlzc2lvbiBpcyBoZXJlYnkgZ3JhbnRlZCwgZnJlZSBvZiBjaGFyZ2UsIHRvIGFueSBwZXJzb24gb2J0YWluaW5nXG4gKiBhIGNvcHkgb2YgdGhpcyBzb2Z0d2FyZSBhbmQgYXNzb2NpYXRlZCBkb2N1bWVudGF0aW9uIGZpbGVzICh0aGVcbiAqICdTb2Z0d2FyZScpLCB0byBkZWFsIGluIHRoZSBTb2Z0d2FyZSB3aXRob3V0IHJlc3RyaWN0aW9uLCBpbmNsdWRpbmdcbiAqIHdpdGhvdXQgbGltaXRhdGlvbiB0aGUgcmlnaHRzIHRvIHVzZSwgY29weSwgbW9kaWZ5LCBtZXJnZSwgcHVibGlzaCxcbiAqIGRpc3RyaWJ1dGUsIHN1YmxpY2Vuc2UsIGFuZC9vciBzZWxsIGNvcGllcyBvZiB0aGUgU29mdHdhcmUsIGFuZCB0b1xuICogcGVybWl0IHBlcnNvbnMgdG8gd2hvbSB0aGUgU29mdHdhcmUgaXMgZnVybmlzaGVkIHRvIGRvIHNvLCBzdWJqZWN0IHRvXG4gKiB0aGUgZm9sbG93aW5nIGNvbmRpdGlvbnM6XG4gKlxuICogVGhlIGFib3ZlIGNvcHlyaWdodCBub3RpY2UgYW5kIHRoaXMgcGVybWlzc2lvbiBub3RpY2Ugc2hhbGwgYmVcbiAqIGluY2x1ZGVkIGluIGFsbCBjb3BpZXMgb3Igc3Vic3RhbnRpYWwgcG9ydGlvbnMgb2YgdGhlIFNvZnR3YXJlLlxuICpcbiAqIFRIRSBTT0ZUV0FSRSBJUyBQUk9WSURFRCAnQVMgSVMnLCBXSVRIT1VUIFdBUlJBTlRZIE9GIEFOWSBLSU5ELFxuICogRVhQUkVTUyBPUiBJTVBMSUVELCBJTkNMVURJTkcgQlVUIE5PVCBMSU1JVEVEIFRPIFRIRSBXQVJSQU5USUVTIE9GXG4gKiBNRVJDSEFOVEFCSUxJVFksIEZJVE5FU1MgRk9SIEEgUEFSVElDVUxBUiBQVVJQT1NFIEFORCBOT05JTkZSSU5HRU1FTlQuXG4gKiBJTiBOTyBFVkVOVCBTSEFMTCBUSEUgQVVUSE9SUyBPUiBDT1BZUklHSFQgSE9MREVSUyBCRSBMSUFCTEUgRk9SIEFOWVxuICogQ0xBSU0sIERBTUFHRVMgT1IgT1RIRVIgTElBQklMSVRZLCBXSEVUSEVSIElOIEFOIEFDVElPTiBPRiBDT05UUkFDVCxcbiAqIFRPUlQgT1IgT1RIRVJXSVNFLCBBUklTSU5HIEZST00sIE9VVCBPRiBPUiBJTiBDT05ORUNUSU9OIFdJVEggVEhFXG4gKiBTT0ZUV0FSRSBPUiBUSEUgVVNFIE9SIE9USEVSIERFQUxJTkdTIElOIFRIRSBTT0ZUV0FSRS5cbiAqL1xuXG5jb25zdCBVUF9QQVRIX1JFR0VYUCA9IC8oPzpefFtcXFxcL10pXFwuXFwuKD86W1xcXFwvXXwkKS87XG5cbmV4cG9ydCBmdW5jdGlvbiByZXNvbHZlUGF0aChyZWxhdGl2ZVBhdGg6IHN0cmluZyk6IHN0cmluZztcbmV4cG9ydCBmdW5jdGlvbiByZXNvbHZlUGF0aChyb290UGF0aDogc3RyaW5nLCByZWxhdGl2ZVBhdGg6IHN0cmluZyk6IHN0cmluZztcbmV4cG9ydCBmdW5jdGlvbiByZXNvbHZlUGF0aChyb290UGF0aDogc3RyaW5nLCByZWxhdGl2ZVBhdGg/OiBzdHJpbmcpOiBzdHJpbmcge1xuICBsZXQgcGF0aCA9IHJlbGF0aXZlUGF0aDtcbiAgbGV0IHJvb3QgPSByb290UGF0aDtcblxuICAvLyByb290IGlzIG9wdGlvbmFsLCBzaW1pbGFyIHRvIHJvb3QucmVzb2x2ZVxuICBpZiAocmVsYXRpdmVQYXRoID09PSB1bmRlZmluZWQpIHtcbiAgICBwYXRoID0gcm9vdFBhdGg7XG4gICAgcm9vdCA9IFwiLlwiO1xuICB9XG5cbiAgaWYgKHBhdGggPT0gbnVsbCkge1xuICAgIHRocm93IG5ldyBUeXBlRXJyb3IoXCJBcmd1bWVudCByZWxhdGl2ZVBhdGggaXMgcmVxdWlyZWQuXCIpO1xuICB9XG5cbiAgLy8gY29udGFpbmluZyBOVUxMIGJ5dGVzIGlzIG1hbGljaW91c1xuICBpZiAocGF0aC5pbmNsdWRlcyhcIlxcMFwiKSkge1xuICAgIHRocm93IGNyZWF0ZUh0dHBFcnJvcig0MDAsIFwiTWFsaWNpb3VzIFBhdGhcIik7XG4gIH1cblxuICAvLyBwYXRoIHNob3VsZCBuZXZlciBiZSBhYnNvbHV0ZVxuICBpZiAoaXNBYnNvbHV0ZShwYXRoKSkge1xuICAgIHRocm93IGNyZWF0ZUh0dHBFcnJvcig0MDAsIFwiTWFsaWNpb3VzIFBhdGhcIik7XG4gIH1cblxuICAvLyBwYXRoIG91dHNpZGUgcm9vdFxuICBpZiAoVVBfUEFUSF9SRUdFWFAudGVzdChub3JtYWxpemUoXCIuXCIgKyBzZXAgKyBwYXRoKSkpIHtcbiAgICB0aHJvdyBjcmVhdGVIdHRwRXJyb3IoNDAzKTtcbiAgfVxuXG4gIC8vIGpvaW4gdGhlIHJlbGF0aXZlIHBhdGhcbiAgcmV0dXJuIG5vcm1hbGl6ZShqb2luKHJvb3QsIHBhdGgpKTtcbn1cblxuLyoqIEEgdXRpbGl0eSBjbGFzcyB0aGF0IHRyYW5zZm9ybXMgXCJhbnlcIiBjaHVuayBpbnRvIGFuIGBVaW50OEFycmF5YC4gKi9cbmV4cG9ydCBjbGFzcyBVaW50OEFycmF5VHJhbnNmb3JtU3RyZWFtXG4gIGV4dGVuZHMgVHJhbnNmb3JtU3RyZWFtPHVua25vd24sIFVpbnQ4QXJyYXk+IHtcbiAgY29uc3RydWN0b3IoKSB7XG4gICAgY29uc3QgaW5pdCA9IHtcbiAgICAgIGFzeW5jIHRyYW5zZm9ybShcbiAgICAgICAgY2h1bms6IHVua25vd24sXG4gICAgICAgIGNvbnRyb2xsZXI6IFRyYW5zZm9ybVN0cmVhbURlZmF1bHRDb250cm9sbGVyPFVpbnQ4QXJyYXk+LFxuICAgICAgKSB7XG4gICAgICAgIGNodW5rID0gYXdhaXQgY2h1bms7XG4gICAgICAgIHN3aXRjaCAodHlwZW9mIGNodW5rKSB7XG4gICAgICAgICAgY2FzZSBcIm9iamVjdFwiOlxuICAgICAgICAgICAgaWYgKGNodW5rID09PSBudWxsKSB7XG4gICAgICAgICAgICAgIGNvbnRyb2xsZXIudGVybWluYXRlKCk7XG4gICAgICAgICAgICB9IGVsc2UgaWYgKEFycmF5QnVmZmVyLmlzVmlldyhjaHVuaykpIHtcbiAgICAgICAgICAgICAgY29udHJvbGxlci5lbnF1ZXVlKFxuICAgICAgICAgICAgICAgIG5ldyBVaW50OEFycmF5KFxuICAgICAgICAgICAgICAgICAgY2h1bmsuYnVmZmVyLFxuICAgICAgICAgICAgICAgICAgY2h1bmsuYnl0ZU9mZnNldCxcbiAgICAgICAgICAgICAgICAgIGNodW5rLmJ5dGVMZW5ndGgsXG4gICAgICAgICAgICAgICAgKSxcbiAgICAgICAgICAgICAgKTtcbiAgICAgICAgICAgIH0gZWxzZSBpZiAoXG4gICAgICAgICAgICAgIEFycmF5LmlzQXJyYXkoY2h1bmspICYmXG4gICAgICAgICAgICAgIGNodW5rLmV2ZXJ5KCh2YWx1ZSkgPT4gdHlwZW9mIHZhbHVlID09PSBcIm51bWJlclwiKVxuICAgICAgICAgICAgKSB7XG4gICAgICAgICAgICAgIGNvbnRyb2xsZXIuZW5xdWV1ZShuZXcgVWludDhBcnJheShjaHVuaykpO1xuICAgICAgICAgICAgfSBlbHNlIGlmIChcbiAgICAgICAgICAgICAgdHlwZW9mIGNodW5rLnZhbHVlT2YgPT09IFwiZnVuY3Rpb25cIiAmJiBjaHVuay52YWx1ZU9mKCkgIT09IGNodW5rXG4gICAgICAgICAgICApIHtcbiAgICAgICAgICAgICAgdGhpcy50cmFuc2Zvcm0oY2h1bmsudmFsdWVPZigpLCBjb250cm9sbGVyKTtcbiAgICAgICAgICAgIH0gZWxzZSBpZiAoXCJ0b0pTT05cIiBpbiBjaHVuaykge1xuICAgICAgICAgICAgICB0aGlzLnRyYW5zZm9ybShKU09OLnN0cmluZ2lmeShjaHVuayksIGNvbnRyb2xsZXIpO1xuICAgICAgICAgICAgfVxuICAgICAgICAgICAgYnJlYWs7XG4gICAgICAgICAgY2FzZSBcInN5bWJvbFwiOlxuICAgICAgICAgICAgY29udHJvbGxlci5lcnJvcihcbiAgICAgICAgICAgICAgbmV3IFR5cGVFcnJvcihcIkNhbm5vdCB0cmFuc2Zvcm0gYSBzeW1ib2wgdG8gYSBVaW50OEFycmF5XCIpLFxuICAgICAgICAgICAgKTtcbiAgICAgICAgICAgIGJyZWFrO1xuICAgICAgICAgIGNhc2UgXCJ1bmRlZmluZWRcIjpcbiAgICAgICAgICAgIGNvbnRyb2xsZXIuZXJyb3IoXG4gICAgICAgICAgICAgIG5ldyBUeXBlRXJyb3IoXCJDYW5ub3QgdHJhbnNmb3JtIHVuZGVmaW5lZCB0byBhIFVpbnQ4QXJyYXlcIiksXG4gICAgICAgICAgICApO1xuICAgICAgICAgICAgYnJlYWs7XG4gICAgICAgICAgZGVmYXVsdDpcbiAgICAgICAgICAgIGNvbnRyb2xsZXIuZW5xdWV1ZSh0aGlzLmVuY29kZXIuZW5jb2RlKFN0cmluZyhjaHVuaykpKTtcbiAgICAgICAgfVxuICAgICAgfSxcbiAgICAgIGVuY29kZXI6IG5ldyBUZXh0RW5jb2RlcigpLFxuICAgIH07XG4gICAgc3VwZXIoaW5pdCk7XG4gIH1cbn1cblxuY29uc3QgcmVwbGFjZW1lbnRzOiBSZWNvcmQ8c3RyaW5nLCBzdHJpbmc+ID0ge1xuICBcIi9cIjogXCJfXCIsXG4gIFwiK1wiOiBcIi1cIixcbiAgXCI9XCI6IFwiXCIsXG59O1xuXG5jb25zdCBlbmNvZGVyID0gbmV3IFRleHRFbmNvZGVyKCk7XG5cbmV4cG9ydCBmdW5jdGlvbiBlbmNvZGVCYXNlNjRTYWZlKGRhdGE6IHN0cmluZyB8IEFycmF5QnVmZmVyKTogc3RyaW5nIHtcbiAgcmV0dXJuIGJhc2U2NC5lbmNvZGUoZGF0YSkucmVwbGFjZSgvXFwvfFxcK3w9L2csIChjKSA9PiByZXBsYWNlbWVudHNbY10pO1xufVxuXG5leHBvcnQgZnVuY3Rpb24gaXNOb2RlKCk6IGJvb2xlYW4ge1xuICByZXR1cm4gXCJwcm9jZXNzXCIgaW4gZ2xvYmFsVGhpcyAmJiBcImdsb2JhbFwiIGluIGdsb2JhbFRoaXM7XG59XG5cbmV4cG9ydCBmdW5jdGlvbiBpbXBvcnRLZXkoa2V5OiBLZXkpOiBQcm9taXNlPENyeXB0b0tleT4ge1xuICBpZiAodHlwZW9mIGtleSA9PT0gXCJzdHJpbmdcIikge1xuICAgIGtleSA9IGVuY29kZXIuZW5jb2RlKGtleSk7XG4gIH0gZWxzZSBpZiAoQXJyYXkuaXNBcnJheShrZXkpKSB7XG4gICAga2V5ID0gbmV3IFVpbnQ4QXJyYXkoa2V5KTtcbiAgfVxuICByZXR1cm4gY3J5cHRvLnN1YnRsZS5pbXBvcnRLZXkoXG4gICAgXCJyYXdcIixcbiAgICBrZXksXG4gICAge1xuICAgICAgbmFtZTogXCJITUFDXCIsXG4gICAgICBoYXNoOiB7IG5hbWU6IFwiU0hBLTI1NlwiIH0sXG4gICAgfSxcbiAgICB0cnVlLFxuICAgIFtcInNpZ25cIiwgXCJ2ZXJpZnlcIl0sXG4gICk7XG59XG5cbmV4cG9ydCBmdW5jdGlvbiBzaWduKGRhdGE6IERhdGEsIGtleTogQ3J5cHRvS2V5KTogUHJvbWlzZTxBcnJheUJ1ZmZlcj4ge1xuICBpZiAodHlwZW9mIGRhdGEgPT09IFwic3RyaW5nXCIpIHtcbiAgICBkYXRhID0gZW5jb2Rlci5lbmNvZGUoZGF0YSk7XG4gIH0gZWxzZSBpZiAoQXJyYXkuaXNBcnJheShkYXRhKSkge1xuICAgIGRhdGEgPSBVaW50OEFycmF5LmZyb20oZGF0YSk7XG4gIH1cbiAgcmV0dXJuIGNyeXB0by5zdWJ0bGUuc2lnbihcIkhNQUNcIiwga2V5LCBkYXRhKTtcbn1cbiJdLCJuYW1lcyI6W10sIm1hcHBpbmdzIjoiQUFJQSxTQUFTLE1BQU0sRUFBRSxVQUFVLEVBQUUsSUFBSSxFQUFFLFNBQVMsRUFBRSxHQUFHLEVBQUUsTUFBTSxRQUFRLFdBQVcsQ0FBQztBQUM3RSxTQUFTLGVBQWUsUUFBUSxnQkFBZ0IsQ0FBQztBQUlqRCxNQUFNLG1CQUFtQiw2R0FDbUYsQUFBQztBQUM3RyxNQUFNLElBQUksR0FBRyxJQUFJLENBQUMsVUFBVSxDQUFDLENBQUMsQ0FBQyxBQUFDO0FBQ2hDLE1BQU0sS0FBSyxHQUFHLEdBQUcsQ0FBQyxVQUFVLENBQUMsQ0FBQyxDQUFDLEFBQUM7QUFDaEMsTUFBTSxFQUFFLEdBQUcsSUFBSSxDQUFDLFVBQVUsQ0FBQyxDQUFDLENBQUMsQUFBQztBQUM5QixNQUFNLEVBQUUsR0FBRyxJQUFJLENBQUMsVUFBVSxDQUFDLENBQUMsQ0FBQyxBQUFDO0FBQzlCLE1BQU0sK0JBQStCLDZFQUN1QyxBQUFDO0FBQzdFLE1BQU0sZ0NBQWdDLEdBQUcsWUFBWSxBQUFDO0FBQ3RELE9BQU8sTUFBTSxrQkFBa0IsR0FBRyxNQUFNLENBQUMsQ0FBQyxTQUFTO0FBRW5ELHVFQUF1RSxDQUN2RSxPQUFPLE1BQU0sVUFBVSxHQUFHO0lBQUMsUUFBUTtJQUFFLFFBQVE7SUFBRSxRQUFRO0lBQUUsU0FBUztJQUFFLFFBQVE7Q0FBQyxDQUFDO0FBRTlFLE9BQU8sU0FBUyxNQUFNLENBQUMsSUFBYSxFQUFFLEdBQUcsR0FBRyxrQkFBa0IsRUFBZ0I7SUFDNUUsSUFBSSxDQUFDLElBQUksRUFBRTtRQUNULE1BQU0sSUFBSSxLQUFLLENBQUMsR0FBRyxDQUFDLENBQUM7S0FDdEI7Q0FDRjtBQUVEOztHQUVHLENBQ0gsT0FBTyxTQUFTLGVBQWUsQ0FBQyxJQUFZLEVBQUU7SUFDNUMsSUFBSTtRQUNGLE9BQU8sa0JBQWtCLENBQUMsSUFBSSxDQUFDLENBQUM7S0FDakMsQ0FBQyxPQUFNO1FBQ04sT0FBTyxJQUFJLENBQUM7S0FDYjtDQUNGO0FBRUQsa0RBQWtELENBQ2xELE9BQU8sU0FBUyxTQUFTLENBQUMsR0FBVyxFQUFFO0lBQ3JDLE9BQU8sTUFBTSxDQUFDLEdBQUcsQ0FBQyxDQUNmLE9BQU8sQ0FBQywrQkFBK0IsRUFBRSxnQ0FBZ0MsQ0FBQyxDQUMxRSxPQUFPLENBQUMsbUJBQW1CLEVBQUUsU0FBUyxDQUFDLENBQUM7Q0FDNUM7QUFFRCxTQUFTLFdBQVcsQ0FBQyxNQUFtQixFQUFVO0lBQ2hELE1BQU0sR0FBRyxHQUFHLEtBQUssQ0FBQyxJQUFJLENBQUMsSUFBSSxVQUFVLENBQUMsTUFBTSxDQUFDLENBQUMsQUFBQztJQUMvQyxPQUFPLEdBQUcsQ0FBQyxHQUFHLENBQUMsQ0FBQyxDQUFDLEdBQUssQ0FBQyxDQUFDLFFBQVEsQ0FBQyxFQUFFLENBQUMsQ0FBQyxRQUFRLENBQUMsQ0FBQyxFQUFFLEdBQUcsQ0FBQyxDQUFDLENBQUMsSUFBSSxDQUFDLEVBQUUsQ0FBQyxDQUFDO0NBQ2pFO0FBRUQsT0FBTyxlQUFlLGlCQUFpQixDQUNyQyxNQUFNLEdBQUcsRUFBRSxFQUNYLFNBQVMsR0FBRyxFQUFFLEVBQ0c7SUFDakIsTUFBTSxNQUFNLEdBQUcsTUFBTSxNQUFNLENBQUMsTUFBTSxDQUFDLE1BQU0sQ0FDdkMsT0FBTyxFQUNQLE1BQU0sQ0FBQyxlQUFlLENBQUMsSUFBSSxVQUFVLENBQUMsR0FBRyxDQUFDLENBQUMsQ0FDNUMsQUFBQztJQUNGLE9BQU8sQ0FBQyxFQUFFLE1BQU0sQ0FBQyxFQUFFLFdBQVcsQ0FBQyxNQUFNLENBQUMsQ0FBQyxFQUFFLFNBQVMsR0FBRyxDQUFDLENBQUMsRUFBRSxTQUFTLENBQUMsQ0FBQyxHQUFHLEVBQUUsQ0FBQyxDQUFDLENBQUM7Q0FDN0U7QUFFRCxPQUFPLGVBQWUsV0FBVyxHQUFvQjtJQUNuRCxNQUFNLE1BQU0sR0FBRyxNQUFNLE1BQU0sQ0FBQyxNQUFNLENBQUMsTUFBTSxDQUN2QyxPQUFPLEVBQ1AsTUFBTSxDQUFDLGVBQWUsQ0FBQyxJQUFJLFVBQVUsQ0FBQyxHQUFHLENBQUMsQ0FBQyxDQUM1QyxBQUFDO0lBQ0YsT0FBTyxDQUFDLElBQUksRUFBRSxXQUFXLENBQUMsTUFBTSxDQUFDLENBQUMsQ0FBQyxDQUFDO0NBQ3JDO0FBRUQsZ0NBQWdDLENBQ2hDLE9BQU8sU0FBUyxlQUFlLENBQzdCLEtBQWMsRUFDbUI7SUFDakMsT0FBTyxPQUFPLEtBQUssS0FBSyxRQUFRLElBQUksS0FBSyxLQUFLLElBQUksSUFDaEQsTUFBTSxDQUFDLGFBQWEsSUFBSSxLQUFLLElBQzdCLG1DQUFtQztJQUNuQyxPQUFPLEFBQUMsS0FBSyxBQUFRLENBQUMsTUFBTSxDQUFDLGFBQWEsQ0FBQyxLQUFLLFVBQVUsQ0FBQztDQUM5RDtBQUVELE9BQU8sU0FBUyxlQUFlLENBSzdCLEtBQWlCLEVBQ2dCO0lBQ2pDLE9BQU8sUUFBUSxJQUFJLEtBQUssQ0FBQztDQUMxQjtBQUVELCtCQUErQixDQUMvQixPQUFPLFNBQVMsUUFBUSxDQUFDLEtBQWMsRUFBd0I7SUFDN0QsT0FBTyxPQUFPLEtBQUssS0FBSyxRQUFRLElBQUksS0FBSyxLQUFLLElBQUksSUFBSSxNQUFNLElBQUksS0FBSyxJQUNuRSxPQUFPLEFBQUMsS0FBSyxDQUE2QixJQUFJLEtBQUssVUFBVSxDQUFDO0NBQ2pFO0FBRUQsU0FBUyxRQUFRLENBQUMsS0FBYyxFQUF3QjtJQUN0RCxPQUFPLE9BQU8sS0FBSyxLQUFLLFFBQVEsSUFBSSxLQUFLLElBQUksSUFBSSxJQUFJLE9BQU8sSUFBSSxLQUFLLElBQ25FLG1DQUFtQztJQUNuQyxPQUFPLEFBQUMsS0FBSyxBQUF3QixDQUFDLE9BQU8sQ0FBQyxLQUFLLFVBQVUsQ0FBQztDQUNqRTtBQUVELE9BQU8sU0FBUyxNQUFNLENBQUMsS0FBYyxFQUFzQjtJQUN6RCxPQUFPLE9BQU8sS0FBSyxLQUFLLFFBQVEsSUFBSSxLQUFLLElBQUksSUFBSSxJQUFJLEtBQUssSUFBSSxLQUFLLElBQ2pFLG1DQUFtQztJQUNuQyxPQUFPLEFBQUMsS0FBSyxDQUFTLEdBQUcsS0FBSyxRQUFRLElBQUksV0FBVyxJQUFJLEtBQUssSUFDOUQsWUFBWSxJQUFJLEtBQUssQ0FBQztDQUN6QjtBQUVELE9BQU8sU0FBUyxrQkFBa0IsQ0FDaEMsS0FBYyxFQUNrQjtJQUNoQyxPQUFPLE9BQU8sS0FBSyxLQUFLLFFBQVEsSUFBSSxLQUFLLEtBQUssSUFBSSxJQUNoRCxDQUFDLE1BQU0sSUFBSSxLQUFLLElBQUksVUFBVSxJQUFJLEtBQUssQ0FBQyxJQUN4QyxDQUFDLEtBQUssSUFBSSxLQUFLLElBQUksU0FBUyxJQUFJLEtBQUssQ0FBQyxJQUFJLE1BQU0sSUFBSSxLQUFLLENBQUM7Q0FDN0Q7QUFpQkQ7O0dBRUcsQ0FDSCxPQUFPLFNBQVMsK0JBQStCLENBQzdDLE1BQThCLEVBQ0Y7SUFDNUIsT0FBTyxJQUFJLGNBQWMsQ0FBQztRQUN4QixNQUFNLEtBQUssRUFBQyxVQUFVLEVBQUU7WUFDdEIsV0FBVyxNQUFNLEtBQUssSUFBSSxNQUFNLENBQUU7Z0JBQ2hDLElBQUksVUFBVSxDQUFDLFFBQVEsQ0FBQyxPQUFPLEtBQUssQ0FBQyxFQUFFO29CQUNyQyxVQUFVLENBQUMsT0FBTyxDQUFDLE9BQU8sQ0FBQyxNQUFNLENBQUMsTUFBTSxDQUFDLEtBQUssQ0FBQyxDQUFDLENBQUMsQ0FBQztpQkFDbkQsTUFBTSxJQUFJLEtBQUssWUFBWSxVQUFVLEVBQUU7b0JBQ3RDLFVBQVUsQ0FBQyxPQUFPLENBQUMsS0FBSyxDQUFDLENBQUM7aUJBQzNCLE1BQU0sSUFBSSxXQUFXLENBQUMsTUFBTSxDQUFDLEtBQUssQ0FBQyxFQUFFO29CQUNwQyxVQUFVLENBQUMsT0FBTyxDQUFDLElBQUksVUFBVSxDQUFDLEtBQUssQ0FBQyxNQUFNLENBQUMsQ0FBQyxDQUFDO2lCQUNsRCxNQUFNLElBQUksS0FBSyxZQUFZLFdBQVcsRUFBRTtvQkFDdkMsVUFBVSxDQUFDLE9BQU8sQ0FBQyxJQUFJLFVBQVUsQ0FBQyxLQUFLLENBQUMsQ0FBQyxDQUFDO2lCQUMzQyxNQUFNO29CQUNMLElBQUk7d0JBQ0YsVUFBVSxDQUFDLE9BQU8sQ0FBQyxPQUFPLENBQUMsTUFBTSxDQUFDLElBQUksQ0FBQyxTQUFTLENBQUMsS0FBSyxDQUFDLENBQUMsQ0FBQyxDQUFDO3FCQUMzRCxDQUFDLE9BQU07b0JBQ04sOEJBQThCO3FCQUMvQjtpQkFDRjthQUNGO1lBQ0QsVUFBVSxDQUFDLEtBQUssRUFBRSxDQUFDO1NBQ3BCO0tBQ0YsQ0FBQyxDQUFDO0NBQ0o7QUFFRDs7Ozs7Ozs7Ozs7Ozs7O0dBZUcsQ0FDSCxPQUFPLFNBQVMsd0JBQXdCLENBQ3RDLE1BQWlELEVBQ2pELE9BQXdDLEdBQUcsRUFBRSxFQUNqQjtJQUM1QixNQUFNLEVBQ0osU0FBUyxFQUFHLElBQUksQ0FBQSxFQUNoQixTQUFTLEVBQUcsa0JBQWtCLENBQUEsRUFDOUIsUUFBUSxDQUFBLElBQ1QsR0FBRyxPQUFPLEFBQUM7SUFFWixPQUFPLElBQUksY0FBYyxDQUFDO1FBQ3hCLE1BQU0sSUFBSSxFQUFDLFVBQVUsRUFBRTtZQUNyQixNQUFNLEtBQUssR0FBRyxJQUFJLFVBQVUsQ0FBQyxTQUFTLENBQUMsQUFBQztZQUN4QyxJQUFJO2dCQUNGLE1BQU0sSUFBSSxHQUFHLE1BQU0sTUFBTSxDQUFDLElBQUksQ0FBQyxLQUFLLENBQUMsQUFBQztnQkFDdEMsSUFBSSxJQUFJLEtBQUssSUFBSSxFQUFFO29CQUNqQixJQUFJLFFBQVEsQ0FBQyxNQUFNLENBQUMsSUFBSSxTQUFTLEVBQUU7d0JBQ2pDLE1BQU0sQ0FBQyxLQUFLLEVBQUUsQ0FBQztxQkFDaEI7b0JBQ0QsVUFBVSxDQUFDLEtBQUssRUFBRSxDQUFDO29CQUNuQixPQUFPO2lCQUNSO2dCQUNELFVBQVUsQ0FBQyxPQUFPLENBQUMsS0FBSyxDQUFDLFFBQVEsQ0FBQyxDQUFDLEVBQUUsSUFBSSxDQUFDLENBQUMsQ0FBQzthQUM3QyxDQUFDLE9BQU8sQ0FBQyxFQUFFO2dCQUNWLFVBQVUsQ0FBQyxLQUFLLENBQUMsQ0FBQyxDQUFDLENBQUM7Z0JBQ3BCLElBQUksUUFBUSxDQUFDLE1BQU0sQ0FBQyxFQUFFO29CQUNwQixNQUFNLENBQUMsS0FBSyxFQUFFLENBQUM7aUJBQ2hCO2FBQ0Y7U0FDRjtRQUNELE1BQU0sSUFBRztZQUNQLElBQUksUUFBUSxDQUFDLE1BQU0sQ0FBQyxJQUFJLFNBQVMsRUFBRTtnQkFDakMsTUFBTSxDQUFDLEtBQUssRUFBRSxDQUFDO2FBQ2hCO1NBQ0Y7S0FDRixFQUFFLFFBQVEsQ0FBQyxDQUFDO0NBQ2Q7QUFFRCxzRUFBc0UsQ0FDdEUsT0FBTyxTQUFTLGFBQWEsQ0FBQyxLQUFhLEVBQXdCO0lBQ2pFLE9BQU87UUFDTCxNQUFNLENBQUMsVUFBVTtRQUNqQixNQUFNLENBQUMsWUFBWTtRQUNuQixNQUFNLENBQUMsZUFBZTtRQUN0QixNQUFNLENBQUMsU0FBUztRQUNoQixNQUFNLENBQUMsUUFBUTtRQUNmLE1BQU0sQ0FBQyxnQkFBZ0I7UUFDdkIsTUFBTSxDQUFDLGFBQWE7UUFDcEIsTUFBTSxDQUFDLGlCQUFpQjtRQUN4QixNQUFNLENBQUMsY0FBYztRQUNyQixNQUFNLENBQUMsUUFBUTtRQUNmLE1BQU0sQ0FBQyxJQUFJO1FBQ1gsTUFBTSxDQUFDLGNBQWM7UUFDckIsTUFBTSxDQUFDLGtCQUFrQjtRQUN6QixNQUFNLENBQUMscUJBQXFCO1FBQzVCLE1BQU0sQ0FBQyxpQkFBaUI7UUFDeEIsTUFBTSxDQUFDLG9CQUFvQjtRQUMzQixNQUFNLENBQUMsNEJBQTRCO1FBQ25DLE1BQU0sQ0FBQyxpQkFBaUI7UUFDeEIsTUFBTSxDQUFDLE1BQU07UUFDYixNQUFNLENBQUMsa0JBQWtCO1FBQ3pCLE1BQU0sQ0FBQyxtQkFBbUI7UUFDMUIsTUFBTSxDQUFDLE1BQU07UUFDYixNQUFNLENBQUMsZ0JBQWdCO1FBQ3ZCLE1BQU0sQ0FBQyxlQUFlO1FBQ3RCLE1BQU0sQ0FBQyxvQkFBb0I7UUFDM0IsTUFBTSxDQUFDLGVBQWU7UUFDdEIsTUFBTSxDQUFDLDJCQUEyQjtRQUNsQyxNQUFNLENBQUMsMEJBQTBCO1FBQ2pDLE1BQU0sQ0FBQyxtQkFBbUI7UUFDMUIsTUFBTSxDQUFDLGNBQWM7UUFDckIsTUFBTSxDQUFDLFVBQVU7UUFDakIsTUFBTSxDQUFDLGtCQUFrQjtRQUN6QixNQUFNLENBQUMsY0FBYztRQUNyQixNQUFNLENBQUMsdUJBQXVCO1FBQzlCLE1BQU0sQ0FBQyxxQkFBcUI7UUFDNUIsTUFBTSxDQUFDLG1CQUFtQjtRQUMxQixNQUFNLENBQUMsWUFBWTtRQUNuQixNQUFNLENBQUMsV0FBVztRQUNsQixNQUFNLENBQUMsNkJBQTZCO0tBQ3JDLENBQUMsUUFBUSxDQUFDLEtBQUssQ0FBQyxDQUFDO0NBQ25CO0FBRUQsaUVBQWlFLENBQ2pFLE9BQU8sU0FBUyxnQkFBZ0IsQ0FBQyxLQUFhLEVBQTJCO0lBQ3ZFLE9BQU87UUFDTCxNQUFNLENBQUMsZUFBZTtRQUN0QixNQUFNLENBQUMsZ0JBQWdCO1FBQ3ZCLE1BQU0sQ0FBQyxLQUFLO1FBQ1osTUFBTSxDQUFDLFFBQVE7UUFDZixNQUFNLENBQUMsUUFBUTtRQUNmLE1BQU0sQ0FBQyxpQkFBaUI7UUFDeEIsTUFBTSxDQUFDLGlCQUFpQjtLQUN6QixDQUFDLFFBQVEsQ0FBQyxLQUFLLENBQUMsQ0FBQztDQUNuQjtBQUVELCtDQUErQyxDQUMvQyxPQUFPLFNBQVMsTUFBTSxDQUFDLEtBQWEsRUFBVztJQUM3QyxPQUFPLCtCQUErQixJQUFJLENBQUMsS0FBSyxDQUFDLENBQUM7Q0FDbkQ7QUFFRCxxREFBcUQsQ0FDckQsT0FBTyxTQUFTLFlBQVksQ0FBQyxFQUFjLEVBQWM7SUFDdkQsTUFBTSxNQUFNLEdBQUcsSUFBSSxVQUFVLENBQUMsRUFBRSxDQUFDLE1BQU0sQ0FBQyxBQUFDO0lBQ3pDLElBQUksQ0FBQyxHQUFHLENBQUMsQUFBQztJQUNWLElBQUssSUFBSSxDQUFDLEdBQUcsQ0FBQyxFQUFFLENBQUMsR0FBRyxFQUFFLENBQUMsTUFBTSxFQUFFLENBQUMsRUFBRSxDQUFFO1FBQ2xDLElBQUksRUFBRSxDQUFDLENBQUMsQ0FBQyxLQUFLLEtBQUssSUFBSSxFQUFFLENBQUMsQ0FBQyxDQUFDLEtBQUssSUFBSSxFQUFFLFNBQVM7UUFDaEQsTUFBTSxDQUFDLENBQUMsRUFBRSxDQUFDLEdBQUcsRUFBRSxDQUFDLENBQUMsQ0FBQyxDQUFDO0tBQ3JCO0lBQ0QsT0FBTyxNQUFNLENBQUMsS0FBSyxDQUFDLENBQUMsRUFBRSxDQUFDLENBQUMsQ0FBQztDQUMzQjtBQUVELE9BQU8sU0FBUyxRQUFRLENBQUMsS0FBaUIsRUFBYztJQUN0RCxJQUFJLEtBQUssQ0FBQyxLQUFLLENBQUMsVUFBVSxHQUFHLENBQUMsQ0FBQyxJQUFJLEVBQUUsRUFBRTtRQUNyQyxJQUFJLElBQUksR0FBRyxDQUFDLEFBQUM7UUFDYixJQUFJLEtBQUssQ0FBQyxVQUFVLEdBQUcsQ0FBQyxJQUFJLEtBQUssQ0FBQyxLQUFLLENBQUMsVUFBVSxHQUFHLENBQUMsQ0FBQyxLQUFLLEVBQUUsRUFBRTtZQUM5RCxJQUFJLEdBQUcsQ0FBQyxDQUFDO1NBQ1Y7UUFDRCxPQUFPLEtBQUssQ0FBQyxRQUFRLENBQUMsQ0FBQyxFQUFFLEtBQUssQ0FBQyxVQUFVLEdBQUcsSUFBSSxDQUFDLENBQUM7S0FDbkQ7SUFDRCxPQUFPLEtBQUssQ0FBQztDQUNkO0FBRUQ7Ozs7Ozs7Ozs7Ozs7Ozs7Ozs7Ozs7Ozs7OztHQTJCRyxDQUVILE1BQU0sY0FBYywrQkFBK0IsQUFBQztBQUlwRCxPQUFPLFNBQVMsV0FBVyxDQUFDLFFBQWdCLEVBQUUsWUFBcUIsRUFBVTtJQUMzRSxJQUFJLElBQUksR0FBRyxZQUFZLEFBQUM7SUFDeEIsSUFBSSxJQUFJLEdBQUcsUUFBUSxBQUFDO0lBRXBCLDRDQUE0QztJQUM1QyxJQUFJLFlBQVksS0FBSyxTQUFTLEVBQUU7UUFDOUIsSUFBSSxHQUFHLFFBQVEsQ0FBQztRQUNoQixJQUFJLEdBQUcsR0FBRyxDQUFDO0tBQ1o7SUFFRCxJQUFJLElBQUksSUFBSSxJQUFJLEVBQUU7UUFDaEIsTUFBTSxJQUFJLFNBQVMsQ0FBQyxvQ0FBb0MsQ0FBQyxDQUFDO0tBQzNEO0lBRUQscUNBQXFDO0lBQ3JDLElBQUksSUFBSSxDQUFDLFFBQVEsQ0FBQyxJQUFJLENBQUMsRUFBRTtRQUN2QixNQUFNLGVBQWUsQ0FBQyxHQUFHLEVBQUUsZ0JBQWdCLENBQUMsQ0FBQztLQUM5QztJQUVELGdDQUFnQztJQUNoQyxJQUFJLFVBQVUsQ0FBQyxJQUFJLENBQUMsRUFBRTtRQUNwQixNQUFNLGVBQWUsQ0FBQyxHQUFHLEVBQUUsZ0JBQWdCLENBQUMsQ0FBQztLQUM5QztJQUVELG9CQUFvQjtJQUNwQixJQUFJLGNBQWMsQ0FBQyxJQUFJLENBQUMsU0FBUyxDQUFDLEdBQUcsR0FBRyxHQUFHLEdBQUcsSUFBSSxDQUFDLENBQUMsRUFBRTtRQUNwRCxNQUFNLGVBQWUsQ0FBQyxHQUFHLENBQUMsQ0FBQztLQUM1QjtJQUVELHlCQUF5QjtJQUN6QixPQUFPLFNBQVMsQ0FBQyxJQUFJLENBQUMsSUFBSSxFQUFFLElBQUksQ0FBQyxDQUFDLENBQUM7Q0FDcEM7QUFFRCx3RUFBd0UsQ0FDeEUsT0FBTyxNQUFNLHlCQUF5QixTQUM1QixlQUFlO0lBQ3ZCLGFBQWM7UUFDWixNQUFNLElBQUksR0FBRztZQUNYLE1BQU0sU0FBUyxFQUNiLEtBQWMsRUFDZCxVQUF3RCxFQUN4RDtnQkFDQSxLQUFLLEdBQUcsTUFBTSxLQUFLLENBQUM7Z0JBQ3BCLE9BQVEsT0FBTyxLQUFLO29CQUNsQixLQUFLLFFBQVE7d0JBQ1gsSUFBSSxLQUFLLEtBQUssSUFBSSxFQUFFOzRCQUNsQixVQUFVLENBQUMsU0FBUyxFQUFFLENBQUM7eUJBQ3hCLE1BQU0sSUFBSSxXQUFXLENBQUMsTUFBTSxDQUFDLEtBQUssQ0FBQyxFQUFFOzRCQUNwQyxVQUFVLENBQUMsT0FBTyxDQUNoQixJQUFJLFVBQVUsQ0FDWixLQUFLLENBQUMsTUFBTSxFQUNaLEtBQUssQ0FBQyxVQUFVLEVBQ2hCLEtBQUssQ0FBQyxVQUFVLENBQ2pCLENBQ0YsQ0FBQzt5QkFDSCxNQUFNLElBQ0wsS0FBSyxDQUFDLE9BQU8sQ0FBQyxLQUFLLENBQUMsSUFDcEIsS0FBSyxDQUFDLEtBQUssQ0FBQyxDQUFDLEtBQUssR0FBSyxPQUFPLEtBQUssS0FBSyxRQUFRLENBQUMsRUFDakQ7NEJBQ0EsVUFBVSxDQUFDLE9BQU8sQ0FBQyxJQUFJLFVBQVUsQ0FBQyxLQUFLLENBQUMsQ0FBQyxDQUFDO3lCQUMzQyxNQUFNLElBQ0wsT0FBTyxLQUFLLENBQUMsT0FBTyxLQUFLLFVBQVUsSUFBSSxLQUFLLENBQUMsT0FBTyxFQUFFLEtBQUssS0FBSyxFQUNoRTs0QkFDQSxJQUFJLENBQUMsU0FBUyxDQUFDLEtBQUssQ0FBQyxPQUFPLEVBQUUsRUFBRSxVQUFVLENBQUMsQ0FBQzt5QkFDN0MsTUFBTSxJQUFJLFFBQVEsSUFBSSxLQUFLLEVBQUU7NEJBQzVCLElBQUksQ0FBQyxTQUFTLENBQUMsSUFBSSxDQUFDLFNBQVMsQ0FBQyxLQUFLLENBQUMsRUFBRSxVQUFVLENBQUMsQ0FBQzt5QkFDbkQ7d0JBQ0QsTUFBTTtvQkFDUixLQUFLLFFBQVE7d0JBQ1gsVUFBVSxDQUFDLEtBQUssQ0FDZCxJQUFJLFNBQVMsQ0FBQywyQ0FBMkMsQ0FBQyxDQUMzRCxDQUFDO3dCQUNGLE1BQU07b0JBQ1IsS0FBSyxXQUFXO3dCQUNkLFVBQVUsQ0FBQyxLQUFLLENBQ2QsSUFBSSxTQUFTLENBQUMsNENBQTRDLENBQUMsQ0FDNUQsQ0FBQzt3QkFDRixNQUFNO29CQUNSO3dCQUNFLFVBQVUsQ0FBQyxPQUFPLENBQUMsSUFBSSxDQUFDLE9BQU8sQ0FBQyxNQUFNLENBQUMsTUFBTSxDQUFDLEtBQUssQ0FBQyxDQUFDLENBQUMsQ0FBQztpQkFDMUQ7YUFDRjtZQUNELE9BQU8sRUFBRSxJQUFJLFdBQVcsRUFBRTtTQUMzQixBQUFDO1FBQ0YsS0FBSyxDQUFDLElBQUksQ0FBQyxDQUFDO0tBQ2I7Q0FDRjtBQUVELE1BQU0sWUFBWSxHQUEyQjtJQUMzQyxHQUFHLEVBQUUsR0FBRztJQUNSLEdBQUcsRUFBRSxHQUFHO0lBQ1IsR0FBRyxFQUFFLEVBQUU7Q0FDUixBQUFDO0FBRUYsTUFBTSxPQUFPLEdBQUcsSUFBSSxXQUFXLEVBQUUsQUFBQztBQUVsQyxPQUFPLFNBQVMsZ0JBQWdCLENBQUMsSUFBMEIsRUFBVTtJQUNuRSxPQUFPLE1BQU0sQ0FBQyxNQUFNLENBQUMsSUFBSSxDQUFDLENBQUMsT0FBTyxhQUFhLENBQUMsQ0FBQyxHQUFLLFlBQVksQ0FBQyxDQUFDLENBQUMsQ0FBQyxDQUFDO0NBQ3hFO0FBRUQsT0FBTyxTQUFTLE1BQU0sR0FBWTtJQUNoQyxPQUFPLFNBQVMsSUFBSSxVQUFVLElBQUksUUFBUSxJQUFJLFVBQVUsQ0FBQztDQUMxRDtBQUVELE9BQU8sU0FBUyxTQUFTLENBQUMsR0FBUSxFQUFzQjtJQUN0RCxJQUFJLE9BQU8sR0FBRyxLQUFLLFFBQVEsRUFBRTtRQUMzQixHQUFHLEdBQUcsT0FBTyxDQUFDLE1BQU0sQ0FBQyxHQUFHLENBQUMsQ0FBQztLQUMzQixNQUFNLElBQUksS0FBSyxDQUFDLE9BQU8sQ0FBQyxHQUFHLENBQUMsRUFBRTtRQUM3QixHQUFHLEdBQUcsSUFBSSxVQUFVLENBQUMsR0FBRyxDQUFDLENBQUM7S0FDM0I7SUFDRCxPQUFPLE1BQU0sQ0FBQyxNQUFNLENBQUMsU0FBUyxDQUM1QixLQUFLLEVBQ0wsR0FBRyxFQUNIO1FBQ0UsSUFBSSxFQUFFLE1BQU07UUFDWixJQUFJLEVBQUU7WUFBRSxJQUFJLEVBQUUsU0FBUztTQUFFO0tBQzFCLEVBQ0QsSUFBSSxFQUNKO1FBQUMsTUFBTTtRQUFFLFFBQVE7S0FBQyxDQUNuQixDQUFDO0NBQ0g7QUFFRCxPQUFPLFNBQVMsSUFBSSxDQUFDLElBQVUsRUFBRSxHQUFjLEVBQXdCO0lBQ3JFLElBQUksT0FBTyxJQUFJLEtBQUssUUFBUSxFQUFFO1FBQzVCLElBQUksR0FBRyxPQUFPLENBQUMsTUFBTSxDQUFDLElBQUksQ0FBQyxDQUFDO0tBQzdCLE1BQU0sSUFBSSxLQUFLLENBQUMsT0FBTyxDQUFDLElBQUksQ0FBQyxFQUFFO1FBQzlCLElBQUksR0FBRyxVQUFVLENBQUMsSUFBSSxDQUFDLElBQUksQ0FBQyxDQUFDO0tBQzlCO0lBQ0QsT0FBTyxNQUFNLENBQUMsTUFBTSxDQUFDLElBQUksQ0FBQyxNQUFNLEVBQUUsR0FBRyxFQUFFLElBQUksQ0FBQyxDQUFDO0NBQzlDIn0=
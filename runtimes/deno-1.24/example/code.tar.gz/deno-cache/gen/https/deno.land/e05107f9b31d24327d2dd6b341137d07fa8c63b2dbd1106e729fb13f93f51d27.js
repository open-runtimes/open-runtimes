// Copyright 2020-2021 the denosaurs team. All rights reserved. MIT license.
import { blue, bold, exists, grant, gray, log, reset, setColorEnabled, yellow } from "../deps.ts";
import { getConfigFilename, writeConfigTemplate } from "./config.ts";
import { Runner } from "./runner.ts";
import { templates } from "./templates.ts";
import { VERSION } from "../info.ts";
const logger = log.create("main");
/** These are the permissions required for a clean run
 * of `denon`. If not provided through installation they
 * will be asked on every run by the `grant()` std function.
 *
 * The permissions required are:
 * - *read*, used to correctly load a configuration file and
 * to monitor for filesystem changes in the directory `denon`
 * is executed to reload scripts.
 * - *write*, write configuration templates.
 * - *run*, used to run scripts as child processes.
 * - *write*, download configuration templates and import
 * `denon.config.ts` file. */ export const PERMISSIONS = [
    {
        name: "read"
    },
    {
        name: "write"
    },
    {
        name: "run"
    }, 
];
/** These permissions are required on specific situations,
 * `denon` should not be installed with this permissions
 * but you should be granting them when they are required. */ export const PERMISSION_OPTIONAL = {
    initializeConfig: [
        {
            name: "write"
        }
    ]
};
export async function grantPermissions() {
    // @see PERMISSIONS .
    const permissions = await grant([
        ...PERMISSIONS
    ]);
    if (!permissions || permissions.length < PERMISSIONS.length) {
        logger.critical("Required permissions `read` and `run` not granted");
        Deno.exit(1);
    }
}
/** Create configuration file in the root of current work directory.
 * // TODO: make it interactive */ export async function initializeConfig(type = "json") {
    const permissions = await grant(PERMISSION_OPTIONAL.initializeConfig);
    if (!permissions || permissions.length < PERMISSION_OPTIONAL.initializeConfig.length) {
        logger.critical("Required permissions for this operation not granted");
        Deno.exit(1);
    }
    const template = templates[type];
    if (!template) {
        logger.error(`\`${type}\` is not a valid template.`);
        logger.info(`valid templates are ${Object.keys(templates)}`);
        return;
    }
    if (!await exists(template.filename)) {
        await writeConfigTemplate(template);
    } else {
        logger.error(`\`${template.filename}\` already exists in root dir`);
    }
}
/** Grab a fresh copy of denon */ export async function upgrade(version) {
    const url = version !== "latest" ? `https://deno.land/x/denon@${version}/denon.ts` : "https://deno.land/x/denon/denon.ts";
    logger.debug(`Checking if ${url} exists`);
    if ((await fetch(url)).status !== 200) {
        logger.critical(`Upgrade url ${url} does not exist`);
        Deno.exit(1);
    }
    logger.info(`Running \`deno install -qAfr --unstable ${url}\``);
    await Deno.run({
        cmd: [
            "deno",
            "install",
            "-qAfr",
            "--unstable",
            url
        ],
        stdout: undefined
    }).status();
    Deno.exit(0);
}
// /** Generate autocomplete suggestions */
// export function autocomplete(config: CompleteDenonConfig): void {
//   // Write your CLI template.
//   const completion = omelette.default(`denon <script>`);
//   // Bind events for every template part.
//   completion.on("script", function ({ reply }: { reply: Function }): void {
//     // const watcher = new Watcher(config.watcher);
//     const auto = Object.keys(config.scripts);
//     // for (const file of Deno.readDirSync(Deno.cwd())) {
//     //   if (file.isFile && watcher.isWatched(file.name)) {
//     //     auto.push(file.name);
//     //   } else {
//     //     // auto.push(file.name);
//     //   }
//     // }
//     console.log(auto);
//     reply(auto);
//   });
//   completion.init();
// }
/** List all available scripts declared in the config file.
 * // TODO(@qu4k): make it interactive */ export async function printAvailableScripts(config) {
    if (Object.keys(config.scripts).length) {
        logger.info("available scripts:");
        const runner = new Runner(config);
        for (const name of Object.keys(config.scripts)){
            const script = config.scripts[name];
            console.log();
            console.log(` - ${yellow(bold(name))}`);
            if (typeof script === "object" && !Array.isArray(script) && script.desc) {
                console.log(`   ${script.desc}`);
            }
            const commands = runner.build(name).map((command)=>command.cmd.join(" ")).join(bold(" && "));
            console.log(gray(`   $ ${commands}`));
        }
        console.log();
        console.log(`You can run scripts with \`${blue("denon")} ${yellow("<script>")}\``);
    } else {
        logger.error("It looks like you don't have any scripts...");
        const config1 = getConfigFilename();
        if (config1) {
            logger.info(`You can add scripts to your \`${config1}\` file. Check the docs.`);
        } else {
            logger.info(`You can create a config to add scripts to with \`${blue("denon")} ${yellow("--init")}${reset("`.")}`);
        }
    }
    const latest = await fetchLatestVersion();
    if (latest && latest !== VERSION) {
        logger.warning(`New version available (${latest}). Upgrade with \`${blue("denon")} ${yellow("--upgrade")}${reset("`.")}`);
    }
}
export async function fetchLatestVersion() {
    const cdn = "https://cdn.deno.land/";
    const url = `${cdn}denon/meta/versions.json`;
    const res = await fetch(url);
    if (res.status !== 200) return undefined;
    const data = await res.json();
    return data.latest;
}
/** Help message to be shown if `denon`
 * is run with `--help` flag. */ export function printHelp() {
    setColorEnabled(true);
    console.log(`${blue("DENON")} - ${VERSION}
created by qu4k & eliassjogreen
Monitor any changes in your Deno application and automatically restart.

Usage:
    ${blue("denon")} ${yellow("<script name>")}     ${gray("-- eg: denon start")}
    ${blue("denon")} ${yellow("<command>")}         ${gray("-- eg: denon run helloworld.ts")}
    ${blue("denon")} [options]         ${gray("-- eg: denon --help")}

Options:
    -h --help               Show this screen.
    -v --version            Show version.
    -i --init               Create config file in current working dir.
    -u --upgrade <version>  Upgrade to latest version. (default: master)
    -c --config <file>      Use specific file as configuration.
`);
}
//# sourceMappingURL=data:application/json;base64,eyJ2ZXJzaW9uIjozLCJzb3VyY2VzIjpbImh0dHBzOi8vZGVuby5sYW5kL3gvZGVub25AMi41LjAvc3JjL2NsaS50cyJdLCJzb3VyY2VzQ29udGVudCI6WyIvLyBDb3B5cmlnaHQgMjAyMC0yMDIxIHRoZSBkZW5vc2F1cnMgdGVhbS4gQWxsIHJpZ2h0cyByZXNlcnZlZC4gTUlUIGxpY2Vuc2UuXG5cbmltcG9ydCB7XG4gIGJsdWUsXG4gIGJvbGQsXG4gIGV4aXN0cyxcbiAgZ3JhbnQsXG4gIGdyYXksXG4gIGxvZyxcbiAgcmVzZXQsXG4gIHNldENvbG9yRW5hYmxlZCxcbiAgeWVsbG93LFxufSBmcm9tIFwiLi4vZGVwcy50c1wiO1xuXG5pbXBvcnQge1xuICBDb21wbGV0ZURlbm9uQ29uZmlnLFxuICBnZXRDb25maWdGaWxlbmFtZSxcbiAgd3JpdGVDb25maWdUZW1wbGF0ZSxcbn0gZnJvbSBcIi4vY29uZmlnLnRzXCI7XG5pbXBvcnQgeyBSdW5uZXIgfSBmcm9tIFwiLi9ydW5uZXIudHNcIjtcblxuaW1wb3J0IHsgdGVtcGxhdGVzIH0gZnJvbSBcIi4vdGVtcGxhdGVzLnRzXCI7XG5pbXBvcnQgeyBWRVJTSU9OIH0gZnJvbSBcIi4uL2luZm8udHNcIjtcblxuY29uc3QgbG9nZ2VyID0gbG9nLmNyZWF0ZShcIm1haW5cIik7XG5cbi8qKiBUaGVzZSBhcmUgdGhlIHBlcm1pc3Npb25zIHJlcXVpcmVkIGZvciBhIGNsZWFuIHJ1blxuICogb2YgYGRlbm9uYC4gSWYgbm90IHByb3ZpZGVkIHRocm91Z2ggaW5zdGFsbGF0aW9uIHRoZXlcbiAqIHdpbGwgYmUgYXNrZWQgb24gZXZlcnkgcnVuIGJ5IHRoZSBgZ3JhbnQoKWAgc3RkIGZ1bmN0aW9uLlxuICpcbiAqIFRoZSBwZXJtaXNzaW9ucyByZXF1aXJlZCBhcmU6XG4gKiAtICpyZWFkKiwgdXNlZCB0byBjb3JyZWN0bHkgbG9hZCBhIGNvbmZpZ3VyYXRpb24gZmlsZSBhbmRcbiAqIHRvIG1vbml0b3IgZm9yIGZpbGVzeXN0ZW0gY2hhbmdlcyBpbiB0aGUgZGlyZWN0b3J5IGBkZW5vbmBcbiAqIGlzIGV4ZWN1dGVkIHRvIHJlbG9hZCBzY3JpcHRzLlxuICogLSAqd3JpdGUqLCB3cml0ZSBjb25maWd1cmF0aW9uIHRlbXBsYXRlcy5cbiAqIC0gKnJ1biosIHVzZWQgdG8gcnVuIHNjcmlwdHMgYXMgY2hpbGQgcHJvY2Vzc2VzLlxuICogLSAqd3JpdGUqLCBkb3dubG9hZCBjb25maWd1cmF0aW9uIHRlbXBsYXRlcyBhbmQgaW1wb3J0XG4gKiBgZGVub24uY29uZmlnLnRzYCBmaWxlLiAqL1xuZXhwb3J0IGNvbnN0IFBFUk1JU1NJT05TOiBEZW5vLlBlcm1pc3Npb25EZXNjcmlwdG9yW10gPSBbXG4gIHsgbmFtZTogXCJyZWFkXCIgfSxcbiAgeyBuYW1lOiBcIndyaXRlXCIgfSxcbiAgeyBuYW1lOiBcInJ1blwiIH0sXG5dO1xuXG4vKiogVGhlc2UgcGVybWlzc2lvbnMgYXJlIHJlcXVpcmVkIG9uIHNwZWNpZmljIHNpdHVhdGlvbnMsXG4gKiBgZGVub25gIHNob3VsZCBub3QgYmUgaW5zdGFsbGVkIHdpdGggdGhpcyBwZXJtaXNzaW9uc1xuICogYnV0IHlvdSBzaG91bGQgYmUgZ3JhbnRpbmcgdGhlbSB3aGVuIHRoZXkgYXJlIHJlcXVpcmVkLiAqL1xuZXhwb3J0IGNvbnN0IFBFUk1JU1NJT05fT1BUSU9OQUw6IHtcbiAgW2tleTogc3RyaW5nXTogRGVuby5QZXJtaXNzaW9uRGVzY3JpcHRvcltdO1xufSA9IHtcbiAgaW5pdGlhbGl6ZUNvbmZpZzogW3sgbmFtZTogXCJ3cml0ZVwiIH1dLFxufTtcblxuZXhwb3J0IGFzeW5jIGZ1bmN0aW9uIGdyYW50UGVybWlzc2lvbnMoKTogUHJvbWlzZTx2b2lkPiB7XG4gIC8vIEBzZWUgUEVSTUlTU0lPTlMgLlxuICBjb25zdCBwZXJtaXNzaW9ucyA9IGF3YWl0IGdyYW50KFsuLi5QRVJNSVNTSU9OU10pO1xuICBpZiAoIXBlcm1pc3Npb25zIHx8IHBlcm1pc3Npb25zLmxlbmd0aCA8IFBFUk1JU1NJT05TLmxlbmd0aCkge1xuICAgIGxvZ2dlci5jcml0aWNhbChcIlJlcXVpcmVkIHBlcm1pc3Npb25zIGByZWFkYCBhbmQgYHJ1bmAgbm90IGdyYW50ZWRcIik7XG4gICAgRGVuby5leGl0KDEpO1xuICB9XG59XG4vKiogQ3JlYXRlIGNvbmZpZ3VyYXRpb24gZmlsZSBpbiB0aGUgcm9vdCBvZiBjdXJyZW50IHdvcmsgZGlyZWN0b3J5LlxuICogLy8gVE9ETzogbWFrZSBpdCBpbnRlcmFjdGl2ZSAqL1xuZXhwb3J0IGFzeW5jIGZ1bmN0aW9uIGluaXRpYWxpemVDb25maWcodHlwZSA9IFwianNvblwiKTogUHJvbWlzZTx2b2lkPiB7XG4gIGNvbnN0IHBlcm1pc3Npb25zID0gYXdhaXQgZ3JhbnQoUEVSTUlTU0lPTl9PUFRJT05BTC5pbml0aWFsaXplQ29uZmlnKTtcbiAgaWYgKFxuICAgICFwZXJtaXNzaW9ucyB8fFxuICAgIHBlcm1pc3Npb25zLmxlbmd0aCA8IFBFUk1JU1NJT05fT1BUSU9OQUwuaW5pdGlhbGl6ZUNvbmZpZy5sZW5ndGhcbiAgKSB7XG4gICAgbG9nZ2VyLmNyaXRpY2FsKFwiUmVxdWlyZWQgcGVybWlzc2lvbnMgZm9yIHRoaXMgb3BlcmF0aW9uIG5vdCBncmFudGVkXCIpO1xuICAgIERlbm8uZXhpdCgxKTtcbiAgfVxuICBjb25zdCB0ZW1wbGF0ZSA9IHRlbXBsYXRlc1t0eXBlXTtcbiAgaWYgKCF0ZW1wbGF0ZSkge1xuICAgIGxvZ2dlci5lcnJvcihgXFxgJHt0eXBlfVxcYCBpcyBub3QgYSB2YWxpZCB0ZW1wbGF0ZS5gKTtcbiAgICBsb2dnZXIuaW5mbyhgdmFsaWQgdGVtcGxhdGVzIGFyZSAke09iamVjdC5rZXlzKHRlbXBsYXRlcyl9YCk7XG4gICAgcmV0dXJuO1xuICB9XG5cbiAgaWYgKCEoYXdhaXQgZXhpc3RzKHRlbXBsYXRlLmZpbGVuYW1lKSkpIHtcbiAgICBhd2FpdCB3cml0ZUNvbmZpZ1RlbXBsYXRlKHRlbXBsYXRlKTtcbiAgfSBlbHNlIHtcbiAgICBsb2dnZXIuZXJyb3IoYFxcYCR7dGVtcGxhdGUuZmlsZW5hbWV9XFxgIGFscmVhZHkgZXhpc3RzIGluIHJvb3QgZGlyYCk7XG4gIH1cbn1cblxuLyoqIEdyYWIgYSBmcmVzaCBjb3B5IG9mIGRlbm9uICovXG5leHBvcnQgYXN5bmMgZnVuY3Rpb24gdXBncmFkZSh2ZXJzaW9uPzogc3RyaW5nKTogUHJvbWlzZTx2b2lkPiB7XG4gIGNvbnN0IHVybCA9IHZlcnNpb24gIT09IFwibGF0ZXN0XCJcbiAgICA/IGBodHRwczovL2Rlbm8ubGFuZC94L2Rlbm9uQCR7dmVyc2lvbn0vZGVub24udHNgXG4gICAgOiBcImh0dHBzOi8vZGVuby5sYW5kL3gvZGVub24vZGVub24udHNcIjtcblxuICBsb2dnZXIuZGVidWcoYENoZWNraW5nIGlmICR7dXJsfSBleGlzdHNgKTtcbiAgaWYgKChhd2FpdCBmZXRjaCh1cmwpKS5zdGF0dXMgIT09IDIwMCkge1xuICAgIGxvZ2dlci5jcml0aWNhbChgVXBncmFkZSB1cmwgJHt1cmx9IGRvZXMgbm90IGV4aXN0YCk7XG4gICAgRGVuby5leGl0KDEpO1xuICB9XG5cbiAgbG9nZ2VyLmluZm8oXG4gICAgYFJ1bm5pbmcgXFxgZGVubyBpbnN0YWxsIC1xQWZyIC0tdW5zdGFibGUgJHt1cmx9XFxgYCxcbiAgKTtcbiAgYXdhaXQgRGVuby5ydW4oe1xuICAgIGNtZDogW1wiZGVub1wiLCBcImluc3RhbGxcIiwgXCItcUFmclwiLCBcIi0tdW5zdGFibGVcIiwgdXJsXSxcbiAgICBzdGRvdXQ6IHVuZGVmaW5lZCxcbiAgfSkuc3RhdHVzKCk7XG4gIERlbm8uZXhpdCgwKTtcbn1cblxuLy8gLyoqIEdlbmVyYXRlIGF1dG9jb21wbGV0ZSBzdWdnZXN0aW9ucyAqL1xuLy8gZXhwb3J0IGZ1bmN0aW9uIGF1dG9jb21wbGV0ZShjb25maWc6IENvbXBsZXRlRGVub25Db25maWcpOiB2b2lkIHtcbi8vICAgLy8gV3JpdGUgeW91ciBDTEkgdGVtcGxhdGUuXG4vLyAgIGNvbnN0IGNvbXBsZXRpb24gPSBvbWVsZXR0ZS5kZWZhdWx0KGBkZW5vbiA8c2NyaXB0PmApO1xuXG4vLyAgIC8vIEJpbmQgZXZlbnRzIGZvciBldmVyeSB0ZW1wbGF0ZSBwYXJ0LlxuLy8gICBjb21wbGV0aW9uLm9uKFwic2NyaXB0XCIsIGZ1bmN0aW9uICh7IHJlcGx5IH06IHsgcmVwbHk6IEZ1bmN0aW9uIH0pOiB2b2lkIHtcbi8vICAgICAvLyBjb25zdCB3YXRjaGVyID0gbmV3IFdhdGNoZXIoY29uZmlnLndhdGNoZXIpO1xuLy8gICAgIGNvbnN0IGF1dG8gPSBPYmplY3Qua2V5cyhjb25maWcuc2NyaXB0cyk7XG4vLyAgICAgLy8gZm9yIChjb25zdCBmaWxlIG9mIERlbm8ucmVhZERpclN5bmMoRGVuby5jd2QoKSkpIHtcbi8vICAgICAvLyAgIGlmIChmaWxlLmlzRmlsZSAmJiB3YXRjaGVyLmlzV2F0Y2hlZChmaWxlLm5hbWUpKSB7XG4vLyAgICAgLy8gICAgIGF1dG8ucHVzaChmaWxlLm5hbWUpO1xuLy8gICAgIC8vICAgfSBlbHNlIHtcbi8vICAgICAvLyAgICAgLy8gYXV0by5wdXNoKGZpbGUubmFtZSk7XG4vLyAgICAgLy8gICB9XG4vLyAgICAgLy8gfVxuLy8gICAgIGNvbnNvbGUubG9nKGF1dG8pO1xuLy8gICAgIHJlcGx5KGF1dG8pO1xuLy8gICB9KTtcblxuLy8gICBjb21wbGV0aW9uLmluaXQoKTtcbi8vIH1cblxuLyoqIExpc3QgYWxsIGF2YWlsYWJsZSBzY3JpcHRzIGRlY2xhcmVkIGluIHRoZSBjb25maWcgZmlsZS5cbiAqIC8vIFRPRE8oQHF1NGspOiBtYWtlIGl0IGludGVyYWN0aXZlICovXG5leHBvcnQgYXN5bmMgZnVuY3Rpb24gcHJpbnRBdmFpbGFibGVTY3JpcHRzKFxuICBjb25maWc6IENvbXBsZXRlRGVub25Db25maWcsXG4pOiBQcm9taXNlPHZvaWQ+IHtcbiAgaWYgKE9iamVjdC5rZXlzKGNvbmZpZy5zY3JpcHRzKS5sZW5ndGgpIHtcbiAgICBsb2dnZXIuaW5mbyhcImF2YWlsYWJsZSBzY3JpcHRzOlwiKTtcbiAgICBjb25zdCBydW5uZXIgPSBuZXcgUnVubmVyKGNvbmZpZyk7XG4gICAgZm9yIChjb25zdCBuYW1lIG9mIE9iamVjdC5rZXlzKGNvbmZpZy5zY3JpcHRzKSkge1xuICAgICAgY29uc3Qgc2NyaXB0ID0gY29uZmlnLnNjcmlwdHNbbmFtZV07XG4gICAgICBjb25zb2xlLmxvZygpO1xuICAgICAgY29uc29sZS5sb2coYCAtICR7eWVsbG93KGJvbGQobmFtZSkpfWApO1xuXG4gICAgICBpZiAodHlwZW9mIHNjcmlwdCA9PT0gXCJvYmplY3RcIiAmJiAhQXJyYXkuaXNBcnJheShzY3JpcHQpICYmIHNjcmlwdC5kZXNjKSB7XG4gICAgICAgIGNvbnNvbGUubG9nKGAgICAke3NjcmlwdC5kZXNjfWApO1xuICAgICAgfVxuXG4gICAgICBjb25zdCBjb21tYW5kcyA9IHJ1bm5lclxuICAgICAgICAuYnVpbGQobmFtZSlcbiAgICAgICAgLm1hcCgoY29tbWFuZCkgPT4gY29tbWFuZC5jbWQuam9pbihcIiBcIikpXG4gICAgICAgIC5qb2luKGJvbGQoXCIgJiYgXCIpKTtcblxuICAgICAgY29uc29sZS5sb2coZ3JheShgICAgJCAke2NvbW1hbmRzfWApKTtcbiAgICB9XG4gICAgY29uc29sZS5sb2coKTtcbiAgICBjb25zb2xlLmxvZyhcbiAgICAgIGBZb3UgY2FuIHJ1biBzY3JpcHRzIHdpdGggXFxgJHtibHVlKFwiZGVub25cIil9ICR7eWVsbG93KFwiPHNjcmlwdD5cIil9XFxgYCxcbiAgICApO1xuICB9IGVsc2Uge1xuICAgIGxvZ2dlci5lcnJvcihcIkl0IGxvb2tzIGxpa2UgeW91IGRvbid0IGhhdmUgYW55IHNjcmlwdHMuLi5cIik7XG4gICAgY29uc3QgY29uZmlnID0gZ2V0Q29uZmlnRmlsZW5hbWUoKTtcbiAgICBpZiAoY29uZmlnKSB7XG4gICAgICBsb2dnZXIuaW5mbyhcbiAgICAgICAgYFlvdSBjYW4gYWRkIHNjcmlwdHMgdG8geW91ciBcXGAke2NvbmZpZ31cXGAgZmlsZS4gQ2hlY2sgdGhlIGRvY3MuYCxcbiAgICAgICk7XG4gICAgfSBlbHNlIHtcbiAgICAgIGxvZ2dlci5pbmZvKFxuICAgICAgICBgWW91IGNhbiBjcmVhdGUgYSBjb25maWcgdG8gYWRkIHNjcmlwdHMgdG8gd2l0aCBcXGAke1xuICAgICAgICAgIGJsdWUoXG4gICAgICAgICAgICBcImRlbm9uXCIsXG4gICAgICAgICAgKVxuICAgICAgICB9ICR7eWVsbG93KFwiLS1pbml0XCIpfSR7cmVzZXQoXCJgLlwiKX1gLFxuICAgICAgKTtcbiAgICB9XG4gIH1cbiAgY29uc3QgbGF0ZXN0ID0gYXdhaXQgZmV0Y2hMYXRlc3RWZXJzaW9uKCk7XG4gIGlmIChsYXRlc3QgJiYgbGF0ZXN0ICE9PSBWRVJTSU9OKSB7XG4gICAgbG9nZ2VyLndhcm5pbmcoXG4gICAgICBgTmV3IHZlcnNpb24gYXZhaWxhYmxlICgke2xhdGVzdH0pLiBVcGdyYWRlIHdpdGggXFxgJHtcbiAgICAgICAgYmx1ZShcbiAgICAgICAgICBcImRlbm9uXCIsXG4gICAgICAgIClcbiAgICAgIH0gJHt5ZWxsb3coXCItLXVwZ3JhZGVcIil9JHtyZXNldChcImAuXCIpfWAsXG4gICAgKTtcbiAgfVxufVxuXG5leHBvcnQgYXN5bmMgZnVuY3Rpb24gZmV0Y2hMYXRlc3RWZXJzaW9uKCk6IFByb21pc2U8c3RyaW5nIHwgdW5kZWZpbmVkPiB7XG4gIGNvbnN0IGNkbiA9IFwiaHR0cHM6Ly9jZG4uZGVuby5sYW5kL1wiO1xuICBjb25zdCB1cmwgPSBgJHtjZG59ZGVub24vbWV0YS92ZXJzaW9ucy5qc29uYDtcbiAgY29uc3QgcmVzID0gYXdhaXQgZmV0Y2godXJsKTtcbiAgaWYgKHJlcy5zdGF0dXMgIT09IDIwMCkgcmV0dXJuIHVuZGVmaW5lZDtcbiAgY29uc3QgZGF0YSA9IGF3YWl0IHJlcy5qc29uKCk7XG4gIHJldHVybiBkYXRhLmxhdGVzdDtcbn1cblxuLyoqIEhlbHAgbWVzc2FnZSB0byBiZSBzaG93biBpZiBgZGVub25gXG4gKiBpcyBydW4gd2l0aCBgLS1oZWxwYCBmbGFnLiAqL1xuZXhwb3J0IGZ1bmN0aW9uIHByaW50SGVscCgpOiB2b2lkIHtcbiAgc2V0Q29sb3JFbmFibGVkKHRydWUpO1xuICBjb25zb2xlLmxvZyhcbiAgICBgJHtibHVlKFwiREVOT05cIil9IC0gJHtWRVJTSU9OfVxuY3JlYXRlZCBieSBxdTRrICYgZWxpYXNzam9ncmVlblxuTW9uaXRvciBhbnkgY2hhbmdlcyBpbiB5b3VyIERlbm8gYXBwbGljYXRpb24gYW5kIGF1dG9tYXRpY2FsbHkgcmVzdGFydC5cblxuVXNhZ2U6XG4gICAgJHtibHVlKFwiZGVub25cIil9ICR7eWVsbG93KFwiPHNjcmlwdCBuYW1lPlwiKX0gICAgICR7XG4gICAgICBncmF5KFxuICAgICAgICBcIi0tIGVnOiBkZW5vbiBzdGFydFwiLFxuICAgICAgKVxuICAgIH1cbiAgICAke2JsdWUoXCJkZW5vblwiKX0gJHt5ZWxsb3coXCI8Y29tbWFuZD5cIil9ICAgICAgICAgJHtcbiAgICAgIGdyYXkoXG4gICAgICAgIFwiLS0gZWc6IGRlbm9uIHJ1biBoZWxsb3dvcmxkLnRzXCIsXG4gICAgICApXG4gICAgfVxuICAgICR7Ymx1ZShcImRlbm9uXCIpfSBbb3B0aW9uc10gICAgICAgICAke2dyYXkoXCItLSBlZzogZGVub24gLS1oZWxwXCIpfVxuXG5PcHRpb25zOlxuICAgIC1oIC0taGVscCAgICAgICAgICAgICAgIFNob3cgdGhpcyBzY3JlZW4uXG4gICAgLXYgLS12ZXJzaW9uICAgICAgICAgICAgU2hvdyB2ZXJzaW9uLlxuICAgIC1pIC0taW5pdCAgICAgICAgICAgICAgIENyZWF0ZSBjb25maWcgZmlsZSBpbiBjdXJyZW50IHdvcmtpbmcgZGlyLlxuICAgIC11IC0tdXBncmFkZSA8dmVyc2lvbj4gIFVwZ3JhZGUgdG8gbGF0ZXN0IHZlcnNpb24uIChkZWZhdWx0OiBtYXN0ZXIpXG4gICAgLWMgLS1jb25maWcgPGZpbGU+ICAgICAgVXNlIHNwZWNpZmljIGZpbGUgYXMgY29uZmlndXJhdGlvbi5cbmAsXG4gICk7XG59XG4iXSwibmFtZXMiOltdLCJtYXBwaW5ncyI6IkFBQUEsNEVBQTRFO0FBRTVFLFNBQ0UsSUFBSSxFQUNKLElBQUksRUFDSixNQUFNLEVBQ04sS0FBSyxFQUNMLElBQUksRUFDSixHQUFHLEVBQ0gsS0FBSyxFQUNMLGVBQWUsRUFDZixNQUFNLFFBQ0QsWUFBWSxDQUFDO0FBRXBCLFNBRUUsaUJBQWlCLEVBQ2pCLG1CQUFtQixRQUNkLGFBQWEsQ0FBQztBQUNyQixTQUFTLE1BQU0sUUFBUSxhQUFhLENBQUM7QUFFckMsU0FBUyxTQUFTLFFBQVEsZ0JBQWdCLENBQUM7QUFDM0MsU0FBUyxPQUFPLFFBQVEsWUFBWSxDQUFDO0FBRXJDLE1BQU0sTUFBTSxHQUFHLEdBQUcsQ0FBQyxNQUFNLENBQUMsTUFBTSxDQUFDLEFBQUM7QUFFbEM7Ozs7Ozs7Ozs7OzZCQVc2QixDQUM3QixPQUFPLE1BQU0sV0FBVyxHQUFnQztJQUN0RDtRQUFFLElBQUksRUFBRSxNQUFNO0tBQUU7SUFDaEI7UUFBRSxJQUFJLEVBQUUsT0FBTztLQUFFO0lBQ2pCO1FBQUUsSUFBSSxFQUFFLEtBQUs7S0FBRTtDQUNoQixDQUFDO0FBRUY7OzZEQUU2RCxDQUM3RCxPQUFPLE1BQU0sbUJBQW1CLEdBRTVCO0lBQ0YsZ0JBQWdCLEVBQUU7UUFBQztZQUFFLElBQUksRUFBRSxPQUFPO1NBQUU7S0FBQztDQUN0QyxDQUFDO0FBRUYsT0FBTyxlQUFlLGdCQUFnQixHQUFrQjtJQUN0RCxxQkFBcUI7SUFDckIsTUFBTSxXQUFXLEdBQUcsTUFBTSxLQUFLLENBQUM7V0FBSSxXQUFXO0tBQUMsQ0FBQyxBQUFDO0lBQ2xELElBQUksQ0FBQyxXQUFXLElBQUksV0FBVyxDQUFDLE1BQU0sR0FBRyxXQUFXLENBQUMsTUFBTSxFQUFFO1FBQzNELE1BQU0sQ0FBQyxRQUFRLENBQUMsbURBQW1ELENBQUMsQ0FBQztRQUNyRSxJQUFJLENBQUMsSUFBSSxDQUFDLENBQUMsQ0FBQyxDQUFDO0tBQ2Q7Q0FDRjtBQUNEO2tDQUNrQyxDQUNsQyxPQUFPLGVBQWUsZ0JBQWdCLENBQUMsSUFBSSxHQUFHLE1BQU0sRUFBaUI7SUFDbkUsTUFBTSxXQUFXLEdBQUcsTUFBTSxLQUFLLENBQUMsbUJBQW1CLENBQUMsZ0JBQWdCLENBQUMsQUFBQztJQUN0RSxJQUNFLENBQUMsV0FBVyxJQUNaLFdBQVcsQ0FBQyxNQUFNLEdBQUcsbUJBQW1CLENBQUMsZ0JBQWdCLENBQUMsTUFBTSxFQUNoRTtRQUNBLE1BQU0sQ0FBQyxRQUFRLENBQUMscURBQXFELENBQUMsQ0FBQztRQUN2RSxJQUFJLENBQUMsSUFBSSxDQUFDLENBQUMsQ0FBQyxDQUFDO0tBQ2Q7SUFDRCxNQUFNLFFBQVEsR0FBRyxTQUFTLENBQUMsSUFBSSxDQUFDLEFBQUM7SUFDakMsSUFBSSxDQUFDLFFBQVEsRUFBRTtRQUNiLE1BQU0sQ0FBQyxLQUFLLENBQUMsQ0FBQyxFQUFFLEVBQUUsSUFBSSxDQUFDLDJCQUEyQixDQUFDLENBQUMsQ0FBQztRQUNyRCxNQUFNLENBQUMsSUFBSSxDQUFDLENBQUMsb0JBQW9CLEVBQUUsTUFBTSxDQUFDLElBQUksQ0FBQyxTQUFTLENBQUMsQ0FBQyxDQUFDLENBQUMsQ0FBQztRQUM3RCxPQUFPO0tBQ1I7SUFFRCxJQUFJLENBQUUsTUFBTSxNQUFNLENBQUMsUUFBUSxDQUFDLFFBQVEsQ0FBQyxBQUFDLEVBQUU7UUFDdEMsTUFBTSxtQkFBbUIsQ0FBQyxRQUFRLENBQUMsQ0FBQztLQUNyQyxNQUFNO1FBQ0wsTUFBTSxDQUFDLEtBQUssQ0FBQyxDQUFDLEVBQUUsRUFBRSxRQUFRLENBQUMsUUFBUSxDQUFDLDZCQUE2QixDQUFDLENBQUMsQ0FBQztLQUNyRTtDQUNGO0FBRUQsaUNBQWlDLENBQ2pDLE9BQU8sZUFBZSxPQUFPLENBQUMsT0FBZ0IsRUFBaUI7SUFDN0QsTUFBTSxHQUFHLEdBQUcsT0FBTyxLQUFLLFFBQVEsR0FDNUIsQ0FBQywwQkFBMEIsRUFBRSxPQUFPLENBQUMsU0FBUyxDQUFDLEdBQy9DLG9DQUFvQyxBQUFDO0lBRXpDLE1BQU0sQ0FBQyxLQUFLLENBQUMsQ0FBQyxZQUFZLEVBQUUsR0FBRyxDQUFDLE9BQU8sQ0FBQyxDQUFDLENBQUM7SUFDMUMsSUFBSSxDQUFDLE1BQU0sS0FBSyxDQUFDLEdBQUcsQ0FBQyxDQUFDLENBQUMsTUFBTSxLQUFLLEdBQUcsRUFBRTtRQUNyQyxNQUFNLENBQUMsUUFBUSxDQUFDLENBQUMsWUFBWSxFQUFFLEdBQUcsQ0FBQyxlQUFlLENBQUMsQ0FBQyxDQUFDO1FBQ3JELElBQUksQ0FBQyxJQUFJLENBQUMsQ0FBQyxDQUFDLENBQUM7S0FDZDtJQUVELE1BQU0sQ0FBQyxJQUFJLENBQ1QsQ0FBQyx3Q0FBd0MsRUFBRSxHQUFHLENBQUMsRUFBRSxDQUFDLENBQ25ELENBQUM7SUFDRixNQUFNLElBQUksQ0FBQyxHQUFHLENBQUM7UUFDYixHQUFHLEVBQUU7WUFBQyxNQUFNO1lBQUUsU0FBUztZQUFFLE9BQU87WUFBRSxZQUFZO1lBQUUsR0FBRztTQUFDO1FBQ3BELE1BQU0sRUFBRSxTQUFTO0tBQ2xCLENBQUMsQ0FBQyxNQUFNLEVBQUUsQ0FBQztJQUNaLElBQUksQ0FBQyxJQUFJLENBQUMsQ0FBQyxDQUFDLENBQUM7Q0FDZDtBQUVELDJDQUEyQztBQUMzQyxvRUFBb0U7QUFDcEUsZ0NBQWdDO0FBQ2hDLDJEQUEyRDtBQUUzRCw0Q0FBNEM7QUFDNUMsOEVBQThFO0FBQzlFLHNEQUFzRDtBQUN0RCxnREFBZ0Q7QUFDaEQsNERBQTREO0FBQzVELDhEQUE4RDtBQUM5RCxtQ0FBbUM7QUFDbkMsb0JBQW9CO0FBQ3BCLHNDQUFzQztBQUN0QyxhQUFhO0FBQ2IsV0FBVztBQUNYLHlCQUF5QjtBQUN6QixtQkFBbUI7QUFDbkIsUUFBUTtBQUVSLHVCQUF1QjtBQUN2QixJQUFJO0FBRUo7eUNBQ3lDLENBQ3pDLE9BQU8sZUFBZSxxQkFBcUIsQ0FDekMsTUFBMkIsRUFDWjtJQUNmLElBQUksTUFBTSxDQUFDLElBQUksQ0FBQyxNQUFNLENBQUMsT0FBTyxDQUFDLENBQUMsTUFBTSxFQUFFO1FBQ3RDLE1BQU0sQ0FBQyxJQUFJLENBQUMsb0JBQW9CLENBQUMsQ0FBQztRQUNsQyxNQUFNLE1BQU0sR0FBRyxJQUFJLE1BQU0sQ0FBQyxNQUFNLENBQUMsQUFBQztRQUNsQyxLQUFLLE1BQU0sSUFBSSxJQUFJLE1BQU0sQ0FBQyxJQUFJLENBQUMsTUFBTSxDQUFDLE9BQU8sQ0FBQyxDQUFFO1lBQzlDLE1BQU0sTUFBTSxHQUFHLE1BQU0sQ0FBQyxPQUFPLENBQUMsSUFBSSxDQUFDLEFBQUM7WUFDcEMsT0FBTyxDQUFDLEdBQUcsRUFBRSxDQUFDO1lBQ2QsT0FBTyxDQUFDLEdBQUcsQ0FBQyxDQUFDLEdBQUcsRUFBRSxNQUFNLENBQUMsSUFBSSxDQUFDLElBQUksQ0FBQyxDQUFDLENBQUMsQ0FBQyxDQUFDLENBQUM7WUFFeEMsSUFBSSxPQUFPLE1BQU0sS0FBSyxRQUFRLElBQUksQ0FBQyxLQUFLLENBQUMsT0FBTyxDQUFDLE1BQU0sQ0FBQyxJQUFJLE1BQU0sQ0FBQyxJQUFJLEVBQUU7Z0JBQ3ZFLE9BQU8sQ0FBQyxHQUFHLENBQUMsQ0FBQyxHQUFHLEVBQUUsTUFBTSxDQUFDLElBQUksQ0FBQyxDQUFDLENBQUMsQ0FBQzthQUNsQztZQUVELE1BQU0sUUFBUSxHQUFHLE1BQU0sQ0FDcEIsS0FBSyxDQUFDLElBQUksQ0FBQyxDQUNYLEdBQUcsQ0FBQyxDQUFDLE9BQU8sR0FBSyxPQUFPLENBQUMsR0FBRyxDQUFDLElBQUksQ0FBQyxHQUFHLENBQUMsQ0FBQyxDQUN2QyxJQUFJLENBQUMsSUFBSSxDQUFDLE1BQU0sQ0FBQyxDQUFDLEFBQUM7WUFFdEIsT0FBTyxDQUFDLEdBQUcsQ0FBQyxJQUFJLENBQUMsQ0FBQyxLQUFLLEVBQUUsUUFBUSxDQUFDLENBQUMsQ0FBQyxDQUFDLENBQUM7U0FDdkM7UUFDRCxPQUFPLENBQUMsR0FBRyxFQUFFLENBQUM7UUFDZCxPQUFPLENBQUMsR0FBRyxDQUNULENBQUMsMkJBQTJCLEVBQUUsSUFBSSxDQUFDLE9BQU8sQ0FBQyxDQUFDLENBQUMsRUFBRSxNQUFNLENBQUMsVUFBVSxDQUFDLENBQUMsRUFBRSxDQUFDLENBQ3RFLENBQUM7S0FDSCxNQUFNO1FBQ0wsTUFBTSxDQUFDLEtBQUssQ0FBQyw2Q0FBNkMsQ0FBQyxDQUFDO1FBQzVELE1BQU0sT0FBTSxHQUFHLGlCQUFpQixFQUFFLEFBQUM7UUFDbkMsSUFBSSxPQUFNLEVBQUU7WUFDVixNQUFNLENBQUMsSUFBSSxDQUNULENBQUMsOEJBQThCLEVBQUUsT0FBTSxDQUFDLHdCQUF3QixDQUFDLENBQ2xFLENBQUM7U0FDSCxNQUFNO1lBQ0wsTUFBTSxDQUFDLElBQUksQ0FDVCxDQUFDLGlEQUFpRCxFQUNoRCxJQUFJLENBQ0YsT0FBTyxDQUNSLENBQ0YsQ0FBQyxFQUFFLE1BQU0sQ0FBQyxRQUFRLENBQUMsQ0FBQyxFQUFFLEtBQUssQ0FBQyxJQUFJLENBQUMsQ0FBQyxDQUFDLENBQ3JDLENBQUM7U0FDSDtLQUNGO0lBQ0QsTUFBTSxNQUFNLEdBQUcsTUFBTSxrQkFBa0IsRUFBRSxBQUFDO0lBQzFDLElBQUksTUFBTSxJQUFJLE1BQU0sS0FBSyxPQUFPLEVBQUU7UUFDaEMsTUFBTSxDQUFDLE9BQU8sQ0FDWixDQUFDLHVCQUF1QixFQUFFLE1BQU0sQ0FBQyxrQkFBa0IsRUFDakQsSUFBSSxDQUNGLE9BQU8sQ0FDUixDQUNGLENBQUMsRUFBRSxNQUFNLENBQUMsV0FBVyxDQUFDLENBQUMsRUFBRSxLQUFLLENBQUMsSUFBSSxDQUFDLENBQUMsQ0FBQyxDQUN4QyxDQUFDO0tBQ0g7Q0FDRjtBQUVELE9BQU8sZUFBZSxrQkFBa0IsR0FBZ0M7SUFDdEUsTUFBTSxHQUFHLEdBQUcsd0JBQXdCLEFBQUM7SUFDckMsTUFBTSxHQUFHLEdBQUcsQ0FBQyxFQUFFLEdBQUcsQ0FBQyx3QkFBd0IsQ0FBQyxBQUFDO0lBQzdDLE1BQU0sR0FBRyxHQUFHLE1BQU0sS0FBSyxDQUFDLEdBQUcsQ0FBQyxBQUFDO0lBQzdCLElBQUksR0FBRyxDQUFDLE1BQU0sS0FBSyxHQUFHLEVBQUUsT0FBTyxTQUFTLENBQUM7SUFDekMsTUFBTSxJQUFJLEdBQUcsTUFBTSxHQUFHLENBQUMsSUFBSSxFQUFFLEFBQUM7SUFDOUIsT0FBTyxJQUFJLENBQUMsTUFBTSxDQUFDO0NBQ3BCO0FBRUQ7Z0NBQ2dDLENBQ2hDLE9BQU8sU0FBUyxTQUFTLEdBQVM7SUFDaEMsZUFBZSxDQUFDLElBQUksQ0FBQyxDQUFDO0lBQ3RCLE9BQU8sQ0FBQyxHQUFHLENBQ1QsQ0FBQyxFQUFFLElBQUksQ0FBQyxPQUFPLENBQUMsQ0FBQyxHQUFHLEVBQUUsT0FBTyxDQUFDOzs7OztJQUs5QixFQUFFLElBQUksQ0FBQyxPQUFPLENBQUMsQ0FBQyxDQUFDLEVBQUUsTUFBTSxDQUFDLGVBQWUsQ0FBQyxDQUFDLEtBQUssRUFDOUMsSUFBSSxDQUNGLG9CQUFvQixDQUNyQixDQUNGO0lBQ0QsRUFBRSxJQUFJLENBQUMsT0FBTyxDQUFDLENBQUMsQ0FBQyxFQUFFLE1BQU0sQ0FBQyxXQUFXLENBQUMsQ0FBQyxTQUFTLEVBQzlDLElBQUksQ0FDRixnQ0FBZ0MsQ0FDakMsQ0FDRjtJQUNELEVBQUUsSUFBSSxDQUFDLE9BQU8sQ0FBQyxDQUFDLG1CQUFtQixFQUFFLElBQUksQ0FBQyxxQkFBcUIsQ0FBQyxDQUFDOzs7Ozs7OztBQVFyRSxDQUFDLENBQ0UsQ0FBQztDQUNIIn0=
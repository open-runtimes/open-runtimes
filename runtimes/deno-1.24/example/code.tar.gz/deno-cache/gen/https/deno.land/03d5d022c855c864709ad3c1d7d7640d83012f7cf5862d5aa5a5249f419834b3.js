// Copyright 2018-2022 the Deno authors. All rights reserved. MIT license.
// Based on https://github.com/golang/go/blob/0452f9460f50f0f0aba18df43dc2b31906fb66cc/src/io/io.go
// Copyright 2009 The Go Authors. All rights reserved.
// Use of this source code is governed by a BSD-style
// license that can be found in the LICENSE file.
import { Buffer } from "./buffer.ts";
/** Reader utility for strings */ export class StringReader extends Buffer {
    constructor(s){
        super(new TextEncoder().encode(s).buffer);
    }
}
/** Reader utility for combining multiple readers */ export class MultiReader {
    readers;
    currentIndex = 0;
    constructor(readers){
        this.readers = [
            ...readers
        ];
    }
    async read(p) {
        const r = this.readers[this.currentIndex];
        if (!r) return null;
        const result = await r.read(p);
        if (result === null) {
            this.currentIndex++;
            return 0;
        }
        return result;
    }
}
/**
 * A `LimitedReader` reads from `reader` but limits the amount of data returned to just `limit` bytes.
 * Each call to `read` updates `limit` to reflect the new amount remaining.
 * `read` returns `null` when `limit` <= `0` or
 * when the underlying `reader` returns `null`.
 */ export class LimitedReader {
    constructor(reader, limit){
        this.reader = reader;
        this.limit = limit;
    }
    async read(p) {
        if (this.limit <= 0) {
            return null;
        }
        if (p.length > this.limit) {
            p = p.subarray(0, this.limit);
        }
        const n = await this.reader.read(p);
        if (n == null) {
            return null;
        }
        this.limit -= n;
        return n;
    }
    reader;
    limit;
}
//# sourceMappingURL=data:application/json;base64,eyJ2ZXJzaW9uIjozLCJzb3VyY2VzIjpbImh0dHBzOi8vZGVuby5sYW5kL3N0ZEAwLjE0MC4wL2lvL3JlYWRlcnMudHMiXSwic291cmNlc0NvbnRlbnQiOlsiLy8gQ29weXJpZ2h0IDIwMTgtMjAyMiB0aGUgRGVubyBhdXRob3JzLiBBbGwgcmlnaHRzIHJlc2VydmVkLiBNSVQgbGljZW5zZS5cbi8vIEJhc2VkIG9uIGh0dHBzOi8vZ2l0aHViLmNvbS9nb2xhbmcvZ28vYmxvYi8wNDUyZjk0NjBmNTBmMGYwYWJhMThkZjQzZGMyYjMxOTA2ZmI2NmNjL3NyYy9pby9pby5nb1xuLy8gQ29weXJpZ2h0IDIwMDkgVGhlIEdvIEF1dGhvcnMuIEFsbCByaWdodHMgcmVzZXJ2ZWQuXG4vLyBVc2Ugb2YgdGhpcyBzb3VyY2UgY29kZSBpcyBnb3Zlcm5lZCBieSBhIEJTRC1zdHlsZVxuLy8gbGljZW5zZSB0aGF0IGNhbiBiZSBmb3VuZCBpbiB0aGUgTElDRU5TRSBmaWxlLlxuXG5pbXBvcnQgeyBCdWZmZXIgfSBmcm9tIFwiLi9idWZmZXIudHNcIjtcblxuLyoqIFJlYWRlciB1dGlsaXR5IGZvciBzdHJpbmdzICovXG5leHBvcnQgY2xhc3MgU3RyaW5nUmVhZGVyIGV4dGVuZHMgQnVmZmVyIHtcbiAgY29uc3RydWN0b3Ioczogc3RyaW5nKSB7XG4gICAgc3VwZXIobmV3IFRleHRFbmNvZGVyKCkuZW5jb2RlKHMpLmJ1ZmZlcik7XG4gIH1cbn1cblxuLyoqIFJlYWRlciB1dGlsaXR5IGZvciBjb21iaW5pbmcgbXVsdGlwbGUgcmVhZGVycyAqL1xuZXhwb3J0IGNsYXNzIE11bHRpUmVhZGVyIGltcGxlbWVudHMgRGVuby5SZWFkZXIge1xuICBwcml2YXRlIHJlYWRvbmx5IHJlYWRlcnM6IERlbm8uUmVhZGVyW107XG4gIHByaXZhdGUgY3VycmVudEluZGV4ID0gMDtcblxuICBjb25zdHJ1Y3RvcihyZWFkZXJzOiBEZW5vLlJlYWRlcltdKSB7XG4gICAgdGhpcy5yZWFkZXJzID0gWy4uLnJlYWRlcnNdO1xuICB9XG5cbiAgYXN5bmMgcmVhZChwOiBVaW50OEFycmF5KTogUHJvbWlzZTxudW1iZXIgfCBudWxsPiB7XG4gICAgY29uc3QgciA9IHRoaXMucmVhZGVyc1t0aGlzLmN1cnJlbnRJbmRleF07XG4gICAgaWYgKCFyKSByZXR1cm4gbnVsbDtcbiAgICBjb25zdCByZXN1bHQgPSBhd2FpdCByLnJlYWQocCk7XG4gICAgaWYgKHJlc3VsdCA9PT0gbnVsbCkge1xuICAgICAgdGhpcy5jdXJyZW50SW5kZXgrKztcbiAgICAgIHJldHVybiAwO1xuICAgIH1cbiAgICByZXR1cm4gcmVzdWx0O1xuICB9XG59XG5cbi8qKlxuICogQSBgTGltaXRlZFJlYWRlcmAgcmVhZHMgZnJvbSBgcmVhZGVyYCBidXQgbGltaXRzIHRoZSBhbW91bnQgb2YgZGF0YSByZXR1cm5lZCB0byBqdXN0IGBsaW1pdGAgYnl0ZXMuXG4gKiBFYWNoIGNhbGwgdG8gYHJlYWRgIHVwZGF0ZXMgYGxpbWl0YCB0byByZWZsZWN0IHRoZSBuZXcgYW1vdW50IHJlbWFpbmluZy5cbiAqIGByZWFkYCByZXR1cm5zIGBudWxsYCB3aGVuIGBsaW1pdGAgPD0gYDBgIG9yXG4gKiB3aGVuIHRoZSB1bmRlcmx5aW5nIGByZWFkZXJgIHJldHVybnMgYG51bGxgLlxuICovXG5leHBvcnQgY2xhc3MgTGltaXRlZFJlYWRlciBpbXBsZW1lbnRzIERlbm8uUmVhZGVyIHtcbiAgY29uc3RydWN0b3IocHVibGljIHJlYWRlcjogRGVuby5SZWFkZXIsIHB1YmxpYyBsaW1pdDogbnVtYmVyKSB7fVxuXG4gIGFzeW5jIHJlYWQocDogVWludDhBcnJheSk6IFByb21pc2U8bnVtYmVyIHwgbnVsbD4ge1xuICAgIGlmICh0aGlzLmxpbWl0IDw9IDApIHtcbiAgICAgIHJldHVybiBudWxsO1xuICAgIH1cblxuICAgIGlmIChwLmxlbmd0aCA+IHRoaXMubGltaXQpIHtcbiAgICAgIHAgPSBwLnN1YmFycmF5KDAsIHRoaXMubGltaXQpO1xuICAgIH1cbiAgICBjb25zdCBuID0gYXdhaXQgdGhpcy5yZWFkZXIucmVhZChwKTtcbiAgICBpZiAobiA9PSBudWxsKSB7XG4gICAgICByZXR1cm4gbnVsbDtcbiAgICB9XG5cbiAgICB0aGlzLmxpbWl0IC09IG47XG4gICAgcmV0dXJuIG47XG4gIH1cbn1cbiJdLCJuYW1lcyI6W10sIm1hcHBpbmdzIjoiQUFBQSwwRUFBMEU7QUFDMUUsbUdBQW1HO0FBQ25HLHNEQUFzRDtBQUN0RCxxREFBcUQ7QUFDckQsaURBQWlEO0FBRWpELFNBQVMsTUFBTSxRQUFRLGFBQWEsQ0FBQztBQUVyQyxpQ0FBaUMsQ0FDakMsT0FBTyxNQUFNLFlBQVksU0FBUyxNQUFNO0lBQ3RDLFlBQVksQ0FBUyxDQUFFO1FBQ3JCLEtBQUssQ0FBQyxJQUFJLFdBQVcsRUFBRSxDQUFDLE1BQU0sQ0FBQyxDQUFDLENBQUMsQ0FBQyxNQUFNLENBQUMsQ0FBQztLQUMzQztDQUNGO0FBRUQsb0RBQW9ELENBQ3BELE9BQU8sTUFBTSxXQUFXO0lBQ3RCLEFBQWlCLE9BQU8sQ0FBZ0I7SUFDeEMsQUFBUSxZQUFZLEdBQUcsQ0FBQyxDQUFDO0lBRXpCLFlBQVksT0FBc0IsQ0FBRTtRQUNsQyxJQUFJLENBQUMsT0FBTyxHQUFHO2VBQUksT0FBTztTQUFDLENBQUM7S0FDN0I7SUFFRCxNQUFNLElBQUksQ0FBQyxDQUFhLEVBQTBCO1FBQ2hELE1BQU0sQ0FBQyxHQUFHLElBQUksQ0FBQyxPQUFPLENBQUMsSUFBSSxDQUFDLFlBQVksQ0FBQyxBQUFDO1FBQzFDLElBQUksQ0FBQyxDQUFDLEVBQUUsT0FBTyxJQUFJLENBQUM7UUFDcEIsTUFBTSxNQUFNLEdBQUcsTUFBTSxDQUFDLENBQUMsSUFBSSxDQUFDLENBQUMsQ0FBQyxBQUFDO1FBQy9CLElBQUksTUFBTSxLQUFLLElBQUksRUFBRTtZQUNuQixJQUFJLENBQUMsWUFBWSxFQUFFLENBQUM7WUFDcEIsT0FBTyxDQUFDLENBQUM7U0FDVjtRQUNELE9BQU8sTUFBTSxDQUFDO0tBQ2Y7Q0FDRjtBQUVEOzs7OztHQUtHLENBQ0gsT0FBTyxNQUFNLGFBQWE7SUFDeEIsWUFBbUIsTUFBbUIsRUFBUyxLQUFhLENBQUU7YUFBM0MsTUFBbUIsR0FBbkIsTUFBbUI7YUFBUyxLQUFhLEdBQWIsS0FBYTtLQUFJO0lBRWhFLE1BQU0sSUFBSSxDQUFDLENBQWEsRUFBMEI7UUFDaEQsSUFBSSxJQUFJLENBQUMsS0FBSyxJQUFJLENBQUMsRUFBRTtZQUNuQixPQUFPLElBQUksQ0FBQztTQUNiO1FBRUQsSUFBSSxDQUFDLENBQUMsTUFBTSxHQUFHLElBQUksQ0FBQyxLQUFLLEVBQUU7WUFDekIsQ0FBQyxHQUFHLENBQUMsQ0FBQyxRQUFRLENBQUMsQ0FBQyxFQUFFLElBQUksQ0FBQyxLQUFLLENBQUMsQ0FBQztTQUMvQjtRQUNELE1BQU0sQ0FBQyxHQUFHLE1BQU0sSUFBSSxDQUFDLE1BQU0sQ0FBQyxJQUFJLENBQUMsQ0FBQyxDQUFDLEFBQUM7UUFDcEMsSUFBSSxDQUFDLElBQUksSUFBSSxFQUFFO1lBQ2IsT0FBTyxJQUFJLENBQUM7U0FDYjtRQUVELElBQUksQ0FBQyxLQUFLLElBQUksQ0FBQyxDQUFDO1FBQ2hCLE9BQU8sQ0FBQyxDQUFDO0tBQ1Y7SUFqQmtCLE1BQW1CO0lBQVMsS0FBYTtDQWtCN0QifQ==
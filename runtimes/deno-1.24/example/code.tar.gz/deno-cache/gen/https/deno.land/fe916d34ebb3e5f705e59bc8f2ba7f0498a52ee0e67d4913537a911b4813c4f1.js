import { Cookies } from "./cookies.ts";
import { createHttpError } from "./httpError.ts";
import { Request } from "./request.ts";
import { Response } from "./response.ts";
import { send } from "./send.ts";
import { SSEStreamTarget } from "./server_sent_event.ts";
/** Provides context about the current request and response to middleware
 * functions, and the current instance being processed is the first argument
 * provided a {@linkcode Middleware} function.
 *
 * _Typically this is only used as a type annotation and shouldn't be
 * constructed directly._
 *
 * ### Example
 *
 * ```ts
 * import { Application, Context } from "https://deno.land/x/oak/mod.ts";
 *
 * const app = new Application();
 *
 * app.use((ctx) => {
 *   // information about the request is here:
 *   ctx.request;
 *   // information about the response is here:
 *   ctx.response;
 *   // the cookie store is here:
 *   ctx.cookies;
 * });
 *
 * // Needs a type annotation because it cannot be inferred.
 * function mw(ctx: Context) {
 *   // process here...
 * }
 *
 * app.use(mw);
 * ```
 *
 * @template S the state which extends the application state (`AS`)
 * @template AS the type of the state derived from the application
 */ export class Context {
    #socket;
    #sse;
    /** A reference to the current application. */ app;
    /** An object which allows access to cookies, mediating both the request and
   * response. */ cookies;
    /** Is `true` if the current connection is upgradeable to a web socket.
   * Otherwise the value is `false`.  Use `.upgrade()` to upgrade the connection
   * and return the web socket. */ get isUpgradable() {
        const upgrade = this.request.headers.get("upgrade");
        if (!upgrade || upgrade.toLowerCase() !== "websocket") {
            return false;
        }
        const secKey = this.request.headers.get("sec-websocket-key");
        return typeof secKey === "string" && secKey != "";
    }
    /** Determines if the request should be responded to.  If `false` when the
   * middleware completes processing, the response will not be sent back to the
   * requestor.  Typically this is used if the middleware will take over low
   * level processing of requests and responses, for example if using web
   * sockets.  This automatically gets set to `false` when the context is
   * upgraded to a web socket via the `.upgrade()` method.
   *
   * The default is `true`. */ respond;
    /** An object which contains information about the current request. */ request;
    /** An object which contains information about the response that will be sent
   * when the middleware finishes processing. */ response;
    /** If the the current context has been upgraded, then this will be set to
   * with the current web socket, otherwise it is `undefined`. */ get socket() {
        return this.#socket;
    }
    /** The object to pass state to front-end views.  This can be typed by
   * supplying the generic state argument when creating a new app.  For
   * example:
   *
   * ```ts
   * const app = new Application<{ foo: string }>();
   * ```
   *
   * Or can be contextually inferred based on setting an initial state object:
   *
   * ```ts
   * const app = new Application({ state: { foo: "bar" } });
   * ```
   *
   * On each request/response cycle, the context's state is cloned from the
   * application state. This means changes to the context's `.state` will be
   * dropped when the request drops, but "defaults" can be applied to the
   * application's state.  Changes to the application's state though won't be
   * reflected until the next request in the context's state.
   */ state;
    constructor(app, serverRequest, state, secure = false){
        this.app = app;
        this.state = state;
        this.request = new Request(serverRequest, app.proxy, secure);
        this.respond = true;
        this.response = new Response(this.request);
        this.cookies = new Cookies(this.request, this.response, {
            keys: this.app.keys,
            secure: this.request.secure
        });
    }
    /** Asserts the condition and if the condition fails, creates an HTTP error
   * with the provided status (which defaults to `500`).  The error status by
   * default will be set on the `.response.status`.
   *
   * Because of limitation of TypeScript, any assertion type function requires
   * specific type annotations, so the {@linkcode Context} type should be used
   * even if it can be inferred from the context.
   *
   * ### Example
   *
   * ```ts
   * import { Context, Status } from "https://deno.land/x/oak/mod.ts";
   *
   * export function mw(ctx: Context) {
   *   const body = ctx.request.body();
   *   ctx.assert(body.type === "json", Status.NotAcceptable);
   *   // process the body and send a response...
   * }
   * ```
   */ assert(// deno-lint-ignore no-explicit-any
    condition, errorStatus = 500, message, props) {
        if (condition) {
            return;
        }
        const err = createHttpError(errorStatus, message);
        if (props) {
            Object.assign(err, props);
        }
        throw err;
    }
    /** Asynchronously fulfill a response with a file from the local file
   * system.
   *
   * If the `options.path` is not supplied, the file to be sent will default
   * to this `.request.url.pathname`.
   *
   * Requires Deno read permission. */ send(options) {
        const { path =this.request.url.pathname , ...sendOptions } = options;
        return send(this, path, sendOptions);
    }
    /** Convert the connection to stream events, returning an event target for
   * sending server sent events.  Events dispatched on the returned target will
   * be sent to the client and be available in the client's `EventSource` that
   * initiated the connection.
   *
   * This will set `.respond` to `false`. */ sendEvents(options) {
        if (!this.#sse) {
            this.#sse = new SSEStreamTarget(this, options);
        }
        return this.#sse;
    }
    /** Create and throw an HTTP Error, which can be used to pass status
   * information which can be caught by other middleware to send more
   * meaningful error messages back to the client.  The passed error status will
   * be set on the `.response.status` by default as well.
   */ throw(errorStatus, message, props) {
        const err = createHttpError(errorStatus, message);
        if (props) {
            Object.assign(err, props);
        }
        throw err;
    }
    /** Take the current request and upgrade it to a web socket, resolving with
   * the a web standard `WebSocket` object. This will set `.respond` to
   * `false`.  If the socket cannot be upgraded, this method will throw. */ upgrade(options) {
        if (this.#socket) {
            return this.#socket;
        }
        if (!this.request.originalRequest.upgrade) {
            throw new TypeError("Web socket upgrades not currently supported for this type of server.");
        }
        this.#socket = this.request.originalRequest.upgrade(options);
        this.respond = false;
        return this.#socket;
    }
    [Symbol.for("Deno.customInspect")](inspect) {
        const { app , cookies , isUpgradable , respond , request , response , socket , state ,  } = this;
        return `${this.constructor.name} ${inspect({
            app,
            cookies,
            isUpgradable,
            respond,
            request,
            response,
            socket,
            state
        })}`;
    }
    [Symbol.for("nodejs.util.inspect.custom")](depth, // deno-lint-ignore no-explicit-any
    options, inspect) {
        if (depth < 0) {
            return options.stylize(`[${this.constructor.name}]`, "special");
        }
        const newOptions = Object.assign({}, options, {
            depth: options.depth === null ? null : options.depth - 1
        });
        const { app , cookies , isUpgradable , respond , request , response , socket , state ,  } = this;
        return `${options.stylize(this.constructor.name, "special")} ${inspect({
            app,
            cookies,
            isUpgradable,
            respond,
            request,
            response,
            socket,
            state
        }, newOptions)}`;
    }
}
//# sourceMappingURL=data:application/json;base64,eyJ2ZXJzaW9uIjozLCJzb3VyY2VzIjpbImh0dHBzOi8vZGVuby5sYW5kL3gvb2FrQHYxMC42LjAvY29udGV4dC50cyJdLCJzb3VyY2VzQ29udGVudCI6WyIvLyBDb3B5cmlnaHQgMjAxOC0yMDIyIHRoZSBvYWsgYXV0aG9ycy4gQWxsIHJpZ2h0cyByZXNlcnZlZC4gTUlUIGxpY2Vuc2UuXG5cbmltcG9ydCB0eXBlIHsgQXBwbGljYXRpb24sIFN0YXRlIH0gZnJvbSBcIi4vYXBwbGljYXRpb24udHNcIjtcbmltcG9ydCB7IENvb2tpZXMgfSBmcm9tIFwiLi9jb29raWVzLnRzXCI7XG5pbXBvcnQgeyBjcmVhdGVIdHRwRXJyb3IgfSBmcm9tIFwiLi9odHRwRXJyb3IudHNcIjtcbmltcG9ydCB0eXBlIHsgS2V5U3RhY2sgfSBmcm9tIFwiLi9rZXlTdGFjay50c1wiO1xuaW1wb3J0IHsgUmVxdWVzdCB9IGZyb20gXCIuL3JlcXVlc3QudHNcIjtcbmltcG9ydCB7IFJlc3BvbnNlIH0gZnJvbSBcIi4vcmVzcG9uc2UudHNcIjtcbmltcG9ydCB7IHNlbmQsIFNlbmRPcHRpb25zIH0gZnJvbSBcIi4vc2VuZC50c1wiO1xuaW1wb3J0IHtcbiAgU2VydmVyU2VudEV2ZW50VGFyZ2V0T3B0aW9ucyxcbiAgU1NFU3RyZWFtVGFyZ2V0LFxufSBmcm9tIFwiLi9zZXJ2ZXJfc2VudF9ldmVudC50c1wiO1xuaW1wb3J0IHR5cGUgeyBTZXJ2ZXJTZW50RXZlbnRUYXJnZXQgfSBmcm9tIFwiLi9zZXJ2ZXJfc2VudF9ldmVudC50c1wiO1xuaW1wb3J0IHR5cGUge1xuICBFcnJvclN0YXR1cyxcbiAgU2VydmVyUmVxdWVzdCxcbiAgVXBncmFkZVdlYlNvY2tldE9wdGlvbnMsXG59IGZyb20gXCIuL3R5cGVzLmQudHNcIjtcblxuZXhwb3J0IGludGVyZmFjZSBDb250ZXh0U2VuZE9wdGlvbnMgZXh0ZW5kcyBTZW5kT3B0aW9ucyB7XG4gIC8qKiBUaGUgZmlsZW5hbWUgdG8gc2VuZCwgd2hpY2ggd2lsbCBiZSByZXNvbHZlZCBiYXNlZCBvbiB0aGUgb3RoZXIgb3B0aW9ucy5cbiAgICogSWYgdGhpcyBwcm9wZXJ0eSBpcyBvbWl0dGVkLCB0aGUgY3VycmVudCBjb250ZXh0J3MgYC5yZXF1ZXN0LnVybC5wYXRobmFtZWBcbiAgICogd2lsbCBiZSB1c2VkLiAqL1xuICBwYXRoPzogc3RyaW5nO1xufVxuXG4vKiogUHJvdmlkZXMgY29udGV4dCBhYm91dCB0aGUgY3VycmVudCByZXF1ZXN0IGFuZCByZXNwb25zZSB0byBtaWRkbGV3YXJlXG4gKiBmdW5jdGlvbnMsIGFuZCB0aGUgY3VycmVudCBpbnN0YW5jZSBiZWluZyBwcm9jZXNzZWQgaXMgdGhlIGZpcnN0IGFyZ3VtZW50XG4gKiBwcm92aWRlZCBhIHtAbGlua2NvZGUgTWlkZGxld2FyZX0gZnVuY3Rpb24uXG4gKlxuICogX1R5cGljYWxseSB0aGlzIGlzIG9ubHkgdXNlZCBhcyBhIHR5cGUgYW5ub3RhdGlvbiBhbmQgc2hvdWxkbid0IGJlXG4gKiBjb25zdHJ1Y3RlZCBkaXJlY3RseS5fXG4gKlxuICogIyMjIEV4YW1wbGVcbiAqXG4gKiBgYGB0c1xuICogaW1wb3J0IHsgQXBwbGljYXRpb24sIENvbnRleHQgfSBmcm9tIFwiaHR0cHM6Ly9kZW5vLmxhbmQveC9vYWsvbW9kLnRzXCI7XG4gKlxuICogY29uc3QgYXBwID0gbmV3IEFwcGxpY2F0aW9uKCk7XG4gKlxuICogYXBwLnVzZSgoY3R4KSA9PiB7XG4gKiAgIC8vIGluZm9ybWF0aW9uIGFib3V0IHRoZSByZXF1ZXN0IGlzIGhlcmU6XG4gKiAgIGN0eC5yZXF1ZXN0O1xuICogICAvLyBpbmZvcm1hdGlvbiBhYm91dCB0aGUgcmVzcG9uc2UgaXMgaGVyZTpcbiAqICAgY3R4LnJlc3BvbnNlO1xuICogICAvLyB0aGUgY29va2llIHN0b3JlIGlzIGhlcmU6XG4gKiAgIGN0eC5jb29raWVzO1xuICogfSk7XG4gKlxuICogLy8gTmVlZHMgYSB0eXBlIGFubm90YXRpb24gYmVjYXVzZSBpdCBjYW5ub3QgYmUgaW5mZXJyZWQuXG4gKiBmdW5jdGlvbiBtdyhjdHg6IENvbnRleHQpIHtcbiAqICAgLy8gcHJvY2VzcyBoZXJlLi4uXG4gKiB9XG4gKlxuICogYXBwLnVzZShtdyk7XG4gKiBgYGBcbiAqXG4gKiBAdGVtcGxhdGUgUyB0aGUgc3RhdGUgd2hpY2ggZXh0ZW5kcyB0aGUgYXBwbGljYXRpb24gc3RhdGUgKGBBU2ApXG4gKiBAdGVtcGxhdGUgQVMgdGhlIHR5cGUgb2YgdGhlIHN0YXRlIGRlcml2ZWQgZnJvbSB0aGUgYXBwbGljYXRpb25cbiAqL1xuZXhwb3J0IGNsYXNzIENvbnRleHQ8XG4gIFMgZXh0ZW5kcyBBUyA9IFN0YXRlLFxuICAvLyBkZW5vLWxpbnQtaWdub3JlIG5vLWV4cGxpY2l0LWFueVxuICBBUyBleHRlbmRzIFN0YXRlID0gUmVjb3JkPHN0cmluZywgYW55Pixcbj4ge1xuICAjc29ja2V0PzogV2ViU29ja2V0O1xuICAjc3NlPzogU2VydmVyU2VudEV2ZW50VGFyZ2V0O1xuXG4gIC8qKiBBIHJlZmVyZW5jZSB0byB0aGUgY3VycmVudCBhcHBsaWNhdGlvbi4gKi9cbiAgYXBwOiBBcHBsaWNhdGlvbjxBUz47XG5cbiAgLyoqIEFuIG9iamVjdCB3aGljaCBhbGxvd3MgYWNjZXNzIHRvIGNvb2tpZXMsIG1lZGlhdGluZyBib3RoIHRoZSByZXF1ZXN0IGFuZFxuICAgKiByZXNwb25zZS4gKi9cbiAgY29va2llczogQ29va2llcztcblxuICAvKiogSXMgYHRydWVgIGlmIHRoZSBjdXJyZW50IGNvbm5lY3Rpb24gaXMgdXBncmFkZWFibGUgdG8gYSB3ZWIgc29ja2V0LlxuICAgKiBPdGhlcndpc2UgdGhlIHZhbHVlIGlzIGBmYWxzZWAuICBVc2UgYC51cGdyYWRlKClgIHRvIHVwZ3JhZGUgdGhlIGNvbm5lY3Rpb25cbiAgICogYW5kIHJldHVybiB0aGUgd2ViIHNvY2tldC4gKi9cbiAgZ2V0IGlzVXBncmFkYWJsZSgpOiBib29sZWFuIHtcbiAgICBjb25zdCB1cGdyYWRlID0gdGhpcy5yZXF1ZXN0LmhlYWRlcnMuZ2V0KFwidXBncmFkZVwiKTtcbiAgICBpZiAoIXVwZ3JhZGUgfHwgdXBncmFkZS50b0xvd2VyQ2FzZSgpICE9PSBcIndlYnNvY2tldFwiKSB7XG4gICAgICByZXR1cm4gZmFsc2U7XG4gICAgfVxuICAgIGNvbnN0IHNlY0tleSA9IHRoaXMucmVxdWVzdC5oZWFkZXJzLmdldChcInNlYy13ZWJzb2NrZXQta2V5XCIpO1xuICAgIHJldHVybiB0eXBlb2Ygc2VjS2V5ID09PSBcInN0cmluZ1wiICYmIHNlY0tleSAhPSBcIlwiO1xuICB9XG5cbiAgLyoqIERldGVybWluZXMgaWYgdGhlIHJlcXVlc3Qgc2hvdWxkIGJlIHJlc3BvbmRlZCB0by4gIElmIGBmYWxzZWAgd2hlbiB0aGVcbiAgICogbWlkZGxld2FyZSBjb21wbGV0ZXMgcHJvY2Vzc2luZywgdGhlIHJlc3BvbnNlIHdpbGwgbm90IGJlIHNlbnQgYmFjayB0byB0aGVcbiAgICogcmVxdWVzdG9yLiAgVHlwaWNhbGx5IHRoaXMgaXMgdXNlZCBpZiB0aGUgbWlkZGxld2FyZSB3aWxsIHRha2Ugb3ZlciBsb3dcbiAgICogbGV2ZWwgcHJvY2Vzc2luZyBvZiByZXF1ZXN0cyBhbmQgcmVzcG9uc2VzLCBmb3IgZXhhbXBsZSBpZiB1c2luZyB3ZWJcbiAgICogc29ja2V0cy4gIFRoaXMgYXV0b21hdGljYWxseSBnZXRzIHNldCB0byBgZmFsc2VgIHdoZW4gdGhlIGNvbnRleHQgaXNcbiAgICogdXBncmFkZWQgdG8gYSB3ZWIgc29ja2V0IHZpYSB0aGUgYC51cGdyYWRlKClgIG1ldGhvZC5cbiAgICpcbiAgICogVGhlIGRlZmF1bHQgaXMgYHRydWVgLiAqL1xuICByZXNwb25kOiBib29sZWFuO1xuXG4gIC8qKiBBbiBvYmplY3Qgd2hpY2ggY29udGFpbnMgaW5mb3JtYXRpb24gYWJvdXQgdGhlIGN1cnJlbnQgcmVxdWVzdC4gKi9cbiAgcmVxdWVzdDogUmVxdWVzdDtcblxuICAvKiogQW4gb2JqZWN0IHdoaWNoIGNvbnRhaW5zIGluZm9ybWF0aW9uIGFib3V0IHRoZSByZXNwb25zZSB0aGF0IHdpbGwgYmUgc2VudFxuICAgKiB3aGVuIHRoZSBtaWRkbGV3YXJlIGZpbmlzaGVzIHByb2Nlc3NpbmcuICovXG4gIHJlc3BvbnNlOiBSZXNwb25zZTtcblxuICAvKiogSWYgdGhlIHRoZSBjdXJyZW50IGNvbnRleHQgaGFzIGJlZW4gdXBncmFkZWQsIHRoZW4gdGhpcyB3aWxsIGJlIHNldCB0b1xuICAgKiB3aXRoIHRoZSBjdXJyZW50IHdlYiBzb2NrZXQsIG90aGVyd2lzZSBpdCBpcyBgdW5kZWZpbmVkYC4gKi9cbiAgZ2V0IHNvY2tldCgpOiBXZWJTb2NrZXQgfCB1bmRlZmluZWQge1xuICAgIHJldHVybiB0aGlzLiNzb2NrZXQ7XG4gIH1cblxuICAvKiogVGhlIG9iamVjdCB0byBwYXNzIHN0YXRlIHRvIGZyb250LWVuZCB2aWV3cy4gIFRoaXMgY2FuIGJlIHR5cGVkIGJ5XG4gICAqIHN1cHBseWluZyB0aGUgZ2VuZXJpYyBzdGF0ZSBhcmd1bWVudCB3aGVuIGNyZWF0aW5nIGEgbmV3IGFwcC4gIEZvclxuICAgKiBleGFtcGxlOlxuICAgKlxuICAgKiBgYGB0c1xuICAgKiBjb25zdCBhcHAgPSBuZXcgQXBwbGljYXRpb248eyBmb286IHN0cmluZyB9PigpO1xuICAgKiBgYGBcbiAgICpcbiAgICogT3IgY2FuIGJlIGNvbnRleHR1YWxseSBpbmZlcnJlZCBiYXNlZCBvbiBzZXR0aW5nIGFuIGluaXRpYWwgc3RhdGUgb2JqZWN0OlxuICAgKlxuICAgKiBgYGB0c1xuICAgKiBjb25zdCBhcHAgPSBuZXcgQXBwbGljYXRpb24oeyBzdGF0ZTogeyBmb286IFwiYmFyXCIgfSB9KTtcbiAgICogYGBgXG4gICAqXG4gICAqIE9uIGVhY2ggcmVxdWVzdC9yZXNwb25zZSBjeWNsZSwgdGhlIGNvbnRleHQncyBzdGF0ZSBpcyBjbG9uZWQgZnJvbSB0aGVcbiAgICogYXBwbGljYXRpb24gc3RhdGUuIFRoaXMgbWVhbnMgY2hhbmdlcyB0byB0aGUgY29udGV4dCdzIGAuc3RhdGVgIHdpbGwgYmVcbiAgICogZHJvcHBlZCB3aGVuIHRoZSByZXF1ZXN0IGRyb3BzLCBidXQgXCJkZWZhdWx0c1wiIGNhbiBiZSBhcHBsaWVkIHRvIHRoZVxuICAgKiBhcHBsaWNhdGlvbidzIHN0YXRlLiAgQ2hhbmdlcyB0byB0aGUgYXBwbGljYXRpb24ncyBzdGF0ZSB0aG91Z2ggd29uJ3QgYmVcbiAgICogcmVmbGVjdGVkIHVudGlsIHRoZSBuZXh0IHJlcXVlc3QgaW4gdGhlIGNvbnRleHQncyBzdGF0ZS5cbiAgICovXG4gIHN0YXRlOiBTO1xuXG4gIGNvbnN0cnVjdG9yKFxuICAgIGFwcDogQXBwbGljYXRpb248QVM+LFxuICAgIHNlcnZlclJlcXVlc3Q6IFNlcnZlclJlcXVlc3QsXG4gICAgc3RhdGU6IFMsXG4gICAgc2VjdXJlID0gZmFsc2UsXG4gICkge1xuICAgIHRoaXMuYXBwID0gYXBwO1xuICAgIHRoaXMuc3RhdGUgPSBzdGF0ZTtcbiAgICB0aGlzLnJlcXVlc3QgPSBuZXcgUmVxdWVzdChzZXJ2ZXJSZXF1ZXN0LCBhcHAucHJveHksIHNlY3VyZSk7XG4gICAgdGhpcy5yZXNwb25kID0gdHJ1ZTtcbiAgICB0aGlzLnJlc3BvbnNlID0gbmV3IFJlc3BvbnNlKHRoaXMucmVxdWVzdCk7XG4gICAgdGhpcy5jb29raWVzID0gbmV3IENvb2tpZXModGhpcy5yZXF1ZXN0LCB0aGlzLnJlc3BvbnNlLCB7XG4gICAgICBrZXlzOiB0aGlzLmFwcC5rZXlzIGFzIEtleVN0YWNrIHwgdW5kZWZpbmVkLFxuICAgICAgc2VjdXJlOiB0aGlzLnJlcXVlc3Quc2VjdXJlLFxuICAgIH0pO1xuICB9XG5cbiAgLyoqIEFzc2VydHMgdGhlIGNvbmRpdGlvbiBhbmQgaWYgdGhlIGNvbmRpdGlvbiBmYWlscywgY3JlYXRlcyBhbiBIVFRQIGVycm9yXG4gICAqIHdpdGggdGhlIHByb3ZpZGVkIHN0YXR1cyAod2hpY2ggZGVmYXVsdHMgdG8gYDUwMGApLiAgVGhlIGVycm9yIHN0YXR1cyBieVxuICAgKiBkZWZhdWx0IHdpbGwgYmUgc2V0IG9uIHRoZSBgLnJlc3BvbnNlLnN0YXR1c2AuXG4gICAqXG4gICAqIEJlY2F1c2Ugb2YgbGltaXRhdGlvbiBvZiBUeXBlU2NyaXB0LCBhbnkgYXNzZXJ0aW9uIHR5cGUgZnVuY3Rpb24gcmVxdWlyZXNcbiAgICogc3BlY2lmaWMgdHlwZSBhbm5vdGF0aW9ucywgc28gdGhlIHtAbGlua2NvZGUgQ29udGV4dH0gdHlwZSBzaG91bGQgYmUgdXNlZFxuICAgKiBldmVuIGlmIGl0IGNhbiBiZSBpbmZlcnJlZCBmcm9tIHRoZSBjb250ZXh0LlxuICAgKlxuICAgKiAjIyMgRXhhbXBsZVxuICAgKlxuICAgKiBgYGB0c1xuICAgKiBpbXBvcnQgeyBDb250ZXh0LCBTdGF0dXMgfSBmcm9tIFwiaHR0cHM6Ly9kZW5vLmxhbmQveC9vYWsvbW9kLnRzXCI7XG4gICAqXG4gICAqIGV4cG9ydCBmdW5jdGlvbiBtdyhjdHg6IENvbnRleHQpIHtcbiAgICogICBjb25zdCBib2R5ID0gY3R4LnJlcXVlc3QuYm9keSgpO1xuICAgKiAgIGN0eC5hc3NlcnQoYm9keS50eXBlID09PSBcImpzb25cIiwgU3RhdHVzLk5vdEFjY2VwdGFibGUpO1xuICAgKiAgIC8vIHByb2Nlc3MgdGhlIGJvZHkgYW5kIHNlbmQgYSByZXNwb25zZS4uLlxuICAgKiB9XG4gICAqIGBgYFxuICAgKi9cbiAgYXNzZXJ0KFxuICAgIC8vIGRlbm8tbGludC1pZ25vcmUgbm8tZXhwbGljaXQtYW55XG4gICAgY29uZGl0aW9uOiBhbnksXG4gICAgZXJyb3JTdGF0dXM6IEVycm9yU3RhdHVzID0gNTAwLFxuICAgIG1lc3NhZ2U/OiBzdHJpbmcsXG4gICAgcHJvcHM/OiBSZWNvcmQ8c3RyaW5nLCB1bmtub3duPixcbiAgKTogYXNzZXJ0cyBjb25kaXRpb24ge1xuICAgIGlmIChjb25kaXRpb24pIHtcbiAgICAgIHJldHVybjtcbiAgICB9XG4gICAgY29uc3QgZXJyID0gY3JlYXRlSHR0cEVycm9yKGVycm9yU3RhdHVzLCBtZXNzYWdlKTtcbiAgICBpZiAocHJvcHMpIHtcbiAgICAgIE9iamVjdC5hc3NpZ24oZXJyLCBwcm9wcyk7XG4gICAgfVxuICAgIHRocm93IGVycjtcbiAgfVxuXG4gIC8qKiBBc3luY2hyb25vdXNseSBmdWxmaWxsIGEgcmVzcG9uc2Ugd2l0aCBhIGZpbGUgZnJvbSB0aGUgbG9jYWwgZmlsZVxuICAgKiBzeXN0ZW0uXG4gICAqXG4gICAqIElmIHRoZSBgb3B0aW9ucy5wYXRoYCBpcyBub3Qgc3VwcGxpZWQsIHRoZSBmaWxlIHRvIGJlIHNlbnQgd2lsbCBkZWZhdWx0XG4gICAqIHRvIHRoaXMgYC5yZXF1ZXN0LnVybC5wYXRobmFtZWAuXG4gICAqXG4gICAqIFJlcXVpcmVzIERlbm8gcmVhZCBwZXJtaXNzaW9uLiAqL1xuICBzZW5kKG9wdGlvbnM6IENvbnRleHRTZW5kT3B0aW9ucyk6IFByb21pc2U8c3RyaW5nIHwgdW5kZWZpbmVkPiB7XG4gICAgY29uc3QgeyBwYXRoID0gdGhpcy5yZXF1ZXN0LnVybC5wYXRobmFtZSwgLi4uc2VuZE9wdGlvbnMgfSA9IG9wdGlvbnM7XG4gICAgcmV0dXJuIHNlbmQodGhpcywgcGF0aCwgc2VuZE9wdGlvbnMpO1xuICB9XG5cbiAgLyoqIENvbnZlcnQgdGhlIGNvbm5lY3Rpb24gdG8gc3RyZWFtIGV2ZW50cywgcmV0dXJuaW5nIGFuIGV2ZW50IHRhcmdldCBmb3JcbiAgICogc2VuZGluZyBzZXJ2ZXIgc2VudCBldmVudHMuICBFdmVudHMgZGlzcGF0Y2hlZCBvbiB0aGUgcmV0dXJuZWQgdGFyZ2V0IHdpbGxcbiAgICogYmUgc2VudCB0byB0aGUgY2xpZW50IGFuZCBiZSBhdmFpbGFibGUgaW4gdGhlIGNsaWVudCdzIGBFdmVudFNvdXJjZWAgdGhhdFxuICAgKiBpbml0aWF0ZWQgdGhlIGNvbm5lY3Rpb24uXG4gICAqXG4gICAqIFRoaXMgd2lsbCBzZXQgYC5yZXNwb25kYCB0byBgZmFsc2VgLiAqL1xuICBzZW5kRXZlbnRzKG9wdGlvbnM/OiBTZXJ2ZXJTZW50RXZlbnRUYXJnZXRPcHRpb25zKTogU2VydmVyU2VudEV2ZW50VGFyZ2V0IHtcbiAgICBpZiAoIXRoaXMuI3NzZSkge1xuICAgICAgdGhpcy4jc3NlID0gbmV3IFNTRVN0cmVhbVRhcmdldCh0aGlzLCBvcHRpb25zKTtcbiAgICB9XG4gICAgcmV0dXJuIHRoaXMuI3NzZTtcbiAgfVxuXG4gIC8qKiBDcmVhdGUgYW5kIHRocm93IGFuIEhUVFAgRXJyb3IsIHdoaWNoIGNhbiBiZSB1c2VkIHRvIHBhc3Mgc3RhdHVzXG4gICAqIGluZm9ybWF0aW9uIHdoaWNoIGNhbiBiZSBjYXVnaHQgYnkgb3RoZXIgbWlkZGxld2FyZSB0byBzZW5kIG1vcmVcbiAgICogbWVhbmluZ2Z1bCBlcnJvciBtZXNzYWdlcyBiYWNrIHRvIHRoZSBjbGllbnQuICBUaGUgcGFzc2VkIGVycm9yIHN0YXR1cyB3aWxsXG4gICAqIGJlIHNldCBvbiB0aGUgYC5yZXNwb25zZS5zdGF0dXNgIGJ5IGRlZmF1bHQgYXMgd2VsbC5cbiAgICovXG4gIHRocm93KFxuICAgIGVycm9yU3RhdHVzOiBFcnJvclN0YXR1cyxcbiAgICBtZXNzYWdlPzogc3RyaW5nLFxuICAgIHByb3BzPzogUmVjb3JkPHN0cmluZywgdW5rbm93bj4sXG4gICk6IG5ldmVyIHtcbiAgICBjb25zdCBlcnIgPSBjcmVhdGVIdHRwRXJyb3IoZXJyb3JTdGF0dXMsIG1lc3NhZ2UpO1xuICAgIGlmIChwcm9wcykge1xuICAgICAgT2JqZWN0LmFzc2lnbihlcnIsIHByb3BzKTtcbiAgICB9XG4gICAgdGhyb3cgZXJyO1xuICB9XG5cbiAgLyoqIFRha2UgdGhlIGN1cnJlbnQgcmVxdWVzdCBhbmQgdXBncmFkZSBpdCB0byBhIHdlYiBzb2NrZXQsIHJlc29sdmluZyB3aXRoXG4gICAqIHRoZSBhIHdlYiBzdGFuZGFyZCBgV2ViU29ja2V0YCBvYmplY3QuIFRoaXMgd2lsbCBzZXQgYC5yZXNwb25kYCB0b1xuICAgKiBgZmFsc2VgLiAgSWYgdGhlIHNvY2tldCBjYW5ub3QgYmUgdXBncmFkZWQsIHRoaXMgbWV0aG9kIHdpbGwgdGhyb3cuICovXG4gIHVwZ3JhZGUob3B0aW9ucz86IFVwZ3JhZGVXZWJTb2NrZXRPcHRpb25zKTogV2ViU29ja2V0IHtcbiAgICBpZiAodGhpcy4jc29ja2V0KSB7XG4gICAgICByZXR1cm4gdGhpcy4jc29ja2V0O1xuICAgIH1cbiAgICBpZiAoIXRoaXMucmVxdWVzdC5vcmlnaW5hbFJlcXVlc3QudXBncmFkZSkge1xuICAgICAgdGhyb3cgbmV3IFR5cGVFcnJvcihcbiAgICAgICAgXCJXZWIgc29ja2V0IHVwZ3JhZGVzIG5vdCBjdXJyZW50bHkgc3VwcG9ydGVkIGZvciB0aGlzIHR5cGUgb2Ygc2VydmVyLlwiLFxuICAgICAgKTtcbiAgICB9XG4gICAgdGhpcy4jc29ja2V0ID0gdGhpcy5yZXF1ZXN0Lm9yaWdpbmFsUmVxdWVzdC51cGdyYWRlKG9wdGlvbnMpO1xuICAgIHRoaXMucmVzcG9uZCA9IGZhbHNlO1xuICAgIHJldHVybiB0aGlzLiNzb2NrZXQ7XG4gIH1cblxuICBbU3ltYm9sLmZvcihcIkRlbm8uY3VzdG9tSW5zcGVjdFwiKV0oaW5zcGVjdDogKHZhbHVlOiB1bmtub3duKSA9PiBzdHJpbmcpIHtcbiAgICBjb25zdCB7XG4gICAgICBhcHAsXG4gICAgICBjb29raWVzLFxuICAgICAgaXNVcGdyYWRhYmxlLFxuICAgICAgcmVzcG9uZCxcbiAgICAgIHJlcXVlc3QsXG4gICAgICByZXNwb25zZSxcbiAgICAgIHNvY2tldCxcbiAgICAgIHN0YXRlLFxuICAgIH0gPSB0aGlzO1xuICAgIHJldHVybiBgJHt0aGlzLmNvbnN0cnVjdG9yLm5hbWV9ICR7XG4gICAgICBpbnNwZWN0KHtcbiAgICAgICAgYXBwLFxuICAgICAgICBjb29raWVzLFxuICAgICAgICBpc1VwZ3JhZGFibGUsXG4gICAgICAgIHJlc3BvbmQsXG4gICAgICAgIHJlcXVlc3QsXG4gICAgICAgIHJlc3BvbnNlLFxuICAgICAgICBzb2NrZXQsXG4gICAgICAgIHN0YXRlLFxuICAgICAgfSlcbiAgICB9YDtcbiAgfVxuXG4gIFtTeW1ib2wuZm9yKFwibm9kZWpzLnV0aWwuaW5zcGVjdC5jdXN0b21cIildKFxuICAgIGRlcHRoOiBudW1iZXIsXG4gICAgLy8gZGVuby1saW50LWlnbm9yZSBuby1leHBsaWNpdC1hbnlcbiAgICBvcHRpb25zOiBhbnksXG4gICAgaW5zcGVjdDogKHZhbHVlOiB1bmtub3duLCBvcHRpb25zPzogdW5rbm93bikgPT4gc3RyaW5nLFxuICApIHtcbiAgICBpZiAoZGVwdGggPCAwKSB7XG4gICAgICByZXR1cm4gb3B0aW9ucy5zdHlsaXplKGBbJHt0aGlzLmNvbnN0cnVjdG9yLm5hbWV9XWAsIFwic3BlY2lhbFwiKTtcbiAgICB9XG5cbiAgICBjb25zdCBuZXdPcHRpb25zID0gT2JqZWN0LmFzc2lnbih7fSwgb3B0aW9ucywge1xuICAgICAgZGVwdGg6IG9wdGlvbnMuZGVwdGggPT09IG51bGwgPyBudWxsIDogb3B0aW9ucy5kZXB0aCAtIDEsXG4gICAgfSk7XG4gICAgY29uc3Qge1xuICAgICAgYXBwLFxuICAgICAgY29va2llcyxcbiAgICAgIGlzVXBncmFkYWJsZSxcbiAgICAgIHJlc3BvbmQsXG4gICAgICByZXF1ZXN0LFxuICAgICAgcmVzcG9uc2UsXG4gICAgICBzb2NrZXQsXG4gICAgICBzdGF0ZSxcbiAgICB9ID0gdGhpcztcbiAgICByZXR1cm4gYCR7b3B0aW9ucy5zdHlsaXplKHRoaXMuY29uc3RydWN0b3IubmFtZSwgXCJzcGVjaWFsXCIpfSAke1xuICAgICAgaW5zcGVjdCh7XG4gICAgICAgIGFwcCxcbiAgICAgICAgY29va2llcyxcbiAgICAgICAgaXNVcGdyYWRhYmxlLFxuICAgICAgICByZXNwb25kLFxuICAgICAgICByZXF1ZXN0LFxuICAgICAgICByZXNwb25zZSxcbiAgICAgICAgc29ja2V0LFxuICAgICAgICBzdGF0ZSxcbiAgICAgIH0sIG5ld09wdGlvbnMpXG4gICAgfWA7XG4gIH1cbn1cbiJdLCJuYW1lcyI6W10sIm1hcHBpbmdzIjoiQUFHQSxTQUFTLE9BQU8sUUFBUSxjQUFjLENBQUM7QUFDdkMsU0FBUyxlQUFlLFFBQVEsZ0JBQWdCLENBQUM7QUFFakQsU0FBUyxPQUFPLFFBQVEsY0FBYyxDQUFDO0FBQ3ZDLFNBQVMsUUFBUSxRQUFRLGVBQWUsQ0FBQztBQUN6QyxTQUFTLElBQUksUUFBcUIsV0FBVyxDQUFDO0FBQzlDLFNBRUUsZUFBZSxRQUNWLHdCQUF3QixDQUFDO0FBZWhDOzs7Ozs7Ozs7Ozs7Ozs7Ozs7Ozs7Ozs7Ozs7Ozs7Ozs7R0FpQ0csQ0FDSCxPQUFPLE1BQU0sT0FBTztJQUtsQixDQUFDLE1BQU0sQ0FBYTtJQUNwQixDQUFDLEdBQUcsQ0FBeUI7SUFFN0IsOENBQThDLENBQzlDLEdBQUcsQ0FBa0I7SUFFckI7aUJBQ2UsQ0FDZixPQUFPLENBQVU7SUFFakI7O2tDQUVnQyxDQUNoQyxJQUFJLFlBQVksR0FBWTtRQUMxQixNQUFNLE9BQU8sR0FBRyxJQUFJLENBQUMsT0FBTyxDQUFDLE9BQU8sQ0FBQyxHQUFHLENBQUMsU0FBUyxDQUFDLEFBQUM7UUFDcEQsSUFBSSxDQUFDLE9BQU8sSUFBSSxPQUFPLENBQUMsV0FBVyxFQUFFLEtBQUssV0FBVyxFQUFFO1lBQ3JELE9BQU8sS0FBSyxDQUFDO1NBQ2Q7UUFDRCxNQUFNLE1BQU0sR0FBRyxJQUFJLENBQUMsT0FBTyxDQUFDLE9BQU8sQ0FBQyxHQUFHLENBQUMsbUJBQW1CLENBQUMsQUFBQztRQUM3RCxPQUFPLE9BQU8sTUFBTSxLQUFLLFFBQVEsSUFBSSxNQUFNLElBQUksRUFBRSxDQUFDO0tBQ25EO0lBRUQ7Ozs7Ozs7OEJBTzRCLENBQzVCLE9BQU8sQ0FBVTtJQUVqQixzRUFBc0UsQ0FDdEUsT0FBTyxDQUFVO0lBRWpCO2dEQUM4QyxDQUM5QyxRQUFRLENBQVc7SUFFbkI7aUVBQytELENBQy9ELElBQUksTUFBTSxHQUEwQjtRQUNsQyxPQUFPLElBQUksQ0FBQyxDQUFDLE1BQU0sQ0FBQztLQUNyQjtJQUVEOzs7Ozs7Ozs7Ozs7Ozs7Ozs7O0tBbUJHLENBQ0gsS0FBSyxDQUFJO0lBRVQsWUFDRSxHQUFvQixFQUNwQixhQUE0QixFQUM1QixLQUFRLEVBQ1IsTUFBTSxHQUFHLEtBQUssQ0FDZDtRQUNBLElBQUksQ0FBQyxHQUFHLEdBQUcsR0FBRyxDQUFDO1FBQ2YsSUFBSSxDQUFDLEtBQUssR0FBRyxLQUFLLENBQUM7UUFDbkIsSUFBSSxDQUFDLE9BQU8sR0FBRyxJQUFJLE9BQU8sQ0FBQyxhQUFhLEVBQUUsR0FBRyxDQUFDLEtBQUssRUFBRSxNQUFNLENBQUMsQ0FBQztRQUM3RCxJQUFJLENBQUMsT0FBTyxHQUFHLElBQUksQ0FBQztRQUNwQixJQUFJLENBQUMsUUFBUSxHQUFHLElBQUksUUFBUSxDQUFDLElBQUksQ0FBQyxPQUFPLENBQUMsQ0FBQztRQUMzQyxJQUFJLENBQUMsT0FBTyxHQUFHLElBQUksT0FBTyxDQUFDLElBQUksQ0FBQyxPQUFPLEVBQUUsSUFBSSxDQUFDLFFBQVEsRUFBRTtZQUN0RCxJQUFJLEVBQUUsSUFBSSxDQUFDLEdBQUcsQ0FBQyxJQUFJO1lBQ25CLE1BQU0sRUFBRSxJQUFJLENBQUMsT0FBTyxDQUFDLE1BQU07U0FDNUIsQ0FBQyxDQUFDO0tBQ0o7SUFFRDs7Ozs7Ozs7Ozs7Ozs7Ozs7OztLQW1CRyxDQUNILE1BQU0sQ0FDSixtQ0FBbUM7SUFDbkMsU0FBYyxFQUNkLFdBQXdCLEdBQUcsR0FBRyxFQUM5QixPQUFnQixFQUNoQixLQUErQixFQUNaO1FBQ25CLElBQUksU0FBUyxFQUFFO1lBQ2IsT0FBTztTQUNSO1FBQ0QsTUFBTSxHQUFHLEdBQUcsZUFBZSxDQUFDLFdBQVcsRUFBRSxPQUFPLENBQUMsQUFBQztRQUNsRCxJQUFJLEtBQUssRUFBRTtZQUNULE1BQU0sQ0FBQyxNQUFNLENBQUMsR0FBRyxFQUFFLEtBQUssQ0FBQyxDQUFDO1NBQzNCO1FBQ0QsTUFBTSxHQUFHLENBQUM7S0FDWDtJQUVEOzs7Ozs7c0NBTW9DLENBQ3BDLElBQUksQ0FBQyxPQUEyQixFQUErQjtRQUM3RCxNQUFNLEVBQUUsSUFBSSxFQUFHLElBQUksQ0FBQyxPQUFPLENBQUMsR0FBRyxDQUFDLFFBQVEsQ0FBQSxFQUFFLEdBQUcsV0FBVyxFQUFFLEdBQUcsT0FBTyxBQUFDO1FBQ3JFLE9BQU8sSUFBSSxDQUFDLElBQUksRUFBRSxJQUFJLEVBQUUsV0FBVyxDQUFDLENBQUM7S0FDdEM7SUFFRDs7Ozs7NENBSzBDLENBQzFDLFVBQVUsQ0FBQyxPQUFzQyxFQUF5QjtRQUN4RSxJQUFJLENBQUMsSUFBSSxDQUFDLENBQUMsR0FBRyxFQUFFO1lBQ2QsSUFBSSxDQUFDLENBQUMsR0FBRyxHQUFHLElBQUksZUFBZSxDQUFDLElBQUksRUFBRSxPQUFPLENBQUMsQ0FBQztTQUNoRDtRQUNELE9BQU8sSUFBSSxDQUFDLENBQUMsR0FBRyxDQUFDO0tBQ2xCO0lBRUQ7Ozs7S0FJRyxDQUNILEtBQUssQ0FDSCxXQUF3QixFQUN4QixPQUFnQixFQUNoQixLQUErQixFQUN4QjtRQUNQLE1BQU0sR0FBRyxHQUFHLGVBQWUsQ0FBQyxXQUFXLEVBQUUsT0FBTyxDQUFDLEFBQUM7UUFDbEQsSUFBSSxLQUFLLEVBQUU7WUFDVCxNQUFNLENBQUMsTUFBTSxDQUFDLEdBQUcsRUFBRSxLQUFLLENBQUMsQ0FBQztTQUMzQjtRQUNELE1BQU0sR0FBRyxDQUFDO0tBQ1g7SUFFRDs7MkVBRXlFLENBQ3pFLE9BQU8sQ0FBQyxPQUFpQyxFQUFhO1FBQ3BELElBQUksSUFBSSxDQUFDLENBQUMsTUFBTSxFQUFFO1lBQ2hCLE9BQU8sSUFBSSxDQUFDLENBQUMsTUFBTSxDQUFDO1NBQ3JCO1FBQ0QsSUFBSSxDQUFDLElBQUksQ0FBQyxPQUFPLENBQUMsZUFBZSxDQUFDLE9BQU8sRUFBRTtZQUN6QyxNQUFNLElBQUksU0FBUyxDQUNqQixzRUFBc0UsQ0FDdkUsQ0FBQztTQUNIO1FBQ0QsSUFBSSxDQUFDLENBQUMsTUFBTSxHQUFHLElBQUksQ0FBQyxPQUFPLENBQUMsZUFBZSxDQUFDLE9BQU8sQ0FBQyxPQUFPLENBQUMsQ0FBQztRQUM3RCxJQUFJLENBQUMsT0FBTyxHQUFHLEtBQUssQ0FBQztRQUNyQixPQUFPLElBQUksQ0FBQyxDQUFDLE1BQU0sQ0FBQztLQUNyQjtJQUVELENBQUMsTUFBTSxDQUFDLEdBQUcsQ0FBQyxvQkFBb0IsQ0FBQyxDQUFDLENBQUMsT0FBbUMsRUFBRTtRQUN0RSxNQUFNLEVBQ0osR0FBRyxDQUFBLEVBQ0gsT0FBTyxDQUFBLEVBQ1AsWUFBWSxDQUFBLEVBQ1osT0FBTyxDQUFBLEVBQ1AsT0FBTyxDQUFBLEVBQ1AsUUFBUSxDQUFBLEVBQ1IsTUFBTSxDQUFBLEVBQ04sS0FBSyxDQUFBLElBQ04sR0FBRyxJQUFJLEFBQUM7UUFDVCxPQUFPLENBQUMsRUFBRSxJQUFJLENBQUMsV0FBVyxDQUFDLElBQUksQ0FBQyxDQUFDLEVBQy9CLE9BQU8sQ0FBQztZQUNOLEdBQUc7WUFDSCxPQUFPO1lBQ1AsWUFBWTtZQUNaLE9BQU87WUFDUCxPQUFPO1lBQ1AsUUFBUTtZQUNSLE1BQU07WUFDTixLQUFLO1NBQ04sQ0FBQyxDQUNILENBQUMsQ0FBQztLQUNKO0lBRUQsQ0FBQyxNQUFNLENBQUMsR0FBRyxDQUFDLDRCQUE0QixDQUFDLENBQUMsQ0FDeEMsS0FBYSxFQUNiLG1DQUFtQztJQUNuQyxPQUFZLEVBQ1osT0FBc0QsRUFDdEQ7UUFDQSxJQUFJLEtBQUssR0FBRyxDQUFDLEVBQUU7WUFDYixPQUFPLE9BQU8sQ0FBQyxPQUFPLENBQUMsQ0FBQyxDQUFDLEVBQUUsSUFBSSxDQUFDLFdBQVcsQ0FBQyxJQUFJLENBQUMsQ0FBQyxDQUFDLEVBQUUsU0FBUyxDQUFDLENBQUM7U0FDakU7UUFFRCxNQUFNLFVBQVUsR0FBRyxNQUFNLENBQUMsTUFBTSxDQUFDLEVBQUUsRUFBRSxPQUFPLEVBQUU7WUFDNUMsS0FBSyxFQUFFLE9BQU8sQ0FBQyxLQUFLLEtBQUssSUFBSSxHQUFHLElBQUksR0FBRyxPQUFPLENBQUMsS0FBSyxHQUFHLENBQUM7U0FDekQsQ0FBQyxBQUFDO1FBQ0gsTUFBTSxFQUNKLEdBQUcsQ0FBQSxFQUNILE9BQU8sQ0FBQSxFQUNQLFlBQVksQ0FBQSxFQUNaLE9BQU8sQ0FBQSxFQUNQLE9BQU8sQ0FBQSxFQUNQLFFBQVEsQ0FBQSxFQUNSLE1BQU0sQ0FBQSxFQUNOLEtBQUssQ0FBQSxJQUNOLEdBQUcsSUFBSSxBQUFDO1FBQ1QsT0FBTyxDQUFDLEVBQUUsT0FBTyxDQUFDLE9BQU8sQ0FBQyxJQUFJLENBQUMsV0FBVyxDQUFDLElBQUksRUFBRSxTQUFTLENBQUMsQ0FBQyxDQUFDLEVBQzNELE9BQU8sQ0FBQztZQUNOLEdBQUc7WUFDSCxPQUFPO1lBQ1AsWUFBWTtZQUNaLE9BQU87WUFDUCxPQUFPO1lBQ1AsUUFBUTtZQUNSLE1BQU07WUFDTixLQUFLO1NBQ04sRUFBRSxVQUFVLENBQUMsQ0FDZixDQUFDLENBQUM7S0FDSjtDQUNGIn0=
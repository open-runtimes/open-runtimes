import axiod from "https://deno.land/x/axiod/mod.ts";
/*
    'req' variable has:
        'headers' - object with request headers
        'payload' - object with request body data
        'variables' - object with function variables
    'res' variable has:
        'send(text, status)' - function to return text response. Status code defaults to 200
        'json(obj, status)' - function to return JSON response. Status code defaults to 200
    
    If an error is thrown, a response with code 500 will be returned.
*/ export default async function(req, res) {
    const payload = JSON.parse(req.payload === '' ? '{}' : req.payload);
    const todo = (await axiod.get(`https://jsonplaceholder.typicode.com/todos/${payload.id ?? 1}`)).data;
    console.log('log');
    console.warn('warning');
    console.error('error');
    console.info('info');
    console.debug('debug');
    console.log('log1', 'log2');
    console.log({
        hello: 'world'
    });
    console.log([
        'hello',
        'world'
    ]);
    res.json({
        message: 'Hello Open Runtimes 👋',
        todo
    });
};
//# sourceMappingURL=data:application/json;base64,eyJ2ZXJzaW9uIjozLCJzb3VyY2VzIjpbImZpbGU6Ly8vdXNyL2J1aWxkcy9tb2QudHMiXSwic291cmNlc0NvbnRlbnQiOlsiaW1wb3J0IGF4aW9kIGZyb20gXCJodHRwczovL2Rlbm8ubGFuZC94L2F4aW9kL21vZC50c1wiO1xuXG4vKlxuICAgICdyZXEnIHZhcmlhYmxlIGhhczpcbiAgICAgICAgJ2hlYWRlcnMnIC0gb2JqZWN0IHdpdGggcmVxdWVzdCBoZWFkZXJzXG4gICAgICAgICdwYXlsb2FkJyAtIG9iamVjdCB3aXRoIHJlcXVlc3QgYm9keSBkYXRhXG4gICAgICAgICd2YXJpYWJsZXMnIC0gb2JqZWN0IHdpdGggZnVuY3Rpb24gdmFyaWFibGVzXG4gICAgJ3JlcycgdmFyaWFibGUgaGFzOlxuICAgICAgICAnc2VuZCh0ZXh0LCBzdGF0dXMpJyAtIGZ1bmN0aW9uIHRvIHJldHVybiB0ZXh0IHJlc3BvbnNlLiBTdGF0dXMgY29kZSBkZWZhdWx0cyB0byAyMDBcbiAgICAgICAgJ2pzb24ob2JqLCBzdGF0dXMpJyAtIGZ1bmN0aW9uIHRvIHJldHVybiBKU09OIHJlc3BvbnNlLiBTdGF0dXMgY29kZSBkZWZhdWx0cyB0byAyMDBcbiAgICBcbiAgICBJZiBhbiBlcnJvciBpcyB0aHJvd24sIGEgcmVzcG9uc2Ugd2l0aCBjb2RlIDUwMCB3aWxsIGJlIHJldHVybmVkLlxuKi9cblxuZXhwb3J0IGRlZmF1bHQgYXN5bmMgZnVuY3Rpb24ocmVxOiBhbnksIHJlczogYW55KSB7XG4gICAgY29uc3QgcGF5bG9hZCA9IEpTT04ucGFyc2UocmVxLnBheWxvYWQgPT09ICcnID8gJ3t9JyA6IHJlcS5wYXlsb2FkKTtcblxuICAgIGNvbnN0IHRvZG8gPSAoYXdhaXQgYXhpb2QuZ2V0KGBodHRwczovL2pzb25wbGFjZWhvbGRlci50eXBpY29kZS5jb20vdG9kb3MvJHtwYXlsb2FkLmlkID8/IDF9YCkpLmRhdGE7XG4gICAgY29uc29sZS5sb2coJ2xvZycpO1xuICAgIGNvbnNvbGUud2Fybignd2FybmluZycpO1xuICAgIGNvbnNvbGUuZXJyb3IoJ2Vycm9yJyk7XG4gICAgY29uc29sZS5pbmZvKCdpbmZvJyk7XG4gICAgY29uc29sZS5kZWJ1ZygnZGVidWcnKTtcbiAgICBjb25zb2xlLmxvZygnbG9nMScsICdsb2cyJyk7XG4gICAgY29uc29sZS5sb2coe2hlbGxvOiAnd29ybGQnfSk7XG4gICAgY29uc29sZS5sb2coWydoZWxsbycsICd3b3JsZCddKTtcbiAgICByZXMuanNvbih7XG4gICAgICAgIG1lc3NhZ2U6ICdIZWxsbyBPcGVuIFJ1bnRpbWVzIPCfkYsnLFxuICAgICAgICB0b2RvXG4gICAgfSk7XG59Il0sIm5hbWVzIjpbXSwibWFwcGluZ3MiOiJBQUFBLE9BQU8sS0FBSyxNQUFNLGtDQUFrQyxDQUFDO0FBRXJEOzs7Ozs7Ozs7O0VBVUUsQ0FFRixlQUFlLGVBQWUsR0FBUSxFQUFFLEdBQVEsRUFBRTtJQUM5QyxNQUFNLE9BQU8sR0FBRyxJQUFJLENBQUMsS0FBSyxDQUFDLEdBQUcsQ0FBQyxPQUFPLEtBQUssRUFBRSxHQUFHLElBQUksR0FBRyxHQUFHLENBQUMsT0FBTyxDQUFDLEFBQUM7SUFFcEUsTUFBTSxJQUFJLEdBQUcsQ0FBQyxNQUFNLEtBQUssQ0FBQyxHQUFHLENBQUMsQ0FBQywyQ0FBMkMsRUFBRSxPQUFPLENBQUMsRUFBRSxJQUFJLENBQUMsQ0FBQyxDQUFDLENBQUMsQ0FBQyxDQUFDLElBQUksQUFBQztJQUNyRyxPQUFPLENBQUMsR0FBRyxDQUFDLEtBQUssQ0FBQyxDQUFDO0lBQ25CLE9BQU8sQ0FBQyxJQUFJLENBQUMsU0FBUyxDQUFDLENBQUM7SUFDeEIsT0FBTyxDQUFDLEtBQUssQ0FBQyxPQUFPLENBQUMsQ0FBQztJQUN2QixPQUFPLENBQUMsSUFBSSxDQUFDLE1BQU0sQ0FBQyxDQUFDO0lBQ3JCLE9BQU8sQ0FBQyxLQUFLLENBQUMsT0FBTyxDQUFDLENBQUM7SUFDdkIsT0FBTyxDQUFDLEdBQUcsQ0FBQyxNQUFNLEVBQUUsTUFBTSxDQUFDLENBQUM7SUFDNUIsT0FBTyxDQUFDLEdBQUcsQ0FBQztRQUFDLEtBQUssRUFBRSxPQUFPO0tBQUMsQ0FBQyxDQUFDO0lBQzlCLE9BQU8sQ0FBQyxHQUFHLENBQUM7UUFBQyxPQUFPO1FBQUUsT0FBTztLQUFDLENBQUMsQ0FBQztJQUNoQyxHQUFHLENBQUMsSUFBSSxDQUFDO1FBQ0wsT0FBTyxFQUFFLHVCQUF1QjtRQUNoQyxJQUFJO0tBQ1AsQ0FBQyxDQUFDO0NBQ04sQ0FBQSJ9